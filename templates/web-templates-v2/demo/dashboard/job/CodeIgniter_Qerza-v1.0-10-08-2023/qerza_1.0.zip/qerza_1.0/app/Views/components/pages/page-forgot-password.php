<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="author" content="">
	<meta name="robots" content="">
	<meta name="keywords" content="job portal, admin dashboard, Bootstrap CodeIgniter template, job listings, applicants, user-friendly interface, powerful functionalities">
	<meta name="description" content="Qerza is a versatile job portal admin dashboard powered by Bootstrap and CodeIgniter Technology. Streamline job listings, applicants, and enhance your recruitment process. User-friendly interface with powerful functionalities. Job portal, admin dashboard, Bootstrap CodeIgniter template">
	<meta property="og:title" content="Qerza - Job Portal CodeIgniter Admin Dashboard Template">
	<meta property="og:description" content="Dompet is a clean-coded, responsive Codeigniter template that can be easily customised to fit the needs of various credit card and invoice, modern, creative, Transfer money, and other businesses.">
	<meta property="og:image" content="https://qerza.dexignzone.com/codeigniter/social-image.png'); ?>">
    <meta name="format-detection" content="telephone=no">
    <title>Qerza - Job Portal CodeIgniter Admin Dashboard Template</title>

	<!-- Mobile Specific -->
	<meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo site_url('public/assets/images/favicon.png'); ?>">
    <link href="<?php echo site_url('public/assets/vendor/bootstrap-select/dist/css/bootstrap-select.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo site_url('public/assets/css/style.css'); ?>" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
	
</head>

<body class="vh-100">
	<div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-6">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <div class="auth-form">
									<div class="text-center mb-3">
										<a href="<?php echo site_url('/index'); ?>"><img src="<?php echo base_url('public/assets/images/logo-full.png'); ?>" alt=""></a>
									</div>
                                    <h4 class="text-center mb-4 text-white">Forgot Password</h4>
                                    <form action="<?php echo site_url('/index'); ?>">
                                        <div class="form-group">
                                            <label class="text-white"><strong>Email</strong></label>
                                            <input type="email" class="form-control" value="hello@example.com">
                                        </div>
                                        <div class="text-center">
                                            <button type="submit" class="btn bg-white text-primary btn-block">SUBMIT</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!--**********************************
	Scripts
***********************************-->
<!-- Required vendors -->
<script src="<?php echo site_url('public/assets/vendor/global/global.min.js'); ?>"></script>
<script src="<?php echo site_url('public/assets/vendor/bootstrap-select/dist/js/bootstrap-select.min.js'); ?>"></script>
<script src="<?php echo site_url('public/assets/js/custom.min.js'); ?>"></script>
<script src="<?php echo site_url('public/assets/js/deznav-init.js'); ?>"></script>
</body>
</html>