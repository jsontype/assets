<!--**********************************
	Sidebar start
***********************************-->
<div class="deznav">
	<div class="deznav-scroll">
		<ul class="metismenu" id="menu">
			<li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
					<i class="flaticon-381-networking"></i>
					<span class="nav-text">Dashboard</span>
				</a>
				<ul aria-expanded="false">
					<li><a href="<?php echo site_url('/index'); ?>">Dashboard Light</a></li>
					<li><a href="<?php echo site_url('/index_2'); ?>">Dashboard Dark</a></li>
					<li><a href="<?php echo site_url('/search_job'); ?>">Search Job</a></li>
					<li><a href="<?php echo site_url('/application'); ?>">Application</a></li>
					<li><a href="<?php echo site_url('/profile'); ?>">Profile</a></li>
					<li><a href="<?php echo site_url('/statistics'); ?>">Statistics</a></li>
					<li><a href="<?php echo site_url('/companies'); ?>">Companies</a></li>
				</ul>
			</li>
			<li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
					<i class="flaticon-381-television"></i>
					<span class="nav-text">Apps</span>
				</a>
				<ul aria-expanded="false">
					<li><a href="<?php echo site_url('/app_profile'); ?>">Profile</a></li>
					<li><a href="<?php echo site_url('/post_details'); ?>">Post Details</a></li>
					<li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Email</a>
						<ul aria-expanded="false">
							<li><a href="<?php echo site_url('/email_compose'); ?>">Compose</a></li>
                            <li><a href="<?php echo site_url('/email_inbox'); ?>">Inbox</a></li>
                            <li><a href="<?php echo site_url('/email_read'); ?>">Read</a></li>
						</ul>
					</li>
					<li><a href="<?php echo site_url('/app_calendar'); ?>">Calendar</a></li>
					<li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Shop</a>
						<ul aria-expanded="false">
							<li><a href="<?php echo site_url('/ecom_product_grid'); ?>">Product Grid</a></li>
                            <li><a href="<?php echo site_url('/ecom_product_list'); ?>">Product List</a></li>
                            <li><a href="<?php echo site_url('/ecom_product_details'); ?>">Product Details</a></li>
                            <li><a href="<?php echo site_url('/ecom_product_order'); ?>">Order</a></li>
                            <li><a href="<?php echo site_url('/ecom_checkout'); ?>">Checkout</a></li>
                            <li><a href="<?php echo site_url('/ecom_invoice'); ?>">Invoice</a></li>
                            <li><a href="<?php echo site_url('/ecom_customers'); ?>">Customers</a></li>
						</ul>
					</li>
				</ul>
			</li>
			<li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
					<i class="flaticon-381-controls-3"></i>
					<span class="nav-text">Charts</span>
				</a>
				<ul aria-expanded="false">
					<li><a href="<?php echo site_url('/flot'); ?>">Flot</a></li>
                    <li><a href="<?php echo site_url('/morris'); ?>">Morris</a></li>
                    <li><a href="<?php echo site_url('/chartjs'); ?>">Chartjs</a></li>
                    <li><a href="<?php echo site_url('/chartist'); ?>">Chartist</a></li>
                    <li><a href="<?php echo site_url('/sparkline'); ?>">Sparkline</a></li>
                    <li><a href="<?php echo site_url('/peity'); ?>">Peity</a></li>
				</ul>
			</li>
			<li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
					<i class="flaticon-381-internet"></i>
					<span class="nav-text">Bootstrap</span>
				</a>
				<ul aria-expanded="false">
					<li><a href="<?php echo site_url('/accordion'); ?>">Accordion</a></li>
                    <li><a href="<?php echo site_url('/alert'); ?>">Alert</a></li>
                    <li><a href="<?php echo site_url('/badge'); ?>">Badge</a></li>
                    <li><a href="<?php echo site_url('/button'); ?>">Button</a></li>
                    <li><a href="<?php echo site_url('/modal'); ?>">Modal</a></li>
                    <li><a href="<?php echo site_url('/button_group'); ?>">Button Group</a></li>
                    <li><a href="<?php echo site_url('/list_group'); ?>">List Group</a></li>
                    <li><a href="<?php echo site_url('/media_object'); ?>">Media Object</a></li>
                    <li><a href="<?php echo site_url('/card'); ?>">Cards</a></li>
                    <li><a href="<?php echo site_url('/carousel'); ?>">Carousel</a></li>
                    <li><a href="<?php echo site_url('/dropdown'); ?>">Dropdown</a></li>
                    <li><a href="<?php echo site_url('/popover'); ?>">Popover</a></li>
                    <li><a href="<?php echo site_url('/progressbar'); ?>">Progressbar</a></li>
                    <li><a href="<?php echo site_url('/tab'); ?>">Tab</a></li>
                    <li><a href="<?php echo site_url('/typography'); ?>">Typography</a></li>
                    <li><a href="<?php echo site_url('/pagination'); ?>">Pagination</a></li>
                    <li><a href="<?php echo site_url('/grid'); ?>">Grid</a></li>
				</ul>
			</li>
			<li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
					<i class="flaticon-381-heart"></i>
					<span class="nav-text">Plugins</span>
				</a>
				<ul aria-expanded="false">
					<li><a href="<?php echo site_url('/select2'); ?>">Select 2</a></li>
                    <li><a href="<?php echo site_url('/nestable'); ?>">Nestedtable</a></li>
                    <li><a href="<?php echo site_url('/noui_slider'); ?>">Noui Slider</a></li>
                    <li><a href="<?php echo site_url('/sweetalert'); ?>">Sweet Alert</a></li>
                    <li><a href="<?php echo site_url('/toastr'); ?>">Toastr</a></li>
                    <li><a href="<?php echo site_url('/map_jqvmap'); ?>">Jqv Map</a></li>
                    <li><a href="<?php echo site_url('/lightgallery'); ?>">Light Gallery</a></li>
				</ul>
			</li>
			<li><a href="<?php echo site_url('/widget_basic'); ?>" class="ai-icon" aria-expanded="false">
					<i class="flaticon-381-settings-2"></i>
					<span class="nav-text">Widget</span>
				</a>
			</li>
			<li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
					<i class="flaticon-381-notepad"></i>
					<span class="nav-text">Forms</span>
				</a>
				<ul aria-expanded="false">
					<li><a href="<?php echo site_url('/form_element'); ?>">Form Elements</a></li>
                    <li><a href="<?php echo site_url('/form_wizard'); ?>">Wizard</a></li>
                    <li><a href="<?php echo site_url('/form_editor_summernote'); ?>">Summernote</a></li>
                    <li><a href="<?php echo site_url('/form_pickers'); ?>">Pickers</a></li>
                    <li><a href="<?php echo site_url('/form_validation_jquery'); ?>">Jquery Validate</a></li>
				</ul>
			</li>
			<li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
					<i class="flaticon-381-network"></i>
					<span class="nav-text">Table</span>
				</a>
				<ul aria-expanded="false">
					<li><a href="<?php echo site_url('table_bootstrap'); ?>">Bootstrap</a></li>
					<li><a href="<?php echo site_url('table_datatable'); ?>">Datatable</a></li>
				</ul>
			</li>
			<li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
					<i class="flaticon-381-layer-1"></i>
					<span class="nav-text">Pages</span>
				</a>
				<ul aria-expanded="false">
					<li><a href="<?php echo site_url('page_register'); ?>">Register</a></li>
					<li><a href="<?php echo site_url('page_login'); ?>">Login</a></li>
					<li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Error</a>
						<ul aria-expanded="false">
							<li><a href="<?php echo site_url('page_error_400'); ?>">Error 400</a></li>
                            <li><a href="<?php echo site_url('page_error_403'); ?>">Error 403</a></li>
                            <li><a href="<?php echo site_url('page_error_404'); ?>">Error 404</a></li>
                            <li><a href="<?php echo site_url('page_error_500'); ?>">Error 500</a></li>
                            <li><a href="<?php echo site_url('page_error_503'); ?>">Error 503</a></li>
						</ul>
					</li>
					<li><a href="<?php echo site_url('page_lock_screen'); ?>">Lock Screen</a></li>
				</ul>
			</li>
		</ul>
		
		<div class="copyright">
			<p><strong>Qerza Job Portal Admin Dashboard</strong> © 2023 All Rights Reserved</p>
			<p>Made with <span class="heart"></span> by DexignZone</p>
		</div>
	</div>
</div>
<!--**********************************
	Sidebar end
***********************************-->