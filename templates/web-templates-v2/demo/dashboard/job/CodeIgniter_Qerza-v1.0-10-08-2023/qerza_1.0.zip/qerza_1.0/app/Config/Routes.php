<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override(static function () {
    echo view('components/pages/error/page-error-404');
});
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
// $routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'QerzaAdmin::index');
$routes->get('/index', 'QerzaAdmin::index');
$routes->get('/index_2', 'QerzaAdmin::index_2');
$routes->get('/search_job', 'QerzaAdmin::search_job');
$routes->get('/application', 'QerzaAdmin::application');
$routes->get('/profile', 'QerzaAdmin::profile');
$routes->get('/statistics', 'QerzaAdmin::statistics');
$routes->get('/companies', 'QerzaAdmin::companies');
/* Dashboard END */

/* Apps start */
$routes->get('/app_profile', 'QerzaAdmin::app_profile');
$routes->get('/post_details', 'QerzaAdmin::post_details');
$routes->get('/email_compose', 'QerzaAdmin::email_compose');
$routes->get('/email_inbox', 'QerzaAdmin::email_inbox');
$routes->get('/email_read', 'QerzaAdmin::email_read');
$routes->get('/app_calendar', 'QerzaAdmin::app_calendar');
$routes->get('/ecom_product_grid', 'QerzaAdmin::ecom_product_grid');
$routes->get('/ecom_product_list', 'QerzaAdmin::ecom_product_list');
$routes->get('/ecom_product_details', 'QerzaAdmin::ecom_product_details');
$routes->get('/ecom_product_order', 'QerzaAdmin::ecom_product_order');
$routes->get('/ecom_checkout', 'QerzaAdmin::ecom_checkout');
$routes->get('/ecom_invoice', 'QerzaAdmin::ecom_invoice');
$routes->get('/ecom_customers', 'QerzaAdmin::ecom_customers');
/* Apps END */


/* Charts start */
$routes->get('/flot', 'QerzaAdmin::flot');
$routes->get('/morris', 'QerzaAdmin::morris');
$routes->get('/chartjs', 'QerzaAdmin::chartjs');
$routes->get('/chartist', 'QerzaAdmin::chartist');
$routes->get('/sparkline', 'QerzaAdmin::sparkline');
$routes->get('/peity', 'QerzaAdmin::peity');
/* Charts END */


/* Components start */

/* Bootstrap start */
$routes->get('accordion', 'QerzaAdmin::accordion');
$routes->get('alert', 'QerzaAdmin::alert');
$routes->get('badge', 'QerzaAdmin::badge');
$routes->get('button', 'QerzaAdmin::button');
$routes->get('modal', 'QerzaAdmin::modal');
$routes->get('button_group', 'QerzaAdmin::button_group');
$routes->get('list_group', 'QerzaAdmin::list_group');
$routes->get('media_object', 'QerzaAdmin::media_object');
$routes->get('card', 'QerzaAdmin::card');
$routes->get('carousel', 'QerzaAdmin::carousel');
$routes->get('dropdown', 'QerzaAdmin::dropdown');
$routes->get('popover', 'QerzaAdmin::popover');
$routes->get('progressbar', 'QerzaAdmin::progressbar');
$routes->get('tab', 'QerzaAdmin::tab');
$routes->get('typography', 'QerzaAdmin::typography');
$routes->get('pagination', 'QerzaAdmin::pagination');
$routes->get('grid', 'QerzaAdmin::grid');
/* Bootstrap END */

/* Plugins start */
$routes->get('select2', 'QerzaAdmin::select2');
$routes->get('nestable', 'QerzaAdmin::nestable');
$routes->get('noui_slider', 'QerzaAdmin::noui_slider');
$routes->get('sweetalert', 'QerzaAdmin::sweetalert');
$routes->get('toastr', 'QerzaAdmin::toastr');
$routes->get('map_jqvmap', 'QerzaAdmin::map_jqvmap');
$routes->get('lightgallery', 'QerzaAdmin::lightgallery');
/* Plugins END */

/* Widget Start */
$routes->get('widget_basic', 'QerzaAdmin::widget_basic');
/* Widget END */


/* Forms start */
$routes->get('form_element', 'QerzaAdmin::form_element');
$routes->get('form_wizard', 'QerzaAdmin::form_wizard');
$routes->get('form_editor_summernote', 'QerzaAdmin::form_editor_summernote');
$routes->get('form_pickers', 'QerzaAdmin::form_pickers');
$routes->get('form_validation_jquery', 'QerzaAdmin::form_validation_jquery');
/* Forms END */

/* Table start */
$routes->get('table_bootstrap', 'QerzaAdmin::table_bootstrap');
$routes->get('table_datatable', 'QerzaAdmin::table_datatable');
/* Table END */


/* Pages start */
$routes->get('page_register', 'QerzaAdmin::page_register');
$routes->get('page_login', 'QerzaAdmin::page_login');
$routes->get('page_forgot_password', 'QerzaAdmin::page_forgot_password');
$routes->get('empty_page', 'QerzaAdmin::empty_page');
$routes->get('page_lock_screen', 'QerzaAdmin::page_lock_screen');
$routes->get('page_error_400', 'QerzaAdmin::page_error_400');
$routes->get('page_error_403', 'QerzaAdmin::page_error_403');
$routes->get('page_error_404', 'QerzaAdmin::page_error_404');
$routes->get('page_error_500', 'QerzaAdmin::page_error_500');
$routes->get('page_error_503', 'QerzaAdmin::page_error_503');

/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
