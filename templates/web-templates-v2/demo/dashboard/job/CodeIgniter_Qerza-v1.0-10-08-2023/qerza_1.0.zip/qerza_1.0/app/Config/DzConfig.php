<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class DzConfig extends BaseConfig
{
    public $dzAssets = [

		/*
		|--------------------------------------------------------------------------
		| Application Name
		|--------------------------------------------------------------------------
		|
		| This value is the name of your application. This value is used when the
		| framework needs to place the application's name in a notification or
		| any other location as required by the application or its packages.
		|
		*/

		'name' => 'QerzaAdmin Codeigniter',
		

		'public' => [
			'favicon' => 'media/img/logo/favicon.ico',
			'fonts' => [
				'google' => [
					'families' => [
						'Poppins:300,400,500,600,700',
						'Roboto:300,400,500,600,700',
					]
				]
			],
			'global' => [
				'css' => [
					'public/assets/vendor/bootstrap-select/dist/css/bootstrap-select.min.css',
					'public/assets/css/style.css',
				],
				'js' => [
					'top'=>[
						'public/assets/vendor/global/global.min.js',						
						'public/assets/vendor/bootstrap-select/dist/js/bootstrap-select.min.js',						
					],
					'bottom'=>[
						'public/assets/js/custom.min.js',
						'public/assets/js/deznav-init.js',
					],
				],
			],
			'pagelevel' => [
				'css' => [
					'QerzaAdmin_index' => [
						'public/assets/vendor/chartist/css/chartist.min.css',
						'public/assets/vendor/owl-carousel/owl.carousel.css',
					],
					'QerzaAdmin_index_2' => [
						'public/assets/vendor/chartist/css/chartist.min.css',
						'public/assets/vendor/owl-carousel/owl.carousel.css',
					],
					'QerzaAdmin_search_job' => [
					],
					'QerzaAdmin_application' => [
						'public/assets/vendor/jqvmap/css/jqvmap.min.css',
						'public/assets/vendor/chartist/css/chartist.min.css',
						'public/assets/vendor/datatables/css/jquery.dataTables.min.css',
						'public/assets/vendor/nouislider/nouislider.min.css',
					],
					'QerzaAdmin_profile' => [
						'public/assets/vendor/owl-carousel/owl.carousel.css',
					],
					'QerzaAdmin_statistics' => [
						'public/assets/vendor/datatables/css/jquery.dataTables.min.css',
						'public/assets/vendor/nouislider/nouislider.min.css',
					],
					'QerzaAdmin_companies' => [
						'public/assets/vendor/datatables/css/jquery.dataTables.min.css',
						'public/assets/vendor/nouislider/nouislider.min.css',
					],
					'QerzaAdmin_app_profile' => [
						'public/assets/vendor/lightgallery/css/lightgallery.min.css',
					],
					'QerzaAdmin_post_details' => [
						'public/assets/vendor/lightgallery/css/lightgallery.min.css',
					],					
					'QerzaAdmin_email_compose' => [
						'public/assets/vendor/dropzone/dist/dropzone.css',
					],					
					'QerzaAdmin_email_inbox' => [
					],					
					'QerzaAdmin_email_read' => [
					],					
					'QerzaAdmin_app_calendar' => [
						'public/assets/vendor/fullcalendar/css/main.min.css',
					],
					'QerzaAdmin_chartist' => [
						'public/assets/vendor/chartist/css/chartist.min.css',
					],
					'QerzaAdmin_chartjs' => [
					],
					'QerzaAdmin_flot' => [

					],
					'QerzaAdmin_morris' => [
					],
					'QerzaAdmin_peity' => [
					],
					'QerzaAdmin_sparkline' => [
					],
					'QerzaAdmin_ecom_checkout' => [
					],
					'QerzaAdmin_ecom_customers' => [
					],
					'QerzaAdmin_ecom_invoice' => [
					],
					'QerzaAdmin_ecom_product_details' => [
						'public/assets/vendor/star-rating/star-rating-svg.css',
					],
					'QerzaAdmin_ecom_product_grid' => [
						'public/assets/vendor/star-rating/star-rating-svg.css',
					],
					'QerzaAdmin_ecom_product_list' => [
						'public/assets/vendor/star-rating/star-rating-svg.css',
					],
					'QerzaAdmin_ecom_product_order' => [
					],
					'QerzaAdmin_form_editor_summernote' => [
						'public/assets/vendor/summernote/summernote.css',
					],
					'QerzaAdmin_form_element' => [
					],
					'QerzaAdmin_form_pickers' => [
						'public/assets/vendor/bootstrap-daterangepicker/daterangepicker.css',
						'public/assets/vendor/clockpicker/css/bootstrap-clockpicker.min.css',
						'public/assets/vendor/jquery-asColorPicker/css/asColorPicker.min.css',
						'public/assets/vendor/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css',
						'public/assets/vendor/pickadate/themes/default.css',
						'public/assets/vendor/pickadate/themes/default.date.css',
						'https://fonts.googleapis.com/icon?family=Material+Icons',
					],
					'QerzaAdmin_form_validation_jquery' => [
						'public/assets/vendor/jquery-validation/jquery.validate.min.js',
						'public/assets/js/plugins-init/jquery.validate-init.js',
					],
					'QerzaAdmin_form_wizard' => [
						'public/assets/vendor/jquery-smartwizard/dist/css/smart_wizard.min.css',
					],
					'QerzaAdmin_map_jqvmap' => [
						'public/assets/vendor/jqvmap/css/jqvmap.min.css',
					],
					'QerzaAdmin_table_bootstrap' => [
					],
					'QerzaAdmin_table_datatable' => [
						'public/assets/vendor/datatables/css/jquery.dataTables.min.css',
					],
					'QerzaAdmin_lightgallery' => [
						'public/assets/vendor/lightgallery/css/lightgallery.min.css',
					],
					'QerzaAdmin_nestable' => [
						'public/assets/vendor/nestable2/css/jquery.nestable.min.css',
					],
					'QerzaAdmin_noui_slider' => [
						'public/assets/vendor/nouislider/nouislider.min.css',
					],
					'QerzaAdmin_select2' => [
						'public/assets/vendor/select2/css/select2.min.css',
					],
					'QerzaAdmin_sweetalert' => [
						'public/assets/vendor/sweetalert2/dist/sweetalert2.min.css',
					],
					'QerzaAdmin_toastr' => [
						'public/assets/vendor/toastr/css/toastr.min.css',
					],
					'QerzaAdmin_accordion' => [
					],
					'QerzaAdmin_alert' => [
					],
					'QerzaAdmin_badge' => [
					],
					'QerzaAdmin_button' => [
					],
					'QerzaAdmin_button_group' => [
					],
					'QerzaAdmin_card' => [
					],
					'QerzaAdmin_carousel' => [
					],
					'QerzaAdmin_dropdown' => [
					],
					'QerzaAdmin_grid' => [
					],
					'QerzaAdmin_list_group' => [
					],
					'QerzaAdmin_media_object' => [
					],
					'QerzaAdmin_modal' => [
					],
					'QerzaAdmin_pagination' => [
					],
					'QerzaAdmin_popover' => [
					],
					'QerzaAdmin_progressbar' => [
					],
					'QerzaAdmin_tab' => [
					],
					'QerzaAdmin_typography' => [
					],
					'QerzaAdmin_widget_basic' => [
						'public/assets/vendor/chartist/css/chartist.min.css',
					],
					'QerzaAdmin_demo_modules_index' => [
					],
					'QerzaAdmin_demo_modules_add' => [
					],
					'QerzaAdmin_empty_page' => [
					],
					'QerzaAdmin_page_forgot_password' => [
					],
				],
				'js' => [
					'QerzaAdmin_index' => [
						'public/assets/vendor/chart-js/chart.bundle.min.js',
						'public/assets/vendor/owl-carousel/owl.carousel.js',
						'public/assets/vendor/peity/jquery.peity.min.js',
						'public/assets/vendor/apexchart/apexchart.js',
						'public/assets/js/dashboard/dashboard-1.js',
					],
					'QerzaAdmin_index_2' => [
						'public/assets/vendor/chart-js/chart.bundle.min.js',
						'public/assets/vendor/owl-carousel/owl.carousel.js',
						'public/assets/vendor/peity/jquery.peity.min.js',
						'public/assets/vendor/apexchart/apexchart.js',
						'public/assets/js/dashboard/dashboard-1.js',
					],
					'QerzaAdmin_search_job' => [
						'public/assets/vendor/chart-js/chart.bundle.min.js',
					],
					'QerzaAdmin_application' => [
						'public/assets/vendor/chart-js/chart.bundle.min.js',
						'public/assets/vendor/datatables/js/jquery.dataTables.min.js',
					],
					'QerzaAdmin_profile' => [
						'public/assets/vendor/chart-js/chart.bundle.min.js',
					],
					'QerzaAdmin_statistics' => [
						'public/assets/vendor/chart-js/chart.bundle.min.js',
						'public/assets/vendor/peity/jquery.peity.min.js',
						'public/assets/vendor/apexchart/apexchart.js',
						'public/assets/js/dashboard/statistics.js',
					],
					'QerzaAdmin_companies' => [
						'public/assets/vendor/chart-js/chart.bundle.min.js',
					],
					'QerzaAdmin_app_profile' => [
						'public/assets/vendor/lightgallery/js/lightgallery-all.min.js',
						'public/assets/vendor/magnific-popup/magnific-popup.js',
					],
					'QerzaAdmin_post_details' => [
						'public/assets/vendor/lightgallery/js/lightgallery-all.min.js',
					],
					'QerzaAdmin_app_calendar' => [
						'public/assets/vendor/fullcalendar/js/main.min.js',
						'public/assets/js/plugins-init/fullcalendar-init.js',
					],
					'QerzaAdmin_chartist' => [
						'public/assets/vendor/chartist/js/chartist.min.js',
						'public/assets/vendor/chartist-plugin-tooltips/js/chartist-plugin-tooltip.min.js',
						'public/assets/js/plugins-init/chartist-init.js',
					],
					'QerzaAdmin_chartjs' => [
						'public/assets/vendor/chart-js/chart.bundle.min.js',
						'public/assets/js/plugins-init/chartjs-init.js',
					],
					'QerzaAdmin_flot' => [
						'public/assets/vendor/chart-js/chart.bundle.min.js',
						'public/assets/vendor/flot/jquery.flot.js',
						'public/assets/vendor/flot/jquery.flot.pie.js',
						'public/assets/vendor/flot/jquery.flot.resize.js',
						'public/assets/vendor/flot-spline/jquery.flot.spline.min.js',
						'public/assets/js/plugins-init/flot-init.js',
					],
					'QerzaAdmin_morris' => [
						'public/assets/vendor/chart-js/chart.bundle.min.js',
						'public/assets/vendor/raphael/raphael.min.js',
						'public/assets/vendor/morris/morris.min.js',
						'public/assets/js/plugins-init/morris-init.js',
					],
					'QerzaAdmin_peity' => [
						'public/assets/vendor/chart-js/chart.bundle.min.js',
						'public/assets/vendor/peity/jquery.peity.min.js',
						'public/assets/js/plugins-init/piety-init.js',

					],
					'QerzaAdmin_sparkline' => [
						'public/assets/vendor/chart-js/chart.bundle.min.js',
						'public/assets/vendor/jquery-sparkline/jquery.sparkline.min.js',
						'public/assets/js/plugins-init/sparkline-init.js',
						'public/assets/vendor/svganimation/vivus.min.js',
						'public/assets/vendor/svganimation/svg.animation.js',
					],
					'QerzaAdmin_ecom_checkout' => [
					],
					'QerzaAdmin_ecom_customers' => [
								
					],
					'QerzaAdmin_ecom_invoice' => [
					],
					'QerzaAdmin_ecom_product_details' => [
						'public/assets/vendor/star-rating/jquery.star-rating-svg.js',
						'public/assets/vendor/owl-carousel/owl.carousel.js',
					],
					'QerzaAdmin_ecom_product_grid' => [
					],
					'QerzaAdmin_ecom_product_list' => [
						'public/assets/vendor/star-rating/jquery.star-rating-svg.js',
					],
					'QerzaAdmin_ecom_product_order' => [
					],
					'QerzaAdmin_email_compose' => [
						'public/assets/vendor/dropzone/dist/dropzone.js',
					],
					'QerzaAdmin_email_inbox' => [
					],
					'QerzaAdmin_email_read' => [
					],
					'QerzaAdmin_form_editor_summernote' => [
						'public/assets/vendor/ckeditor/ckeditor.js',
					],
					'QerzaAdmin_form_element' => [
					],
					'QerzaAdmin_form_pickers' => [
						'public/assets/vendor/moment/moment.min.js',
						'public/assets/vendor/bootstrap-daterangepicker/daterangepicker.js',
						'public/assets/vendor/clockpicker/js/bootstrap-clockpicker.min.js',
						'public/assets/vendor/jquery-asColor/jquery-asColor.min.js',
						'public/assets/vendor/jquery-asGradient/jquery-asGradient.min.js',
						'public/assets/vendor/jquery-asColorPicker/js/jquery-asColorPicker.min.js',
						'public/assets/vendor/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js',
						'public/assets/vendor/pickadate/picker.js',
						'public/assets/vendor/pickadate/picker.time.js',
						'public/assets/vendor/pickadate/picker.date.js',
						'public/assets/js/plugins-init/bs-daterange-picker-init.js',
						'public/assets/js/plugins-init/clock-picker-init.js',
						'public/assets/js/plugins-init/jquery-asColorPicker.init.js',
						'public/assets/js/plugins-init/material-date-picker-init.js',
						'public/assets/js/plugins-init/pickadate-init.js',
					],
					'QerzaAdmin_form_validation_jquery' => [
						'public/assets/vendor/jquery-validation/jquery.validate.min.js',
						'public/assets/js/plugins-init/jquery.validate-init.js',
					],
					'QerzaAdmin_form_wizard' => [
						'public/assets/vendor/jquery-steps/build/jquery.steps.min.js',
						'public/assets/vendor/jquery-validation/jquery.validate.min.js',
						'public/assets/js/plugins-init/jquery.validate-init.js',
						'public/assets/vendor/jquery-smartwizard/dist/js/jquery.smartWizard.js',
					],
					'QerzaAdmin_map_jqvmap' => [
						'public/assets/vendor/jqvmap/js/jquery.vmap.min.js',
						'public/assets/vendor/jqvmap/js/jquery.vmap.world.js',
						'public/assets/vendor/jqvmap/js/jquery.vmap.usa.js',
						'public/assets/js/plugins-init/jqvmap-init.js',
					],
					
					'QerzaAdmin_page_error_400' => [
					],
					'QerzaAdmin_page_error_403' => [
					],
					'QerzaAdmin_page_error_404' => [
					],
					'QerzaAdmin_page_error_500' => [
					],
					'QerzaAdmin_page_error_503' => [
					],
					'QerzaAdmin_empty_page' => [
					],
					'QerzaAdmin_page_lock_screen' => [
						'public/assets/vendor/deznav/deznav.min.js',
					],
					'QerzaAdmin_page_login' => [
					],
					'QerzaAdmin_page_register' => [
					],
					'QerzaAdmin_page_forgot_password' => [
					],
					'QerzaAdmin_table_bootstrap' => [
					],
					'QerzaAdmin_table_datatable' => [
						'public/assets/vendor/datatables/js/jquery.dataTables.min.js',
						'public/assets/js/plugins-init/datatables.init.js',
					],
					'QerzaAdmin_lightgallery' => [
						'public/assets/vendor/lightgallery/js/lightgallery-all.min.js',
					],
					'QerzaAdmin_nestable' => [
						'public/assets/vendor/nestable2/js/jquery.nestable.min.js',
						'public/assets/js/plugins-init/nestable-init.js',
					],
					'QerzaAdmin_noui_slider' => [
						'public/assets/vendor/nouislider/nouislider.min.js',
						'public/assets/vendor/wnumb/wNumb.js',
						'public/assets/js/plugins-init/nouislider-init.js',
					],
					'QerzaAdmin_select2' => [
						'public/assets/vendor/select2/js/select2.full.min.js',
						'public/assets/js/plugins-init/select2-init.js',
					],
					'QerzaAdmin_sweetalert' => [
						'public/assets/vendor/sweetalert2/dist/sweetalert2.min.js',
						'public/assets/js/plugins-init/sweetalert.init.js',
					],
					'QerzaAdmin_toastr' => [
						'public/assets/vendor/toastr/js/toastr.min.js',
						'public/assets/js/plugins-init/toastr-init.js',
					],
					'QerzaAdmin_accordion' => [
					],
					'QerzaAdmin_alert' => [
					],
					'QerzaAdmin_badge' => [
					],
					'QerzaAdmin_button' => [
					],
					'QerzaAdmin_button_group' => [
					],
					'QerzaAdmin_card' => [
					],
					'QerzaAdmin_carousel' => [
					],
					'QerzaAdmin_dropdown' => [
					],
					'QerzaAdmin_grid' => [
					],
					'QerzaAdmin_list_group' => [
					],
					'QerzaAdmin_media_object' => [
					],
					'QerzaAdmin_modal' => [
					],
					'QerzaAdmin_pagination' => [
					],
					'QerzaAdmin_popover' => [
					],
					'QerzaAdmin_progressbar' => [
					],
					'QerzaAdmin_tab' => [
					],
					'QerzaAdmin_typography' => [
					],
					'QerzaAdmin_widget_basic' => [
						'public/assets/vendor/chart-js/chart.bundle.min.js',
						'public/assets/vendor/apexchart/apexchart.js',
						'public/assets/vendor/chartist/js/chartist.min.js',
						'public/assets/vendor/chartist-plugin-tooltips/js/chartist-plugin-tooltip.min.js',
						'public/assets/vendor/flot/jquery.flot.js',
						'public/assets/vendor/flot/jquery.flot.pie.js',
						'public/assets/vendor/flot/jquery.flot.resize.js',
						'public/assets/vendor/flot-spline/jquery.flot.spline.min.js',
						'public/assets/vendor/jquery-sparkline/jquery.sparkline.min.js',
						'public/assets/js/plugins-init/sparkline-init.js',
						'public/assets/vendor/peity/jquery.peity.min.js',
						'public/assets/js/plugins-init/piety-init.js',
						'public/assets/js/plugins-init/widgets-script-init.js',
					],
						
				]
			],
		]
	];

}
