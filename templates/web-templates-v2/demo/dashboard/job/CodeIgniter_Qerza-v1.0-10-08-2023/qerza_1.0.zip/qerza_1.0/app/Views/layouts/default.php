<?php 
    $router     	= service('router');
    $action     	= class_basename($router->controllerName()).'_'.$router->methodName();
    $globalCss  	= config('DzConfig')->dzAssets['public']['global']['css'];
    $pageLevelCss 	= config('DzConfig')->dzAssets['public']['pagelevel']['css'][$action];
    $globalJs  		= config('DzConfig')->dzAssets['public']['global']['js'];
    $pageLevelJs 	= config('DzConfig')->dzAssets['public']['pagelevel']['js'][$action];

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="author" content="">
	<meta name="robots" content="">
	<meta name="keywords" content="job portal, admin dashboard, Bootstrap CodeIgniter template, job listings, applicants, user-friendly interface, powerful functionalities">
	<meta name="description" content="Qerza is a versatile job portal admin dashboard powered by Bootstrap and CodeIgniter Technology. Streamline job listings, applicants, and enhance your recruitment process. User-friendly interface with powerful functionalities. Job portal, admin dashboard, Bootstrap CodeIgniter template">
	<meta property="og:title" content="Qerza - Job Portal CodeIgniter Admin Dashboard Template">
	<meta property="og:description" content="Dompet is a clean-coded, responsive Codeigniter template that can be easily customised to fit the needs of various credit card and invoice, modern, creative, Transfer money, and other businesses.">
	<meta property="og:image" content="https://qerza.dexignzone.com/codeigniter/social-image.png'); ?>">
    <meta name="format-detection" content="telephone=no">
	
	<!-- Mobile Specific -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
    <!-- Favicon icon -->
	<link rel="icon" type="image/png" sizes="16x16" href="<?php echo site_url('public/assets/images/favicon.png'); ?>">	
	
	<!-- Page Title Here -->
	<title>Qerza - Job Portal CodeIgniter Admin Dashboard Template</title>

	<?php foreach($pageLevelCss as $css){
            if(strpos($css, 'http') !== false){
                $css_url = $css;    
            }else{
                $css_url = base_url($css);
            } 
        ?>	
		 <link href="<?php echo $css_url ?>" rel="stylesheet" type="text/css"/>	
	<?php } ?>
	<?php foreach($globalCss as $css){ ?>	
		 <link href="<?php echo base_url($css) ?>" rel="stylesheet" type="text/css"/>	
	<?php } ?>

	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
	
</head>
<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->
	
	
	<!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">
		<?php echo $this->include('elements/nav-header') ?>
		<?php echo $this->include('elements/chat-box') ?>
        <?php echo $this->include('elements/header') ?>
        <?php echo $this->include('elements/sidebar') ?>
        <?php echo $this->renderSection('content') ?>
        <?php echo $this->include('elements/footer') ?>
	</div>
	
<?php foreach($globalJs['top'] as $js){ ?>
	<script src="<?php echo base_url($js); ?>"></script>
<?php } ?>	
<?php foreach($pageLevelJs as $js){
	if(strpos($js, 'http') !== false){
?>
	<script src="<?php echo $js; ?>"></script>

<?php }
else{
	?>
	<script src="<?php echo base_url($js); ?>"></script>

<?php
	}
} 
?>	

<?php foreach($globalJs['bottom'] as $js){ ?>
	<script src="<?php echo base_url($js); ?>"></script>
<?php } ?>

<?php echo $this->renderSection('scripts') ?>
	
    <!--**********************************
        Main wrapper end
    ***********************************-->
</body>
</html>