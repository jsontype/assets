package com.example.dusty.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/tables")
public class Tables {

    @GetMapping("/basic")
    public String basic() {
        return "tables/basic";
    }

    @GetMapping("/datatables")
    public String datatables() {
        return "tables/datatables";
    }
    
}
    