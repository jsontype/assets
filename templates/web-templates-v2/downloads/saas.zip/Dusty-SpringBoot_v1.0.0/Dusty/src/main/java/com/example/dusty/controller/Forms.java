package com.example.dusty.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/forms")
public class Forms {

@GetMapping("/quilljs")
public String quilljs() {
    return "forms/quilljs";
}
    

@GetMapping("/advanced")
public String advanced() {
    return "forms/advanced";
}
    

@GetMapping("/validation")
public String validation() {
    return "forms/validation";
}
    

@GetMapping("/pickers")
public String pickers() {
    return "forms/pickers";
}
    

@GetMapping("/elements")
public String elements() {
    return "forms/elements";
}
    
}
    