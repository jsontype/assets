package com.example.dusty.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/ui")
public class Ui {

    @GetMapping("/typography")
    public String typography() {
        return "ui/typography";
    }
        
    @GetMapping("/pagination")
    public String pagination() {
        return "ui/pagination";
    }
        
    @GetMapping("/grid")
    public String grid() {
        return "ui/grid";
    }
        
    @GetMapping("/list")
    public String list() {
        return "ui/list";
    }
        
    @GetMapping("/accordions")
    public String accordions() {
        return "ui/accordions";
    }
        
    @GetMapping("/breadcrumb")
    public String breadcrumb() {
        return "ui/breadcrumb";
    }
        
    @GetMapping("/progress")
    public String progress() {
        return "ui/progress";
    }
        
    @GetMapping("/tabs")
    public String tabs() {
        return "ui/tabs";
    }
        
    @GetMapping("/badges")
    public String badges() {
        return "ui/badges";
    }
        
    @GetMapping("/tooltips")
    public String tooltips() {
        return "ui/tooltips";
    }
        
    @GetMapping("/placeholders")
    public String placeholders() {
        return "ui/placeholders";
    }
        
    @GetMapping("/video")
    public String video() {
        return "ui/video";
    }
        
    @GetMapping("/buttons")
    public String buttons() {
        return "ui/buttons";
    }
        
    @GetMapping("/spinners")
    public String spinners() {
        return "ui/spinners";
    }
        
    @GetMapping("/offcanvas")
    public String offcanvas() {
        return "ui/offcanvas";
    }
        
    @GetMapping("/scrollspy")
    public String scrollspy() {
        return "ui/scrollspy";
    }
        
    @GetMapping("/carousel")
    public String carousel() {
        return "ui/carousel";
    }
        
    @GetMapping("/images")
    public String images() {
        return "ui/images";
    }
        
    @GetMapping("/collapse")
    public String collapse() {
        return "ui/collapse";
    }
        
    @GetMapping("/popovers")
    public String popovers() {
        return "ui/popovers";
    }
        
    @GetMapping("/cards")
    public String cards() {
        return "ui/cards";
    }
        
    @GetMapping("/dropdowns")
    public String dropdowns() {
        return "ui/dropdowns";
    }
        
    @GetMapping("/general")
    public String general() {
        return "ui/general";
    }
        
    @GetMapping("/modals")
    public String modals() {
        return "ui/modals";
    }
        
    @GetMapping("/alerts")
    public String alerts() {
        return "ui/alerts";
    }
}
    