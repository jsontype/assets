package com.example.dusty.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/extended")
public class Extended {

    @GetMapping("/carousel")
    public String extendedCarousel() {
        return "extended/carousel";
    }

    @GetMapping("/notifications")
    public String extendedNotifications() {
        return "extended/notifications";
    }

    @GetMapping("/offcanvas")
    public String extendedOffcanvas() {
        return "extended/offcanvas";
    }

    @GetMapping("/range-slider")
    public String extendedRangeSlider() {
        return "extended/range-slider";
    }
    
}
