package com.example.dusty.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/widgets")
public class Widgets {

    @GetMapping("/widget-card")
    public String widgetCard() {
        return "widgets/widget-card";
    }

    @GetMapping("/widget-chart")
    public String widgetChart() {
        return "widgets/widget-chart";
    }
}
    