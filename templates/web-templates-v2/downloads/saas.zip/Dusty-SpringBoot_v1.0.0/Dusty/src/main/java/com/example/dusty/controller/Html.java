package com.example.dusty.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/html")
public class Html {

@GetMapping("/widget-chart")
public String widgetChart() {
    return "html/widget-chart";
}
    

@GetMapping("/widget-card")
public String widgetCard() {
    return "html/widget-card";
}
    

@GetMapping("/offline-page")
public String offlinePage() {
    return "html/offline-page";
}
    

@GetMapping("/index-dark")
public String indexDark() {
    return "html/index-dark";
}
    

@GetMapping("/extended-scrollspy")
public String extendedScrollspy() {
    return "html/extended-scrollspy";
}
    

@GetMapping("/analytics-rtl")
public String analyticsRtl() {
    return "html/analytics-rtl";
}
    

@GetMapping("/analytics-dark")
public String analyticsDark() {
    return "html/analytics-dark";
}
    

@GetMapping("/extended-range-slider")
public String extendedRangeSlider() {
    return "html/extended-range-slider";
}
    

@GetMapping("/extended-offcanvas")
public String extendedOffcanvas() {
    return "html/extended-offcanvas";
}
    

@GetMapping("/index-rtl")
public String indexRtl() {
    return "html/index-rtl";
}
    

@GetMapping("/extended-scrollbar")
public String extendedScrollbar() {
    return "html/extended-scrollbar";
}
    

@GetMapping("/preview")
public String preview() {
    return "html/preview";
}
    

@GetMapping("/analytics")
public String analytics() {
    return "html/analytics";
}
    

@GetMapping("/extended-carousel")
public String extendedCarousel() {
    return "html/extended-carousel";
}
    

@GetMapping("/extended-notifications")
public String extendedNotifications() {
    return "html/extended-notifications";
}
    

@GetMapping("/analytics-dark-rtl")
public String analyticsDarkRtl() {
    return "html/analytics-dark-rtl";
}
    

@GetMapping("")
public String index() {
    return "html/index";
}
    

@GetMapping("/index-dark-rtl")
public String indexDarkRtl() {
    return "html/index-dark-rtl";
}
    

@GetMapping("/email/verification")
public String emailVerification() {
    return "html/email/verification";
}
    

@GetMapping("/partials/head-css")
public String partialsHeadCss() {
    return "html/partials/head-css";
}
    

@GetMapping("/partials/title-meta")
public String partialsTitleMeta() {
    return "html/partials/title-meta";
}
    

@GetMapping("/partials/vendor")
public String partialsVendor() {
    return "html/partials/vendor";
}
    

@GetMapping("/partials/sidebar")
public String partialsSidebar() {
    return "html/partials/sidebar";
}
    

@GetMapping("/partials/body")
public String partialsBody() {
    return "html/partials/body";
}
    

@GetMapping("/partials/menu")
public String partialsMenu() {
    return "html/partials/menu";
}
    

@GetMapping("/partials/footer")
public String partialsFooter() {
    return "html/partials/footer";
}
    

@GetMapping("/partials/topbar")
public String partialsTopbar() {
    return "html/partials/topbar";
}
    

@GetMapping("/tables/datatables")
public String tablesDatatables() {
    return "html/tables/datatables";
}
    

@GetMapping("/tables/basic")
public String tablesBasic() {
    return "html/tables/basic";
}

@GetMapping("/apps/contacts")
public String appsContacts() {
    return "html/apps/contacts";
}
    

@GetMapping("/apps/todolist")
public String appsTodolist() {
    return "html/apps/todolist";
}
    

@GetMapping("/apps/calendar")
public String appsCalendar() {
    return "html/apps/calendar";
}
    

@GetMapping("/contacts/profile")
public String contactsProfile() {
    return "html/contacts/profile";
}
    
}
    