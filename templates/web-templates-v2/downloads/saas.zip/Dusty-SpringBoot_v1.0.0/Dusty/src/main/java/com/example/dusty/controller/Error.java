package com.example.dusty.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/error")
public class Error {

    @GetMapping("/500")
    public String error500() {
        return "error/500";
    }
        
    @GetMapping("/503")
    public String error503() {
        return "error/503";
    }

    @GetMapping("/404")
    public String error404() {
        return "error/404";
    }
        
    @GetMapping("/429")
    public String error429() {
        return "error/429";
    }

    @GetMapping("/offline-page")
    public String offlinePage() {
        return "error/offline-page";
    }
}