package com.example.dusty.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/layouts")
public class Layouts {

    @GetMapping("/analytics-dark")
    public String analyticsDark() {
        return "layouts/analytics-dark";
    }
        
    @GetMapping("/analytics-dark-rtl")
    public String analyticsDarkRTL() {
        return "layouts/analytics-dark-rtl";
    }

    @GetMapping("/analytics-rtl")
    public String analyticsRTL() {
        return "layouts/analytics-rtl";
    }

    @GetMapping("/analytics")
    public String analytics() {
        return "layouts/analytics";
    }

    @GetMapping("/index-dark-rtl")
    public String indexDarkRTL() {
        return "layouts/index-dark-rtl";
    }

    @GetMapping("/index-dark")
    public String indexDark() {
        return "layouts/index-dark";
    }

    @GetMapping("/index-rtl")
    public String indexRTL() {
        return "layouts/index-rtl";
    }
}
    