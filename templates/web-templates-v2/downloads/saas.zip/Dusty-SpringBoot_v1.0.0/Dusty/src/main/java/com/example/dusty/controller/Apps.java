package com.example.dusty.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/apps")
public class Apps {

    @GetMapping("/calendar")
    public String calendar() {
        return "apps/calendar";
    }
        

    @GetMapping("/contacts")
    public String contacts() {
        return "apps/contacts";
    }
        

    @GetMapping("/todolist")
    public String todolist() {
        return "apps/todolist";
    }

}
    