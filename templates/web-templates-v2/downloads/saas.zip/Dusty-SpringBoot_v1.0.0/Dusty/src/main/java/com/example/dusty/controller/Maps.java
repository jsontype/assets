package com.example.dusty.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/maps")
public class Maps {
    
    @GetMapping("/vector")
    public String vector() {
        return "maps/vector";
    }
    
    @GetMapping("/google")
    public String google() {
        return "maps/google";
    }
}
    