package com.example.dusty.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/pages")
public class Pages {
    @GetMapping("/faqs")
    public String faqs() {
        return "pages/faqs";
    }

    @GetMapping("/timeline")
    public String timeline() {
        return "pages/timeline";
    }
        
    @GetMapping("/invoice")
    public String invoice() {
        return "pages/invoice";
    }
        
    @GetMapping("/starter")
    public String starter() {
        return "pages/starter";
    }
        
    @GetMapping("/coming-soon")
    public String comingSoon() {
        return "pages/coming-soon";
    }

    @GetMapping("/pricing")
    public String pricing() {
        return "pages/pricing";
    }

    @GetMapping("/maintenance")
    public String maintenance() {
        return "pages/maintenance";
    }
        
    @GetMapping("/gallery")
    public String gallery() {
        return "pages/gallery";
    }

    @GetMapping("/contacts-profile")
    public String contactsProfile() {
        return "pages/contacts-profile";
    }

    @GetMapping("/profile")
    public String profile() {
        return "pages/profile";
    }

    @GetMapping("/offline-page")
    public String offlinePage() {
        return "pages/offline-page";
    }
}
    