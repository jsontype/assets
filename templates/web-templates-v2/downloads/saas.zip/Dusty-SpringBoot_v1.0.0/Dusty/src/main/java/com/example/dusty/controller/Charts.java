package com.example.dusty.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/charts")
public class Charts {

    @GetMapping("/rangearea")
    public String chartsRangearea() {
        return "charts/rangearea";
    }

    @GetMapping("/flot")
    public String chartsFlot() {
        return "charts/flot";
    }   

    @GetMapping("/area")
    public String chartsArea() {
        return "charts/area";
    }
        
    @GetMapping("/bar")
    public String chartsBar() {
        return "charts/bar";
    }
        
    @GetMapping("/chartjs")
    public String chartsChartjs() {
        return "charts/chartjs";
    }
        
    @GetMapping("/radialbar")
    public String chartsRadialbar() {
        return "charts/radialbar";
    }
        
    @GetMapping("/chartist")
    public String chartsChartist() {
        return "charts/chartist";
    }
        
    @GetMapping("/timeline")
    public String chartsTimeline() {
        return "charts/timeline";
    }
        
    @GetMapping("/funnel")
    public String chartsFunnel() {
        return "charts/funnel";
    }
        
    @GetMapping("/polararea")
    public String chartsPolararea() {
        return "charts/polararea";
    }
        
    @GetMapping("/scatter")
    public String chartsScatter() {
        return "charts/scatter";
    }
        
    @GetMapping("/bubble")
    public String chartsBubble() {
        return "charts/bubble";
    }
        
    @GetMapping("/treemap")
    public String chartsTreemap() {
        return "charts/treemap";
    }
        
    @GetMapping("/pie")
    public String chartsPie() {
        return "charts/pie";
    }
        
    @GetMapping("/column")
    public String chartsColumn() {
        return "charts/column";
    }
        
    @GetMapping("/line")
    public String chartsLine() {
        return "charts/line";
    }
        
    @GetMapping("/boxplot")
    public String chartsBoxplot() {
        return "charts/boxplot";
    }
        
    @GetMapping("/mixed")
    public String chartsMixed() {
        return "charts/mixed";
    }
        
    @GetMapping("/radar")
    public String chartsRadar() {
        return "charts/radar";
    }
        
    @GetMapping("/sparklines")
    public String chartsSparklines() {
        return "charts/sparklines";
    }
        
    @GetMapping("/candlestick")
    public String chartsCandlestick() {
        return "charts/candlestick";
    }
        
    @GetMapping("/heatmap")
    public String chartsHeatmap() {
        return "charts/heatmap";
    }
        
    @GetMapping("/morris")
    public String chartsMorris() {
        return "charts/morris";
    }
}
    