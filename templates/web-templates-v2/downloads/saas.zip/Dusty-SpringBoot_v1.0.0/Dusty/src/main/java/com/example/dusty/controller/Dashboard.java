package com.example.dusty.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Dashboard {

    @GetMapping("/")
    public String index() {
        return "dashboard/index";
    }
    
    @GetMapping("/dashboard/analytics")
    public String analytics() {
        return "dashboard/analytics";
    }

}
