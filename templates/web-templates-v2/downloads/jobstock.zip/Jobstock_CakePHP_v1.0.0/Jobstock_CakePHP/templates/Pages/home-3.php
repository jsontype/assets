<?php
$this->assign('title', 'Home-3 Page');
?>

<!-- Include Navbar -->
<?= $this->element('navbar2') ?>
			
<!-- Hero Banner Start -->
<div class="image-cover hero-header" style="background:#016551 url(<?= $this->Url->build('/assets/img/new-banner.jpg'); ?>) no-repeat;" data-overlay="5">
	<div class="container">

		<div class="inner-banner-text text-center">
			<h1 class="text-capitalize">Find the great exciting &<br>remote-friendly jobs</h1>
			<p class="fs-5">Getting a new job is never easy. Check what new jobs we have in store for you on JobStock.</p>
		</div>
		
		<div class="full-search-2 mt-5">
			<div class="hero-search-content search-shadow">
				
				<div class="row classic-search-box m-0 gx-2">
						
					<div class="col-xl-3 col-lg-3 col-md-12 col-sm-12">
						<div class="form-group briod">
							<div class="input-with-icon">
								<input type="text" class="form-control" placeholder="Skills, Designations, Keyword">
								<i class="fa-solid fa-magnifying-glass text-main"></i>
							</div>
						</div>
					</div>
					<div class="col-xl-3 col-lg-3 col-md-12 col-sm-12">
						<div class="form-group briod">
							<div class="input-with-icon">
								<select class="form-control">
									<option value="1">Job Category</option>
									<option value="2">Accounting & Finance</option>
									<option value="3">Automotive Jobs</option>
									<option value="4">Business Services</option>
									<option value="5">Education Training</option>
									<option value="6">Software Application</option>
									<option value="7">Restaurant & Food</option>
									<option value="8">Healthcare</option>
									<option value="9">Transportation</option>
									<option value="10">Telecommunications</option>
								</select>
								<i class="fa-solid fa-briefcase text-main"></i>
							</div>
						</div>
					</div>
					<div class="col-xl-3 col-lg-3 col-md-12 col-sm-12">
						<div class="form-group">
							<div class="input-with-icon">
								<select class="form-control">
									<option value="1">Select City</option>
									<option value="2">Huntingdon</option>
									<option value="3">Fenland</option>
									<option value="4">United State</option>
									<option value="5">United Kingdom</option>
									<option value="6">California</option>
									<option value="7">Canada</option>
									<option value="8">New York</option>
								</select>
								<i class="fa-solid fa-location-crosshairs text-main"></i>
							</div>
						</div>
					</div>
					<div class="col-xl-3 col-lg-3 col-md-12 col-sm-12">
						<div class="fliox-search-wiop">
							<div class="form-group me-2">
								<a href="JavaScript:Void(0);" data-bs-toggle="modal" data-bs-target="#filter" class="btn btn-filter-search"><i class="fa-solid fa-filter"></i>Filter</a>
							</div>
							<div class="form-group">
								<button type="submit" class="btn btn-main full-width">Search</button>
							</div>
						</div>
					</div>
							
				</div>
				
			</div>
		</div>
			
	</div>
</div>
<!-- Hero Banner End -->

<!-- Explore Categories Start -->
<section>
	<div class="container">
		
		<div class="row justify-content-center">
			<div class="col-xl-6 col-lg-7 col-md-10 text-center">
				<div class="sec-heading center">
					<h2>Explore Best Categories</h2>
					<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores</p>
				</div>
			</div>
		</div>
		
		<div class="row gx-4 gy-4 justify-content-center">
				
			<!-- templates/element/Home/index/categories.php -->
            <?= $this->element('Home/index/categories'); ?>
			
		</div>
		
	</div>	
</section>
<!-- Explore Categories End -->

<!-- Hire Box Start -->
<section class="p-0">
	<div class="container-fluid px-0">
		<div class="row gx-0">
		
			<div class="col-xl-6 col-lg-6 col-md-12 bg-dark">
				<div class="hired-box-slack">
					<div class="hired-box-caption">
						<h2 class="text-light">Hire talents & experts for your web development</h2>
						<p class="text-light fw-light opacity-75">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo</p>
					</div>
					<div class="hired-box-btns">
						<a href="#" class="btn btn-lg btn-main font--bold px-5">Hire Talents</a>
					</div>
				</div>
			</div>
			
			<div class="col-xl-6 col-lg-6 col-md-12 bg-main">
				<div class="hired-box-slack">
					<div class="hired-box-caption">
						<h2 class="text-light">We Are Expert In Web design and development</h2>
						<p class="text-light fw-light opacity-75">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo</p>
					</div>
					<div class="hired-box-btns">
						<a href="#" class="btn btn-lg btn-dark font--bold px-5">Hire Our Team</a>
					</div>
				</div>
			</div>
			
		</div>
	</div>
</section>
<!-- Hire Box End -->

<!-- Featured Jobs Start -->
<section>
	<div class="container">
		
		<div class="row justify-content-center">
			<div class="col-xl-6 col-lg-7 col-md-10 text-center">
				<div class="sec-heading center">
					<h2>Featured Jobs</h2>
					<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores</p>
				</div>
			</div>
		</div>
		
		<div class="row justify-content-center gx-xl-3 gx-3 gy-4">
		
			<!-- templates/element/Home/home-3/jobs3.php -->
            <?= $this->element('Home/home-3/jobs3'); ?>
			
		</div>
		
	</div>
</section>
<!-- Featured Jobs End -->

<!-- Hire Experts Start -->
<section class="gray-simple">
	<div class="container">
	
		<div class="row justify-content-center">
			<div class="col-xl-6 col-lg-7 col-md-10 text-center">
				<div class="sec-heading center">
					<h2>Hire Talents & Experts</h2>
					<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores</p>
				</div>
			</div>
		</div>
	
		<div class="row justify-content-center gx-4 gy-4">
		
			<!-- templates/element/Home/home-2/candidate.php -->
            <?= $this->element('Home/home-2/candidate'); ?>
			
		</div>
		
	</div>		
</section>
<!-- Hire Experts End -->

<!-- Valuable Step Start -->
<section>
	<div class="container">
		
		<div class="row justify-content-center">
			<div class="col-xl-6 col-lg-7 col-md-10 text-center">
				<div class="sec-heading center">
					<h2>Steps Our Working Process</h2>
					<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores</p>
				</div>
			</div>
		</div>
		
		<div class="row align-items-center gx-4 gy-4">
		
			<!-- templates/element/Home/home-3/process.php -->
            <?= $this->element('Home/home-3/process'); ?>
			
		</div>
		
	</div>
</section>
<!-- Valuable Step End -->

<!-- templates/element/Home/index/video.php -->
<?= $this->element('Home/index/video'); ?>			

<!-- Good Reviews By Customers -->
<section>
	<div class="container">
	
		<div class="row justify-content-center">
			<div class="col-lg-7 col-md-10 text-center">
				<div class="sec-heading center">
					<h2>Good Reviews By Customers</h2>
					<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores</p>
				</div>
			</div>
		</div>
		
		<div class="row justify-content-center gx-4 gy-4">
			
			<!-- templates/element/Home/index/reviews.php -->
			<?= $this->element('Home/index/reviews'); ?>
			
		</div>
		
	</div>	
</section>
<!-- Good Reviews By Customers -->

<!-- templates/element/Home/home-3/find.php -->
<?= $this->element('Home/home-3/find'); ?>
						
<!-- templates/element/Home/index/log.php -->
<?= $this->element('Home/index/log'); ?>
			
<!-- templates/element/Home/home-3/filter.php -->
<?= $this->element('Home/home-3/filter'); ?>
	
<!-- Include Footer -->
<?= $this->element('footer4') ?>