<?php
$this->assign('title', 'Blog Page');
?>

<!-- Include Navbar -->
<?= $this->element('navbar2') ?>

<!-- Page Title Start -->
<section class="bg-cover bg-second" style="background:url(<?= $this->Url->build('/assets/img/bg2.png'); ?>)no-repeat;">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				
				<h2 class="ipt-title text-light">Our Latest Updates</h2>
				<span class="ipn-subtitle text-light opacity-75">Get all latest news and updates</span>
				
			</div>
		</div>
	</div>
</section>
<!-- Page Title End -->

<!-- Blog List Start -->
<section class="gray-simple">
	<div class="container">
	
		<!-- row Start -->
		<div class="row gx-4 gy-4">
		
			<!-- templates/element/Pages/blog2.php -->
            <?= $this->element('Pages/blog2'); ?>
			
		</div>
		<!-- /row -->

		<!-- templates/element/For-Candidate/Browse-Jobs/grid-style-1/pagination.php -->
        <?= $this->element('For-Candidate/Browse-Jobs/grid-style-1/pagination'); ?>			
		
	</div>	
</section>
<!-- Blog List End -->
			
<!-- templates/element/Home/home-4/find2.php -->
<?= $this->element('Home/home-4/find2'); ?>
			
<!-- templates/element/Home/index/log.php -->
<?= $this->element('Home/index/log'); ?>

<!-- Include Footer -->
<?= $this->element('footer2') ?>