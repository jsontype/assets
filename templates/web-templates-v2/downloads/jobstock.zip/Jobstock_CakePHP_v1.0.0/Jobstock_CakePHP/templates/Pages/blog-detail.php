<?php
$this->assign('title', 'Blog-Detail Page');
?>

<!-- Include Navbar -->
<?= $this->element('navbar2') ?>
			
<!-- Page Title Start -->
<div class="page-bg">
	<div class="blog-thumb d-lg-flex justify-content-lg-center"><img src="<?= !empty($article['img']) ? $this->Url->build('/' . $article['img']) : $this->Url->build('/assets/img/slider-5.jpg') ?>" class="img-fluid" alt=""></div>
</div>
<!-- Page Title End -->

<!-- Agency List Start -->
<section class="gray-simple">

	<div class="container">
	
		<!-- row Start -->
		<div class="row">
		
			<!-- Blog Detail -->
			<div class="col-lg-8 col-md-12 col-sm-12 col-12">
				<div class="blog-details single-post-item format-standard mb-4">
					<div class="post-details">
						
						<div class="post-top-meta mb-2">
							<span class="pst-cats label text-success bg-success bg-opacity-05 me-2">Updates</span>
							<span class="pst-date label text-danger bg-danger bg-opacity-05">
								<?php if (!empty($article['date'])): ?>
									<?= h($article['date']) ?>
								<?php else: ?>
									17 Feb 2026
								<?php endif; ?>
							</span>
						</div>
						<h3 class="post-title lh-base">
							<?php if (!empty($article['title'])): ?>
								<?= h($article['title']) ?>
							<?php else: ?>
								Why People Like JobStock & It's Team Managing?
							<?php endif; ?>
						</h3>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut 
							labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem. <br><br> Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem.</p>
						<div class="alert alert-success">
							<span class="icon"><i class="fas fa-quote-left"></i></span>
							<p class="text">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
								tem
							ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud ullamco laboris nisi ut aliquip ex ea commodo onsequat.</p>
							<h5 class="name">- Rosalina Pong</h5>
						</div>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
							incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
							exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure
							dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
							Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt
							mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit
							voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo
							inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim
							ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur
							magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui
							dolorem. <br><br>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum
							dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
							culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis
							iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam,
							eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt
							explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit,
							sed quia consequuntur magni dolores eos qui ratione voluptatem.</p>
						<div class="post-bottom-meta">
							<div class="post-tags">
								<h4 class="pbm-title">Related Tags</h4>
								<ul class="list">
									<li><a href="#">organic</a></li>
									<li><a href="#">Foods</a></li>
									<li><a href="#">tasty</a></li>
								</ul>
							</div>
						</div>
					</div>
					
					<div class="pst-foot-roiu">								
						<div class="post-share">
							<ul class="list">
								<li><i class="fa-solid fa-share-nodes"></i></li>
								<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
								<li><a href="#"><i class="fab fa-twitter"></i></a></li>
								<li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
								<li><a href="#"><i class="fab fa-vk"></i></a></li>
								<li><a href="#"><i class="fab fa-tumblr"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
				
				<!-- Blog Comment -->
				<div class="blog-details single-post-item format-standard">
					<div class="post-details">
					
						<div class="comment-area">
							<div class="all-comments">
								<h3 class="comments-title">05 Comments</h3>
								<div class="comment-list">
									<ul>
										
										<!-- templates/element/Pages/comments.php -->
            							<?= $this->element('Pages/comments'); ?>

									</ul>
								</div>
							</div>
							<div class="comment-box submit-form">
								<h3 class="reply-title">Post Comment</h3>
								<div class="comment-form">
									<form action="#">
										<div class="row">
											<div class="col-lg-6 col-md-6 col-sm-12">
												<div class="form-group">
													<input type="text" class="form-control" placeholder="Your Name">
												</div>
											</div>
											<div class="col-lg-6 col-md-6 col-sm-12">
												<div class="form-group">
													<input type="text" class="form-control" placeholder="Your Email">
												</div>
											</div>
											<div class="col-lg-12 col-md-12 col-sm-12">
												<div class="form-group">
													<textarea name="comment" class="form-control" cols="30" rows="6" placeholder="Type your comments...."></textarea>
												</div>
											</div>
											<div class="col-lg-12 col-md-12 col-sm-12">
												<div class="form-group">
													<a href="#" class="btn btn-main px-5">Submit Now</a>
												</div>
											</div>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
			
			<!-- Contact Author -->
			<div class="col-lg-4 col-md-12 col-sm-12 col-12">
				<div class="pg-side-groups">
					
					<!-- templates/element/Pages/author.php -->
            		<?= $this->element('Pages/author'); ?>
				
				</div>
			</div>
			
		</div>
		<!-- /row -->					
		
	</div>
			
</section>
<!-- Contact Author End -->
			
<!-- templates/element/Home/home-4/find2.php -->
<?= $this->element('Home/home-4/find2'); ?>
				
<!-- templates/element/Home/index/log.php -->
<?= $this->element('Home/index/log'); ?>

<!-- Include Footer -->
<?= $this->element('footer2') ?>