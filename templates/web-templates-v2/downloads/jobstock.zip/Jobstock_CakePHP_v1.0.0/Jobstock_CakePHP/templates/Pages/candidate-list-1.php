<?php
$this->assign('title', 'Candidate-List-1 Page');
?>

<!-- Include Navbar -->
<?= $this->element('navbar5') ?>
			
<!-- Page Title Start -->
<div class="page-title bg-main" style="background:url(<?= $this->Url->build('/assets/img/bg2.png'); ?>) no-repeat;">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				
				<h2 class="ipt-title">Candidate List Style 01</h2>
				<div class="breadcrumbs light">
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="JavaScript:Void(0);">Home</a></li>
							<li class="breadcrumb-item"><a href="JavaScript:Void(0);">Candidate</a></li>
							<li class="breadcrumb-item active" aria-current="page">Candidate List 01</li>
						</ol>
					</nav>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Page Title End -->

<!-- All List Wrap -->
<section>
	<div class="container">
		<div class="row">
		
			<!-- Search Sidebar -->
			<div class="col-xxl-3 col-xl-4 col-lg-4 col-md-12 col-sm-12">
				<div class="side-widget-blocks">							
				
					<!-- templates/element/For-Candidate/Browse-Jobs/grid-style-1/search.php -->
            		<?= $this->element('For-Candidate/Browse-Jobs/grid-style-1/search'); ?>
											
					<!-- templates/element/For-Candidate/Browse-Jobs/list-style-1/property2.php -->
            		<?= $this->element('For-Candidate/Browse-Jobs/list-style-1/property2'); ?>

				</div>							
			</div>
			<!-- Sidebar End -->
			
			<!-- Job List Wrap -->
			<div class="col-xxl-9 col-xl-8 col-lg-8 col-md-12 col-sm-12">
				<!-- Shorting Box -->
				<div class="row justify-content-center mb-4">
					<div class="col-lg-12 col-md-12">
							
						<!-- templates/element/For-Candidate/Browse-Jobs/grid-style-1/results.php -->
            			<?= $this->element('For-Candidate/Browse-Jobs/grid-style-1/results'); ?>

					</div>
				</div>
				<!-- Shorting Wrap End -->
				
				<!-- Start All List -->
				<div class="row justify-content-start gx-3 gy-4">

					<!-- templates/element/For-Candidate/Browse-Candidate/candidate-list-1/candidate5.php -->
            		<?= $this->element('For-Candidate/Browse-Candidate/candidate-list-1/candidate5'); ?>
					
				</div>
				<!-- End All Job List -->
				
				<!-- templates/element/For-Candidate/Browse-Jobs/grid-style-1/pagination.php -->
            	<?= $this->element('For-Candidate/Browse-Jobs/grid-style-1/pagination'); ?>
		
			</div>
			<!-- Job List Wrap End-->
			
		</div>
	</div>		
</section>
<!-- All List Wrap -->
			
<!-- templates/element/Home/home-4/find2.php -->
<?= $this->element('Home/home-4/find2'); ?>
		
<!-- templates/element/Home/index/log.php -->
<?= $this->element('Home/index/log'); ?>

<!-- templates/element/Home/home-3/filter.php -->
<?= $this->element('Home/home-3/filter'); ?>
	
<!-- Include Footer -->
<?= $this->element('footer2') ?>