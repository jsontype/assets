<?php
$this->assign('title', 'Candidate-Messages Page');
?>

<!-- Include Navbar -->
<?= $this->element('navbar7') ?>

<!-- dashboard Detail -->
<div class="dashboard-wrap bg-light">
	<a class="mobNavigation" data-bs-toggle="collapse" href="#MobNav" role="button" aria-expanded="false" aria-controls="MobNav">
		<i class="fas fa-bars mr-2"></i>Dashboard Navigation
	</a>
		<div class="collapse" id="MobNav">
		<div class="dashboard-nav">
		<div class="dash-user-blocks pt-5">
				<div class="jbs-grid-usrs-thumb">
					<div class="jbs-grid-yuo">
						<a href="<?= $this->Url->build('/candidate-detail'); ?>"><figure><img src="<?= $this->Url->build('/assets/img/user-5.png'); ?>" class="img-fluid circle" alt=""></figure></a>
					</div>
				</div>
				<div class="jbs-grid-usrs-caption mb-3">
					<div class="jbs-kioyer">
						<div class="jbs-kioyer-groups">
							<span class="fa-solid fa-star active"></span>
							<span class="fa-solid fa-star active"></span>
							<span class="fa-solid fa-star active"></span>
							<span class="fa-solid fa-star active"></span>
							<span class="fa-solid fa-star"></span>
							<span class="aal-reveis">4.7</span>
						</div>
					</div>
					<div class="jbs-tiosk">
						<h4 class="jbs-tiosk-title"><a href="<?= $this->Url->build('/candidate-detail'); ?>">Linda D. Strong</a></h4>
						<div class="jbs-tiosk-subtitle"><span>Front-End Developer</span></div>
					</div>
				</div>
			</div>
			<div class="dashboard-inner">
				<ul data-submenu-title="Main Navigation">
					<li><a href="<?= $this->Url->build('/candidate-dashboard'); ?>"><i class="fa-solid fa-gauge-high me-2"></i>User Dashboard</a></li>
					<li><a href="<?= $this->Url->build('/candidate-profile'); ?>"><i class="fa-regular fa-user me-2"></i>My Profile </a></li>
					<li><a href="<?= $this->Url->build('/candidate-resume'); ?>"><i class="fa-solid fa-file-pdf me-2"></i>My Resumes</a></li>
					<li><a href="<?= $this->Url->build('/candidate-applied-jobs'); ?>"><i class="fa-regular fa-paper-plane me-2"></i>Applied jobs</a></li>
					<li><a href="<?= $this->Url->build('/candidate-alert-job'); ?>"><i class="fa-solid fa-bell me-2"></i>Alert Jobs<span class="count-tag bg-warning">4</span></a></li>
					<li><a href="<?= $this->Url->build('/candidate-saved-jobs'); ?>"><i class="fa-solid fa-bookmark me-2"></i>Shortlist Jobs</a></li>
					<li><a href="<?= $this->Url->build('/candidate-follow-employers'); ?>"><i class="fa-solid fa-user-clock me-2"></i>Following Employers</a></li>
					<li class="active"><a href="<?= $this->Url->build('/candidate-messages'); ?>"><i class="fa-solid fa-comments me-2"></i>Messages<span class="count-tag">4</span></a></li>
					<li><a href="<?= $this->Url->build('/candidate-change-password'); ?>"><i class="fa-solid fa-unlock-keyhole me-2"></i>Change Password</a></li>
					<li><a href="<?= $this->Url->build('/candidate-delete-account'); ?>"><i class="fa-solid fa-trash-can me-2"></i>Delete Account</a></li>
					<li><a href="<?= $this->Url->build('/'); ?>"><i class="fa-solid fa-power-off me-2"></i>Log Out</a></li>
				</ul>
			</div>					
		</div>
	</div>
	
	<div class="dashboard-content">
		<div class="dashboard-tlbar d-block mb-4">
			<div class="row">
				<div class="colxl-12 col-lg-12 col-md-12">
					<h1 class="mb-1 fs-3 fw-medium">Message Inbox</h1>
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item text-muted"><a href="#">Candidate</a></li>
							<li class="breadcrumb-item text-muted"><a href="#">Dashboard</a></li>
							<li class="breadcrumb-item"><a href="#" class="text-main">Chat & Messages</a></li>
						</ol>
					</nav>
				</div>
			</div>
		</div>
		
		<div class="dashboard-widg-bar d-block">
			
			<!-- Convershion -->
			<div class="messages-container margin-top-0">
				<div class="messages-headline">
					<h4>Connor Griffin</h4>
					<a href="#" class="message-action"><i class="ti-trash"></i> Delete Conversation</a>
				</div>

				<div class="messages-container-inner">

					<!-- Messages -->
					<div class="dash-msg-inbox">
						<ul>
							
							<!-- templates/element/For-Candidate/candidate-dashboard/messages.php -->
            				<?= $this->element('For-Candidate/candidate-dashboard/messages'); ?>

						</ul>
					</div>
					<!-- Messages / End -->

					<!-- Message Content -->
					<div class="dash-msg-content">

						<!-- templates/element/For-Candidate/candidate-dashboard/msg.php -->
            			<?= $this->element('For-Candidate/candidate-dashboard/msg'); ?>

						<!-- Reply Area -->
						<div class="clearfix"></div>
						<div class="message-reply">
							<textarea cols="40" rows="3" class="form-control with-light" placeholder="Your Message"></textarea>
							<button type="submit" class="btn btn-main">Send Message</button>
						</div>
						
					</div>
					<!-- Message Content -->

				</div>

			</div>

		</div>
		
		<!-- footer -->
		<div class="row">
			<div class="col-md-12">
				<div class="py-3 text-center">© <script>document.write(new Date().getFullYear())</script> JobStock. Develop with <i class="mdi mdi-heart text-danger"></i> by <a href="https://shreethemes.in" target="_blank" class="text-reset">Shreethemes</a>.</div>
			</div>
		</div>

	</div>				
	
</div>
<!-- dashboard Detail End -->

<!-- templates/element/For-Candidate/candidate-dashboard/files.php -->
<?= $this->element('For-Candidate/candidate-dashboard/files'); ?>