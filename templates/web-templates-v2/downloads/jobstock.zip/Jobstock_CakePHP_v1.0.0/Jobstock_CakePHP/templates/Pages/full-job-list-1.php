<?php
$this->assign('title', 'Full-Job-List-1 Page');
?>

<!-- Include Navbar -->
<?= $this->element('navbar5') ?>

<!-- Page Title Start -->
<div class="page-title bg-main" style="background:url(<?= $this->Url->build('/assets/img/bg2.png'); ?>) no-repeat;">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				
				<div class="full-search-2">
					<div class="hero-search-content search-shadow">
							
						<!-- templates/element/For-Candidate/Browse-Jobs/full-job-grid-1/full-search.php -->
            			<?= $this->element('For-Candidate/Browse-Jobs/full-job-grid-1/full-search'); ?>
					
					</div>
				</div>
		
			</div>
		</div>
	</div>
</div>
<!-- Page Title End -->

<!-- All List Wrap -->
<section>
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12">
			
				<!-- Shorting Box -->
				<div class="row justify-content-center mb-5">
					<div class="col-lg-12 col-md-12">
							
						<!-- templates/element/For-Candidate/Browse-Jobs/grid-style-1/results.php -->
            			<?= $this->element('For-Candidate/Browse-Jobs/grid-style-1/results'); ?>

					</div>
				</div>
				<!-- Shorting Wrap End -->
				
				<!-- Start All List -->
				<div class="row justify-content-start gx-3 gy-4">

					<!-- templates/element/For-Candidate/Browse-Jobs/full-job-list-1/jobs15.php -->
            		<?= $this->element('For-Candidate/Browse-Jobs/full-job-list-1/jobs15'); ?>
					
				</div>
				<!-- End All Job List -->
				
				<!-- templates/element/For-Candidate/Browse-Jobs/grid-style-1/pagination.php -->
            	<?= $this->element('For-Candidate/Browse-Jobs/grid-style-1/pagination'); ?>

			</div>
			
		</div>
	</div>		
</section>
<!-- All List Wrap -->
			
<!-- templates/element/Home/home-4/find2.php -->
<?= $this->element('Home/home-4/find2'); ?>

<!-- templates/element/Home/index/log.php -->
<?= $this->element('Home/index/log'); ?>
			
<!-- templates/element/Home/home-3/filter.php -->
<?= $this->element('Home/home-3/filter'); ?>

<!-- Include Footer -->
<?= $this->element('footer2') ?>