<?php
$this->assign('title', 'Full-Job-List-2 Page');
?>

<!-- Include Navbar -->
<?= $this->element('navbar2') ?>

<!-- Page Title Start -->
<div class="page-title bg-second" style="background:url(<?= $this->Url->build('/assets/img/bg2.png'); ?>) no-repeat;">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				
				<div class="full-search-2">
					<div class="hero-search-content search-shadow">
						
						<!-- templates/element/For-Candidate/Browse-Jobs/full-job-grid-1/full-search.php -->
            			<?= $this->element('For-Candidate/Browse-Jobs/full-job-grid-1/full-search'); ?>
					
					</div>
				</div>
		
			</div>
		</div>
	</div>
</div>
<!-- Page Title End -->

<!-- All List Wrap -->
<section>
	<div class="container">
		<div class="row">
		
			<!-- Search Sidebar -->
			<div class="col-lg-3 col-md-12 col-sm-12">
				<div class="side-widget-blocks">							
				
					<!-- templates/element/For-Candidate/Browse-Jobs/grid-style-1/search.php -->
            		<?= $this->element('For-Candidate/Browse-Jobs/grid-style-1/search'); ?>
												
					<!-- templates/element/For-Candidate/Browse-Jobs/list-style-1/property2.php -->
            		<?= $this->element('For-Candidate/Browse-Jobs/list-style-1/property2'); ?>

				</div>							
			</div>
			<!-- Sidebar End -->
			
			<!-- Job List Wrap -->
			<div class="col-lg-9 col-md-12 col-sm-12">
				<!-- Job Alert Box -->
				<div class="row justify-content-center">
				
					<!-- templates/element/For-Candidate/Browse-Jobs/list-style-1/alert2.php -->
            		<?= $this->element('For-Candidate/Browse-Jobs/list-style-1/alert2'); ?>
					
				</div>
				<!-- Job Alert Box End -->
				
				<!-- Shorting Box -->
				<div class="row justify-content-center mb-4">
					<div class="col-lg-12 col-md-12">
							
						<!-- templates/element/For-Candidate/Browse-Jobs/grid-style-1/results.php -->
            			<?= $this->element('For-Candidate/Browse-Jobs/grid-style-1/results'); ?>

					</div>
				</div>
				<!-- Shorting Wrap End -->
				
				<!-- Start All List -->
				<div class="row justify-content-start gx-3 gy-4">
			
					<!-- templates/element/For-Candidate/Browse-Jobs/list-style-2/jobs13.php -->
            		<?= $this->element('For-Candidate/Browse-Jobs/list-style-2/jobs13'); ?>
					
				</div>
				<!-- End All Job List -->
				
				<!-- templates/element/For-Candidate/Browse-Jobs/grid-style-1/pagination.php -->
            	<?= $this->element('For-Candidate/Browse-Jobs/grid-style-1/pagination'); ?>
				
			</div>
			<!-- Job List Wrap End-->
			
		</div>
	</div>		
</section>
<!-- All List Wrap -->
			
<!-- templates/element/Home/home-4/find2.php -->
<?= $this->element('Home/home-4/find2'); ?>
		
<!-- templates/element/Home/index/log.php -->
<?= $this->element('Home/index/log'); ?>
	
<!-- templates/element/Home/home-3/filter.php -->
<?= $this->element('Home/home-3/filter'); ?>
	
<!-- Include Footer -->
<?= $this->element('footer2') ?>