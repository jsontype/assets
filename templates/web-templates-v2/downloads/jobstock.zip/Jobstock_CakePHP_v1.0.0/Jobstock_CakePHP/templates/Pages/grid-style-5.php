<?php
$this->assign('title', 'Grid-Style-5 Page');
?>

<!-- Include Navbar -->
<?= $this->element('navbar5') ?>
						
<!-- Page Title Start -->
<div class="page-title bg-main" style="background:url(<?= $this->Url->build('/assets/img/bg2.png'); ?>) no-repeat;">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				
				<h2 class="ipt-title">Grid Style Job 05</h2>
				<div class="breadcrumbs light">
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="JavaScript:Void(0);">Home</a></li>
							<li class="breadcrumb-item"><a href="JavaScript:Void(0);">Candidate</a></li>
							<li class="breadcrumb-item active" aria-current="page">Job Grid 05</li>
						</ol>
					</nav>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Page Title End -->

<!-- All List Wrap -->
<section class="gray-simple">
	<div class="container">
		<div class="row">
		
			<!-- Search Sidebar -->
			<div class="col-lg-4 col-md-12 col-sm-12">
				
				<div class="bg-white rounded mb-3">							
				
					<!-- templates/element/For-Candidate/Browse-Jobs/grid-style-1/search.php -->
            		<?= $this->element('For-Candidate/Browse-Jobs/grid-style-1/search'); ?>
					
					<!-- templates/element/For-Candidate/Browse-Jobs/grid-style-1/property.php -->
            		<?= $this->element('For-Candidate/Browse-Jobs/grid-style-1/property'); ?>
					
				</div>
					
				<!-- templates/element/For-Candidate/Browse-Jobs/grid-style-1/alert.php -->
            	<?= $this->element('For-Candidate/Browse-Jobs/grid-style-1/alert'); ?>
	
			</div>
			<!-- Sidebar End -->
			
			<div class="col-lg-8 col-md-12 col-sm-12">
			
				<div class="row justify-content-center mb-5">
					<div class="col-lg-12 col-md-12">
							
						<!-- templates/element/For-Candidate/Browse-Jobs/grid-style-1/results.php -->
            			<?= $this->element('For-Candidate/Browse-Jobs/grid-style-1/results'); ?>

					</div>
				</div>
				
				<!-- Start All List -->
				<div class="row justify-content-center gx-3 gy-4">
			
					<!-- templates/element/For-Candidate/Browse-Jobs/grid-style-5/jobs9.php -->
            		<?= $this->element('For-Candidate/Browse-Jobs/grid-style-5/jobs9'); ?>
						
				</div>
				
				<!-- templates/element/For-Candidate/Browse-Jobs/grid-style-1/pagination.php -->
            	<?= $this->element('For-Candidate/Browse-Jobs/grid-style-1/pagination'); ?>

			</div>
			
		</div>
	</div>		
</section>
<!-- All List Wrap -->
			
<!-- templates/element/Home/home-4/find2.php -->
<?= $this->element('Home/home-4/find2'); ?>
				
<!-- templates/element/Home/index/log.php -->
<?= $this->element('Home/index/log'); ?>

<!-- Include Footer -->
<?= $this->element('footer2') ?>