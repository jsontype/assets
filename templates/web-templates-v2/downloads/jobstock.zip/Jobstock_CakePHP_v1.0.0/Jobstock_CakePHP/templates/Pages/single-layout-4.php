<?php
$this->assign('title', 'Single-Layout-4 Page');
?>

<!-- Include Navbar -->
<?= $this->element('navbar5') ?>

<!-- Header Top Start -->
<section class="bg-cover bg-main" style="background:url(<?= $this->Url->build('/assets/img/bg2.png'); ?>)no-repeat;">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				
				<div class="jbs-head-bodys-top">
					<div class="jbs-roots-y1">
						<div class="jbs-roots-y1-first"><div class="jbs-roots-thumb"><figure><img src="<?= $this->Url->build('/assets/img/l-12.png'); ?>" class="img-fluid" alt=""></figure></div></div>
						<div class="jbs-roots-y1-last ps-3">
							<div class="jbs-urt mb-2"><span class="label text-secondcolor bg-white">Full Time</span></div>
							<div class="jbs-title-iop"><h2 class="m-0 text-light">Sr. Front-end Designer</h2></div>
							<div class="jbs-locat-oiu text-sm-muted text-light d-flex align-items-center">
								<span><i class="fa-solid fa-location-dot opacity-75 me-1"></i>California, USA</span>
								<div class="jbs-kioyer-groups ms-3">
									<span class="fa-solid fa-star active"></span>
									<span class="fa-solid fa-star active"></span>
									<span class="fa-solid fa-star active"></span>
									<span class="fa-solid fa-star active"></span>
									<span class="fa-solid fa-star"></span>
									<span class="aal-reveis text-light opacity-75">4.6</span>
								</div>
							</div>
						</div>
					</div>
					<div class="jbs-roots-y2">
						<div class="jbs-roots-action-groups">
							<div class="jbs-roots-action-btns">
								<button type="button" class="btn btn-md btn-whites fw-medium text-main" data-bs-toggle="modal" data-bs-target="#applyjob">Quick Apply</button>
								<button type="button" class="btn btn-md btn-dark ms-2 fw-medium">Save Job</button>
							</div>
							<div class="jbs-roots-action-info">
								<span class="text-light opacity-75 me-2">74 applicants</span>.<span class="text-sm fw-medium text-light opacity-75 ms-2">Posted 54 min ago</span>
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>
</section>
<!-- Header Top End -->

<!-- Job Detail -->
<section class="gray-simple">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 col-md-12">
				
				<div class="jbs-blocs style_03 b-0 mb-md-4 mb-sm-4">
					<div class="jbs-blocs-body px-4 py-4">
						<div class="jbs-content mb-4">
							<h5>Job Description</h5>
							<p>Shreethemes Web provides equal employment opportunities to all qualified individuals without regard to race, color, religion, sex, gender identity, sexual orientation, pregnancy, age, national origin, physical or mental disability, military or veteran status, genetic information, or any other protected classification. Equal employment opportunity includes, but is not limited to, hiring, training, promotion, demotion, transfer, leaves of absence, and termination. Thynk Web takes allegations of discrimination, harassment, and retaliation seriously, and will promptly investigate when such behavior is reported.</p>
							<p>Our company is seeking to hire a skilled Web Developer to help with the development of our current projects. Your duties will primarily revolve around building software by writing code, as well as modifying software to fix errors, adapt it to new hardware, improve its performance, or upgrade interfaces. You will also be involved in directing system testing and validation procedures, and also working with customers or departments on technical issues including software system design and maintenance.</p>
							<p class="m-0">We are looking for a Senior Web Developer to build and maintain functional web pages and applications. Senior Web Developer will be leading junior developers, refining website specifications, and resolving technical issues. He/She should have extensive experience building web pages from scratch and in-depth knowledge of at least one of the following programming languages: Javascript, Ruby, or PHP. He/She will ensure our web pages are up and running and cover both internal and customer needs.</p>
						</div>
						<div class="jbs-content-body mb-4">
							<h5>Job Requirements</h5>
							<div class="jbs-content mb-3">
								<h6>Requirements:</h6>
								<ul class="simple-list">
									<li>Candidate must have a Bachelors or Masters degree in Computer. (B.tech, Bsc or BCA/MCA)</li>
									<li>Candidate must have a good working knowledge of Javascript and Jquery.</li>
									<li>Good knowledge of HTML and CSS is required.</li>
									<li>Experience in Word press is an advantage</li>
									<li>Jamshedpur, Jharkhand: Reliably commute or planning to relocate before starting work (Required)</li>
								</ul>
							</div>
							
							<div class="jbs-content mb-4">
								<h6>Responsibilities:</h6>
								<ul class="simple-list">
									<li>Write clean, maintainable and efficient code.</li>
									<li>Design robust, scalable and secure features.</li>
									<li>Collaborate with team members to develop and ship web applications within tight timeframes.</li>
									<li>Work on bug fixing, identifying performance issues and improving application performance</li>
									<li>Write unit and functional testcases.</li>
									<li>Continuously discover, evaluate, and implement new technologies to maximise development efficiency. Handling complex technical iss</li>
								</ul>
							</div>
							
							<div class="jbs-content">
								<h6>Qualifications and Skills</h6>
								<ul class="colored-list">
									<li>Bachelor's degree</li>
									<li>BCA/MCA</li>
									<li>BSC IT/Msc IT</li>
									<li>Or any other equivalent degree</li>
								</ul>
							</div>
						</div>
					</div>
					<div class="jbs-blox-footer">
						<div class="blox-first-footer">
							<div class="ftr-share-block">
								<ul>
									<li><strong>Share This Job:</strong></li>
									<li><a href="JavaScript:Void(0);"><i class="fa-brands fa-facebook"></i></a></li>
									<li><a href="JavaScript:Void(0);"><i class="fa-brands fa-linkedin"></i></a></li>
									<li><a href="JavaScript:Void(0);"><i class="fa-brands fa-google-plus"></i></a></li>
									<li><a href="JavaScript:Void(0);"><i class="fa-brands fa-twitter"></i></a></li>
								</ul>
							</div>
						</div>
						<div class="blox-last-footer">
							<div class="jbs-roots-action-btns">
								<button type="button" class="btn btn-md btn-main" data-bs-toggle="modal" data-bs-target="#applyjob">Quick Apply</button>
								<button type="button" class="btn btn-md btn-gray ms-2"><i class="fa-solid fa-heart me-2"></i>Save Job</button>
							</div>
						</div>
					</div>
				</div>
				
			</div>
			
			<div class="col-lg-4 col-md-12">
				<div class="detail-side-block bg-white mb-4">
					<div class="detail-side-head">
						<div class="side-flex-thumb">
							<img src="<?= $this->Url->build('/assets/img/l-12.png'); ?>" class="img-fluid" alt="">
						</div>
						<div class="side-flex-caption">
							<div class="jbs-title-iop"><h4 class="m-0">Sr. Front-end Designer</h4></div>
							<div class="jbs-locat-oiu text-sm-muted">
								<span><i class="fa-solid fa-location-dot me-1"></i>California, USA</span>
							</div>
						</div>
					</div>
					<div class="detail-side-middle">
						<div class="form-group">
							<label>Name:</label>
							<input type="text" class="form-control" placeholder="">
						</div>
						<div class="form-group">
							<label>Email:</label>
							<input type="text" class="form-control" placeholder="">
						</div>
						<div class="form-group">
							<div class="upload-btn-wrapper full-width">
								<button class="btn full-width">Upload Resume</button>
								<input type="file" name="myfile">
							</div>
						</div>
						<div class="form-group">
							<div class="elsoci"><label>Are you authorised to work in India?</label></div>
							<div class="form-check form-check-inline">
								<input class="form-check-input" type="radio" name="workindia" id="wyes" value="option1">
								<label class="form-check-label" for="wyes">Yes</label>
							</div>
							<div class="form-check form-check-inline">
								<input class="form-check-input" type="radio" name="workindia" id="wno" value="option1">
								<label class="form-check-label" for="wno">No</label>
							</div>
						</div>
						<div class="form-group">
							<div class="elsoci"><label>Do you have master degree?</label></div>
							<div class="form-check form-check-inline">
								<input class="form-check-input" type="radio" name="degree" id="dyed" value="option1">
								<label class="form-check-label" for="dyed">Yes</label>
							</div>
							<div class="form-check form-check-inline">
								<input class="form-check-input" type="radio" name="degree" id="dno" value="option1">
								<label class="form-check-label" for="dno">No</label>
							</div>
						</div>
						<div class="form-group">
							<div class="form-check form-check-inline">
								<input class="form-check-input" type="checkbox" id="jobalert" value="option1">
								<label class="form-check-label" for="jobalert">Create Job Alert</label>
							</div>
						</div>
						<div class="form-group">
							<button type="button" class="btn btn-main full-width font-sm">Apply Now</button>
						</div>
					</div>
				</div>
				
				<div class="side-jbs-info-blox bg-white mb-4">
					<div class="side-jbs-info-header">
						<div class="side-jbs-info-thumbs">
							<figure><img src="<?= $this->Url->build('/assets/img/l-12.png'); ?>" class="img-fluid" alt=""></figure>
						</div>
						<div class="side-jbs-info-captionyo ps-3">
							<div class="sld-info-title">
								<h5 class="rtls-title mb-1">Google Inc.</h5>
								<div class="jbs-locat-oiu text-sm-muted">
									<span class="me-1"><i class="fa-solid fa-location-dot me-1"></i>California, USA</span>.<span class="ms-1">Software & Consultancy</span>
								</div>
							</div>
						</div>
					</div>
					<div class="side-jbs-info-middle">
						<div class="side-full-info-groups">
							<div class="single-side-info">
								<span class="text-sm-muted sld-subtitle">Company Founder:</span>
								<h6 class="sld-title">Mr. Daniel Mark</h6>
							</div>
							<div class="single-side-info">
								<span class="text-sm-muted sld-subtitle">Industry:</span>
								<h6 class="sld-title">Technology</h6>
							</div>
							<div class="single-side-info">
								<span class="text-sm-muted sld-subtitle">Founded:</span>
								<h6 class="sld-title">1997</h6>
							</div>
							<div class="single-side-info">
								<span class="text-sm-muted sld-subtitle">Head Office:</span>
								<h6 class="sld-title">London, UK</h6>
							</div>
							<div class="single-side-info">
								<span class="text-sm-muted sld-subtitle">Revenue</span>
								<h6 class="sld-title">$70B+</h6>
							</div>
							<div class="single-side-info">
								<span class="text-sm-muted sld-subtitle">Company Size:</span>
								<h6 class="sld-title">20,000+ Emp.</h6>
							</div>
							<div class="single-side-info">
								<span class="text-sm-muted sld-subtitle">Min Exp.</span>
								<h6 class="sld-title">02 Years</h6>
							</div>
							<div class="single-side-info">
								<span class="text-sm-muted sld-subtitle">Openings</span>
								<h6 class="sld-title">06 Openings</h6>
							</div>
						</div>
					</div>
				</div>
				
				<div class="side-rtl-jbs-block">
					<div class="side-rtl-jbs-head">
						<h5 class="side-jbs-titles">Related Jobs</h5>
					</div>
					<div class="side-rtl-jbs-body">
						<div class="side-rtl-jbs-groups">
							
							<!-- templates/element/For-Candidate/Single-job-Detail/related.php -->
            				<?= $this->element('For-Candidate/Single-job-Detail/related'); ?>
						
						</div>
					</div>
				</div>
							
			</div>
		</div>
	</div>
</section>
<!-- Job Detail -->

<!-- templates/element/Home/home-4/find2.php -->
<?= $this->element('Home/home-4/find2'); ?>
			
<!-- templates/element/Home/index/log.php -->
<?= $this->element('Home/index/log'); ?>

<!-- templates/element/For-Candidate/Single-job-Detail/apply.php -->
<?= $this->element('For-Candidate/Single-job-Detail/apply'); ?>

<!-- Include Footer -->
<?= $this->element('footer2') ?>