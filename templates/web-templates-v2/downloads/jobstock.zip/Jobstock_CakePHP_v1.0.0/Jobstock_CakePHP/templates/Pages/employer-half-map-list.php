<?php
$this->assign('title', 'Employer-Half-Map-List Page');
?>

<!-- Include Navbar -->
<?= $this->element('navbar6') ?>

<!-- Hero Banner Start -->
<div class="map-banner-wrap half-map">
	
	<div class="map-left-box">
		<div class="map-home flt-wrap">
			<div class="home-map-container fw-map">
				<div id="map-main"></div>
			</div>
		</div>
	</div>
	
	<div class="map-content-wrap">
		<div class="map-content-bxo">
		
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12">
				
					<!-- templates/element/For-Candidate/Browse-Map-Jobs/half-map/search2.php -->
            		<?= $this->element('For-Candidate/Browse-Map-Jobs/half-map/search2'); ?>
					
					<div class="_mp-inner-content elior">
						<div class="item-shorting clearfix">
							<div class="left-column"><h4 class="m-0">Showing 1 - 10 of 20 Results</h4></div>
						</div>
						<div class="item-shorting-box-right">
							<div class="shorting-by me-2 small">
								<select>
									<option value="0">Short by (Default)</option>
									<option value="1">Short by (Featured)</option>
									<option value="2">Short by (Urgent)</option>
									<option value="3">Short by (Post Date)</option>
								</select>
							</div>
							<div class="shorting-by small">
								<select>
									<option value="0">10 Per Page</option>
									<option value="1">20 Per Page</option>
									<option value="2">50 Per Page</option>
									<option value="3">10 Per Page</option>
								</select>
							</div>
						</div>
					</div>
					
				</div>
				
			</div>
			
		</div>
		
		<!--- All List -->
		<div class="map-content-list">
			<!-- Start All List -->
			<div class="row justify-content-start gx-3 gy-4">
		
				<!-- templates/element/For-Candidate/candidate-dashboard/employer2.php -->
            	<?= $this->element('For-Candidate/candidate-dashboard/employer2'); ?>
				
			</div>
			<!-- End All Job List -->
			
			<!-- templates/element/For-Candidate/Browse-Jobs/grid-style-1/pagination.php -->
            <?= $this->element('For-Candidate/Browse-Jobs/grid-style-1/pagination'); ?>
				
		</div>
	</div>
	
</div>
<div class="clearfix"></div>
<!-- Hero Banner End -->

<!-- templates/element/Home/index/log.php -->
<?= $this->element('Home/index/log'); ?>
			
<!-- templates/element/Home/home-3/filter.php -->
<?= $this->element('Home/home-3/filter'); ?>