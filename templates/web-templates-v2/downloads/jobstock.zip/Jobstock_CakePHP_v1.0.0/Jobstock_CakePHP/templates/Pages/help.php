<?php
$this->assign('title', 'Help Page');
?>

<!-- Include Navbar -->
<?= $this->element('navbar2') ?>

<!-- Page Title Start -->
<section class="bg-cover bg-second" style="background:url(<?= $this->Url->build('/assets/img/bg2.png'); ?>)no-repeat;">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12">
				
				<h2 class="ipt-title text-light">Help & Component</h2>
				<span class="ipn-subtitle text-light opacity-75">Check all elements and components</span>
				
			</div>
		</div>
	</div>
</section>
<!-- Page Title End -->

<!-- All Components Start -->
<section>
	<div class="container">
	
		<!-- row Start -->
		<div class="row mb-5">
			
			<div class="col-xl-6 col-lg-6 col-md-12 col-12">
				<div class="elements-wrap">
					<h3>Headings</h3>
					
					<!-- templates/element/help/headings.php -->
            		<?= $this->element('help/headings'); ?>

				</div>
			</div>
			
			<div class="col-xl-6 col-lg-6 col-md-12 col-12">
				<div class="elements-wrap">
					<h3>Buttons</h3>
					<div class="d-flex flex-wrap gap-2">
						
						<!-- templates/element/help/buttons.php -->
            			<?= $this->element('help/buttons'); ?>

					</div>
				</div>
			</div>
			
		</div>
		<!-- /row -->
		
		<!-- row Start -->
		<div class="row mb-5">
			
			<div class="col-xl-6 col-lg-6 col-md-12 col-12">
				<div class="elements-wrap">
					<h3>Alerts</h3>
				
					<!-- templates/element/help/alerts.php -->
            		<?= $this->element('help/alerts'); ?>

				</div>
			</div>
			
			<div class="col-xl-6 col-lg-6 col-md-12 col-12">
				<div class="elements-wrap">
					<h3>Alert Links</h3>

					<!-- templates/element/help/links.php -->
            		<?= $this->element('help/links'); ?>

				</div>
			</div>
			
		</div>
		<!-- /row -->
		
		<!-- row Start -->
		<div class="row mb-5">
			
			<div class="col-xl-6 col-lg-6 col-md-12 col-12">
				<div class="elements-wrap">
					<h3>Badges</h3>
					<div class="d-flex flex-wrap gap-2 mb-4">

						<!-- templates/element/help/badges.php -->
            			<?= $this->element('help/badges'); ?>

					</div>
					
					<h3>Avatar</h3>
					<div class="d-flex align-items-center flex-wrap gap-3 mb-4">
						
						<!-- templates/element/help/avatar.php -->
            			<?= $this->element('help/avatar'); ?>

					</div>
					
					<h3>Pagination</h3>
					<div class="pagination-wrap">
						<nav aria-label="...">
							<ul class="pagination">
							<li class="page-item"><a href="#" class="page-link">Previous</a></li>
							<li class="page-item"><a class="page-link" href="#" style="margin-left: 1rem;">1</a></li>
							<li class="page-item active">
								<a class="page-link" href="#" aria-current="page">2</a>
							</li>
							<li class="page-item"><a class="page-link" href="#">3</a></li>
							<li class="page-item"><a class="page-link" href="#">4</a></li>
							<li class="page-item"><a class="page-link" href="#">5</a></li>
							<li class="page-item"><a class="page-link" href="#">Next</a></li>
							</ul>
						</nav>
					</div>
				</div>
			</div>
			
			<div class="col-xl-6 col-lg-6 col-md-12 col-12">
				<div class="elements-wrap">
					<h3>Form Elements</h3>
					
					<!-- templates/element/help/form.php -->
            		<?= $this->element('help/form'); ?>

				</div>
			</div>
			
		</div>
		<!-- /row -->
		
		<!-- row Start -->
		<div class="row mb-5">
			
			<div class="col-xl-6 col-lg-6 col-md-12 col-12">
				<div class="elements-wrap">
					<h3>Accordion</h3>
					<div class="accordion" id="accordionExample">
						
						<!-- templates/element/help/accordion.php -->
            			<?= $this->element('help/accordion'); ?>

					</div>
				</div>
			</div>
			
			<div class="col-xl-6 col-lg-6 col-md-12 col-12">
				<div class="elements-wrap">
					<h3>Navs and tabs</h3>
					
					<!-- templates/element/help/tabs.php -->
            		<?= $this->element('help/tabs'); ?>

				</div>
			</div>
			
		</div>
		<!-- /row -->
		
	</div>	
</section>
<!-- All Components End -->
			
<!-- templates/element/Home/home-4/find2.php -->
<?= $this->element('Home/home-4/find2'); ?>
		
<!-- templates/element/Home/index/log.php -->
<?= $this->element('Home/index/log'); ?>

<!-- Include Footer -->
<?= $this->element('footer2') ?>