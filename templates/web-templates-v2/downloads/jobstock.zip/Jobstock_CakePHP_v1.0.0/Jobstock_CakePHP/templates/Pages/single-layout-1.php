<?php
$this->assign('title', 'Single-Layout-1 Page');
?>

<!-- Include Navbar -->
<?= $this->element('navbar2') ?>

<!-- Page Title Start -->
<section class="bg-cover bg-second" style="background:url(<?= $this->Url->build('/assets/img/bg2.png'); ?>)no-repeat;">
	<div class="ht-110"></div>
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12"></div>
		</div>
	</div>
	<div class="ht-110"></div>
</section>
<!-- Page Title End -->

<!-- Job Detail -->
<section class="gray-simple over-lg-top pt-0 pb-0">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-xl-11 col-lg-12 col-md-12">
				
				<div class="jbs-dts-block styl-01">
					<div class="jbs-dts-header">
						<div class="jbs-dts-header-thumbs">
							<div class="jbs-dts-hgiu mb-2">
								<figure><img src="<?= $this->Url->build('/assets/img/l-12.png'); ?>" class="img-fluid rounded" alt=""></figure>
							</div>
							<div class="jbs-dts-iop">
								<span>04 More Openings</span>
							</div>
						</div>
						<div class="jbs-dts-header-caption">
							<div class="jbs-dts-topper-block mb-4">
								<div class="jbs-urt"><span class="label text-success bg-success bg-opacity-05">Full Time</span></div>
								<div class="jbs-title-iop"><h2 class="m-0">Sr. Front-end Designer</h2></div>
								<div class="jbs-locat-oiu text-sm-muted"><span><i class="fa-solid fa-location-dot me-1"></i>California, USA</span></div>
							</div>
							<div class="jbs-dts-mid-block mb-4">
								<div class="jbs-mid-groups">
									<div class="jbs-single-iou">
										<span class="jhu-subtitle">Role</span>
										<h4 class="jhu-title">Developer</h4>
									</div>
									<div class="jbs-single-iou">
										<span class="jhu-subtitle">Experience</span>
										<h4 class="jhu-title">07 Years</h4>
									</div>
								</div>
							</div>
							<div class="jbs-dts-foot-block">
								<span class="jhu-subtitle">Supperpower Skills</span>
								<div class="sprpower-skills">
									<span><i class="fa-regular fa-star"></i>HTML5</span>
									<span><i class="fa-regular fa-star"></i>CSS3</span>
									<span><i class="fa-regular fa-star"></i>WordPress</span>
									<span><i class="fa-regular fa-star"></i>JavaScript</span>
									<span><i class="fa-regular fa-star"></i>Bootstrap</span>
								</div>
							</div>
						</div>
					</div>
					
					<div class="jbs-dts-body bg-white rounded full-width px-lg-4 px-3 py-4">
						<div class="jbs-dts-body-content">
							<ul class="nav nav-pills small-jbs-tab d-inline-flex gap-2 mb-3" id="pills-tab" role="tablist">
								<li class="nav-item" role="presentation">
									<button class="nav-link active" id="job-description-tab" data-bs-toggle="pill" data-bs-target="#job-description" type="button" role="tab" aria-controls="job-description" aria-selected="true">Job Description</button>
								</li>
								<li class="nav-item" role="presentation">
									<button class="nav-link" id="job-requirements-tab" data-bs-toggle="pill" data-bs-target="#job-requirements" type="button" role="tab" aria-controls="job-requirements" aria-selected="false">Job Requirements</button>
								</li>
								<li class="nav-item" role="presentation">
									<button class="nav-link" id="company-review-tab" data-bs-toggle="pill" data-bs-target="#company-review" type="button" role="tab" aria-controls="company-review" aria-selected="false">Company Review</button>
								</li>
							</ul>
							<div class="tab-content" id="pills-tabContent">
								<!-- Job Description-->
								<div class="tab-pane fade show active" id="job-description" role="tabpanel" aria-labelledby="job-description-tab" tabindex="0">
									<div class="row">
										<div class="col-xl-9 col-lg-10 col-md-12">
											<div class="jbs-content">
												<p>Shreethemes Web provides equal employment opportunities to all qualified individuals without regard to race, color, religion, sex, gender identity, sexual orientation, pregnancy, age, national origin, physical or mental disability, military or veteran status, genetic information, or any other protected classification. Equal employment opportunity includes, but is not limited to, hiring, training, promotion, demotion, transfer, leaves of absence, and termination. Thynk Web takes allegations of discrimination, harassment, and retaliation seriously, and will promptly investigate when such behavior is reported.</p>
												<p>Our company is seeking to hire a skilled Web Developer to help with the development of our current projects. Your duties will primarily revolve around building software by writing code, as well as modifying software to fix errors, adapt it to new hardware, improve its performance, or upgrade interfaces. You will also be involved in directing system testing and validation procedures, and also working with customers or departments on technical issues including software system design and maintenance.</p>
												<p class="m-0">We are looking for a Senior Web Developer to build and maintain functional web pages and applications. Senior Web Developer will be leading junior developers, refining website specifications, and resolving technical issues. He/She should have extensive experience building web pages from scratch and in-depth knowledge of at least one of the following programming languages: Javascript, Ruby, or PHP. He/She will ensure our web pages are up and running and cover both internal and customer needs.</p>
											</div>
										</div>
									</div>
								</div>
								
								<!-- Job Requirements -->
								<div class="tab-pane fade" id="job-requirements" role="tabpanel" aria-labelledby="job-requirements-tab" tabindex="0">
									<div class="row">
										<div class="col-xl-12 col-lg-12 col-md-12">
											<div class="jbs-content mb-4">
												<h6>Requirements:</h6>
												<ul class="simple-list">
													<li>Candidate must have a Bachelors or Masters degree in Computer. (B.tech, Bsc or BCA/MCA)</li>
													<li>Candidate must have a good working knowledge of Javascript and Jquery.</li>
													<li>Good knowledge of HTML and CSS is required.</li>
													<li>Experience in Word press is an advantage</li>
													<li>Jamshedpur, Jharkhand: Reliably commute or planning to relocate before starting work (Required)</li>
												</ul>
											</div>
											
											<div class="jbs-content mb-4">
												<h6>Responsibilities:</h6>
												<ul class="simple-list">
													<li>Write clean, maintainable and efficient code.</li>
													<li>Design robust, scalable and secure features.</li>
													<li>Collaborate with team members to develop and ship web applications within tight timeframes.</li>
													<li>Work on bug fixing, identifying performance issues and improving application performance</li>
													<li>Write unit and functional testcases.</li>
													<li>Continuously discover, evaluate, and implement new technologies to maximise development efficiency. Handling complex technical iss</li>
												</ul>
											</div>
											
											<div class="jbs-content">
												<h6>Qualifications and Skills</h6>
												<ul class="colored-list">
													<li>Bachelor's degree</li>
													<li>BCA/MCA</li>
													<li>BSC IT/Msc IT</li>
													<li>Or any other equivalent degree</li>
												</ul>
											</div>
										</div>
									</div>	
								</div>
								
								<!-- Company Review -->
								<div class="tab-pane fade" id="company-review" role="tabpanel" aria-labelledby="company-review-tab" tabindex="0">
									<div class="row">
										<div class="col-xl-9 col-lg-12 col-md-12">
											
											<div class="single-cdtsr-block pt-4 pb-2">
												<div class="single-cdtsr-body">
													<div class="row align-items-center justify-content-between gy-4">
														<div class="col-xl-6 col-lg-6 col-md-6">
															<div class="cdtx-infr-box">
																<div class="cdtx-infr-icon"><i class="fa-solid fa-envelope-open-text"></i></div>
																<div class="cdtx-infr-captions">
																	<h5>shreethemes@gmail.com</h5>
																	<p>Mail Address</p>
																</div>
															</div>
														</div>
														<div class="col-xl-6 col-lg-6 col-md-6">
															<div class="cdtx-infr-box">
																<div class="cdtx-infr-icon"><i class="fa-solid fa-phone-volume"></i></div>
																<div class="cdtx-infr-captions">
																	<h5>855 606 8472</h5>
																	<p>Phone No.</p>
																</div>
															</div>
														</div>
														<div class="col-xl-6 col-lg-6 col-md-6">
															<div class="cdtx-infr-box">
																<div class="cdtx-infr-icon"><i class="fa-regular fa-user"></i></div>
																<div class="cdtx-infr-captions">
																	<h5>Male</h5>
																	<p>Gender</p>
																</div>
															</div>
														</div>
														<div class="col-xl-6 col-lg-6 col-md-6">
															<div class="cdtx-infr-box">
																<div class="cdtx-infr-icon"><i class="fa-solid fa-cake-candles"></i></div>
																<div class="cdtx-infr-captions">
																	<h5>07 Apr 1992</h5>
																	<p>Age</p>
																</div>
															</div>
														</div>
														<div class="col-xl-6 col-lg-6 col-md-6">
															<div class="cdtx-infr-box">
																<div class="cdtx-infr-icon"><i class="fa-solid fa-wallet"></i></div>
																<div class="cdtx-infr-captions">
																	<h5>$750/month</h5>
																	<p>Offerd Sallary</p>
																</div>
															</div>
														</div>
														<div class="col-xl-6 col-lg-6 col-md-6">
															<div class="cdtx-infr-box">
																<div class="cdtx-infr-icon"><i class="fa-solid fa-briefcase"></i></div>
																<div class="cdtx-infr-captions">
																	<h5>5 Years</h5>
																	<p>Experience</p>
																</div>
															</div>
														</div>
														<div class="col-xl-6 col-lg-6 col-md-6">
															<div class="cdtx-infr-box">
																<div class="cdtx-infr-icon"><i class="fa-solid fa-user-graduate"></i></div>
																<div class="cdtx-infr-captions">
																	<h5>Master Degree</h5>
																	<p>Qualification</p>
																</div>
															</div>
														</div>
														<div class="col-xl-6 col-lg-6 col-md-6">
															<div class="cdtx-infr-box">
																<div class="cdtx-infr-icon"><i class="fa-solid fa-layer-group"></i></div>
																<div class="cdtx-infr-captions">
																	<h5>Fulltime, Remote, Freelance</h5>
																	<p>Work Type</p>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										
										</div>
									</div>
								</div>
							</div>
							
							<div class="my-4 position-relative">
								<button type="button" class="btn btn-md btn-main fw-medium me-3" data-bs-toggle="modal" data-bs-target="#applyjob">Apply Now</button>
								<button type="button" class="btn btn-md btn-gray fw-medium"><i class="fa-solid fa-heart me-2"></i>Save</button>
							</div>
							
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>
</section>
<!-- Job Detail -->

<!-- templates/element/Home/home-4/find2.php -->
<?= $this->element('Home/home-4/find2'); ?>
		
<!-- templates/element/Home/index/log.php -->
<?= $this->element('Home/index/log'); ?>

<!-- templates/element/For-Candidate/Single-job-Detail/apply.php -->
<?= $this->element('For-Candidate/Single-job-Detail/apply'); ?>
			
<!-- Include Footer -->
<?= $this->element('footer2') ?>