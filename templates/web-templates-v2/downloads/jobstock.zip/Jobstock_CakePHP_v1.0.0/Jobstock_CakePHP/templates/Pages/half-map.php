<?php
$this->assign('title', 'Half-Map Page');
?>

<!-- Include Navbar -->
<?= $this->element('navbar6') ?>

<!-- Hero Banner Start -->
<div class="map-banner-wrap half-map">
	
	<div class="map-left-box">
		<div class="map-home flt-wrap">
			<div class="home-map-container fw-map">
				<div id="map-main"></div>
			</div>
		</div>
	</div>
	
	<div class="map-content-wrap">
		<div class="map-content-bxo">
		
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12">
				
					<!-- templates/element/For-Candidate/Browse-Map-Jobs/half-map/search2.php -->
            		<?= $this->element('For-Candidate/Browse-Map-Jobs/half-map/search2'); ?>

					<!-- templates/element/For-Candidate/Browse-Map-Jobs/half-map/results2.php -->
            		<?= $this->element('For-Candidate/Browse-Map-Jobs/half-map/results2'); ?>

				</div>
				
			</div>
			
		</div>
		
		<!--- All List -->
		<div class="map-content-list">
			<!-- Start All List -->
			<div class="row justify-content-center gx-xl-3 gx-3 gy-4">
	
				<!-- templates/element/For-Candidate/Browse-Jobs/grid-style-1/jobs5.php -->
            	<?= $this->element('For-Candidate/Browse-Jobs/grid-style-1/jobs5'); ?>
				
			</div>
			
			<!-- templates/element/For-Candidate/Browse-Jobs/grid-style-1/pagination.php -->
            <?= $this->element('For-Candidate/Browse-Jobs/grid-style-1/pagination'); ?>
				
		</div>
	</div>
	
</div>
<div class="clearfix"></div>
<!-- Hero Banner End -->

<!-- templates/element/Home/index/log.php -->
<?= $this->element('Home/index/log'); ?>
			
<!-- templates/element/Home/home-3/filter.php -->
<?= $this->element('Home/home-3/filter'); ?>