<?php
$this->assign('title', 'Home-11 Page');
?>

<!-- Include Navbar -->
<?= $this->element('navbar2') ?>
			
<!-- Hero Banner Start -->
<div class="image-bg py-5 bg-second position-relative" data-overlay="0">
	<div class="container py-5 z-2 position-relative">
		<div class="row justify-content-center">
			<div class="col-lg-9 col-md-11 col-sm-12">
				<div class="inner-banner-text text-center">
					<div class="inner-banner-eclips mb-3"><span class="label p-2 px-4 rounded-5 fw-medium text-light bg-main">Get Your Hot Jobs</span></div>
					<h1>Find Your Dream Job Today</h1>
					<p class="fs-5">Explore Hundreds of Opportunities!</p>
				</div>
				<div class="search-from-clasic mt-5">
					<div class="hero-search-content shadow-sm">
						<div class="row">
						
							<div class="col-xl-10 col-lg-10 col-md-9 col-sm-12 pe-xl-0 pe-lg-0 pe-md-0">
								<div class="classic-search-box">
									<div class="form-group full">
										<div class="input-with-icon">
											<input type="text" class="form-control fs-6" placeholder="Skills, Designations, Keyword">
											<img src="<?= $this->Url->build('/assets/img/pin.svg'); ?>" width="20" alt="">
										</div>
									</div>
								</div>
							</div>
							
							<div class="col-xl-2 col-lg-2 col-md-3 col-sm-12">
								<div class="form-group">
									<button type="submit" class="btn btn-main full-width">Search Job</button>
								</div>
							</div>
									
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>
	<div class="position-absolute start-0 bottom-0 d-none d-lg-block z-1"><img src="<?= $this->Url->build('/assets/img/banner-cap-1.png'); ?>" class="img-fluid" alt="Image"></div>
	<div class="position-absolute end-0 bottom-0 d-none d-lg-block z-1"><img src="<?= $this->Url->build('/assets/img/banner-cap-2.png'); ?>" class="img-fluid" alt="Image"></div>
</div>
<!-- Hero Banner End -->

<!-- Featured Jobs Start -->
<section>
	<div class="container">
		
		<div class="row justify-content-center">
			<div class="col-xl-6 col-lg-7 col-md-10 text-center">
				<div class="sec-heading center">
					<h2>Featured Jobs</h2>
					<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores</p>
				</div>
			</div>
		</div>
		
		<div class="row justify-content-center gx-xl-3 gx-3 gy-4">
		
			<!-- templates/element/Home/index/jobs.php -->
            <?= $this->element('Home/index/jobs'); ?>				
			
		</div>
		
	</div>
</section>
<!-- Featured Jobs End -->

<!-- Top Job Categories Start -->
<section class="gray-simple">
	<div class="container">
		
		<div class="row justify-content-center">
			<div class="col-xl-6 col-lg-7 col-md-10 text-center">
				<div class="sec-heading center">
					<h2>Explore Top Categories</h2>
					<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores</p>
				</div>
			</div>
		</div>
		
		<div class="row justify-content-center gx-4 gy-4">
			
			<!-- templates/element/Home/home-8/categories3.php -->
            <?= $this->element('Home/home-8/categories3'); ?>
		
		</div>
		
	</div>
</section>
<!-- Top Job Categories End -->

<!-- Why Choose Us Start -->
<section class="pb-4">
	<div class="container">
		
		<!-- templates/element/Home/home-8/popular3.php -->
        <?= $this->element('Home/home-8/popular3'); ?>
		
	</div>
</section>
<div class="clearfix"></div>
<!-- Why Choose Us End -->

<!-- Why Choose Us Start -->
<section class="pt-0">
	<div class="container">
		
		<!-- templates/element/Home/home-8/platform2.php -->
        <?= $this->element('Home/home-8/platform2'); ?>
	
	</div>
</section>
<div class="clearfix"></div>
<!-- Why Choose Us End -->

<!-- templates/element/Home/index/video.php -->
<?= $this->element('Home/index/video'); ?>			

<!-- Good Reviews By Customers -->
<section class="gray">
	<div class="container">
	
		<div class="row justify-content-center">
			<div class="col-lg-7 col-md-10 text-center">
				<div class="sec-heading center">
					<h2>Good Reviews By Customers</h2>
					<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores</p>
				</div>
			</div>
		</div>
		
		<div class="row justify-content-center gx-4 gy-4">
			
			<!-- templates/element/Home/index/reviews.php -->
			<?= $this->element('Home/index/reviews'); ?>
			
		</div>
		
	</div>	
</section>
<!-- Good Reviews By Customers -->

<!-- Our Price End -->
<section>
	<div class="container">
	
		<div class="row justify-content-center">
			<div class="col-lg-7 col-md-10 text-center">
				<div class="sec-heading center">
					<h2>Explore our Prices</h2>
					<p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores</p>
				</div>
			</div>
		</div>
		
		<div class="row justify-content-center gx-4 gy-4">
			
			<!-- templates/element/Home/home-9/prices.php -->
            <?= $this->element('Home/home-9/prices'); ?>
			
		</div>
		
	</div>	
</section>
<!-- Our Price End -->
			
<!-- templates/element/Home/home-11/working4.php -->
<?= $this->element('Home/home-11/working4'); ?>

<!-- templates/element/Home/index/log.php -->
<?= $this->element('Home/index/log'); ?>
			
<!-- Include Footer -->
<?= $this->element('footer3') ?>