<!doctype html>
<html lang="en">
	<head>
		<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrfToken" content="<?= $this->request->getAttribute('csrfToken'); ?>">
		
        <title>JobStock - Cakephp Job Listing, Job Portal Landing & Admin Dashboard Template</title>
		<link rel="icon" type="image/x-icon" href="<?= $this->Url->build('/assets/img/favicon.png'); ?>">

		<!-- CSS Files -->
        <?= $this->Html->css([
            '/assets/css/styles.css',
            '/assets/css/colors.css',
        ]); ?>

        <?= $this->fetch('meta') ?>
        <?= $this->fetch('css') ?>
		
		<link href="https://cdn.jsdelivr.net/npm/@mdi/font/css/materialdesignicons.min.css" rel="stylesheet">
		
    </head>
	
    <body>
        <!-- Preloader -->
        <div id="preloader"><div class="preloader"><span></span><span></span></div></div>
		
        <!-- Main wrapper -->
        <div id="main-wrapper">

            <!-- Main Content -->
        	<?= $this->fetch('content') ?>

            <a href="#" id="back2Top" class="top-scroll" title="Back to top"><i class="bi bi-arrow-up"></i></a>

		</div>
		<!-- End Wrapper -->

		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD_8C7p0Ws2gUu7wo0b6pK9Qu7LuzX2iWY&amp;libraries=places&amp;"></script>
		<!-- Map -->

		<!-- JavaScript Files -->
        <?= $this->Html->script([
            '/assets/js/jquery.min.js',
            '/assets/js/popper.min.js',
            '/assets/js/bootstrap.min.js',
            '/assets/js/rangeslider.js',
            '/assets/js/jquery.nice-select.min.js',
            '/assets/js/slick.js',
            '/assets/js/counterup.min.js',
            '/assets/js/custom.js',
            '/assets/js/map/map_infobox.js',
            '/assets/js/map/markerclusterer.js',
            '/assets/js/map/map.js',
            '/assets/js/map/employer-map.js',
            '/assets/js/raphael/raphael.min.js',
            '/assets/js/morris.js/morris.min.js',
            '/assets/js/custom/dashboard.js',
            '/assets/js/main.js',
            '/assets/js/contact.js',
            '/assets/js/datepicker.js',
            '/assets/js/htmleditor.js',
        ]); ?>

        <?= $this->fetch('script') ?>
		
	</body>
</html>