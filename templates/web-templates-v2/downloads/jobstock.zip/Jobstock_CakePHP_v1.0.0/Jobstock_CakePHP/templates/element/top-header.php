<div class="topbar d-flex align-items-center">
    <div class="container d-flex justify-content-center justify-content-md-between">
        <div class="contact-info d-flex align-items-center gap-2">
            <div class="d-flex align-items-center gap-2 text-light"><i class="bi bi-envelope"></i><a href="mailto:hello@jobstock.com" class="text-light">hello@jobstock.com</a></div>
            <div class="d-flex align-items-center gap-2 text-light"><i class="bi bi-telephone ms-4"></i><span>+233551196764</span></div>
        </div>
        <div class="social-links d-none d-md-flex align-items-center">
            <ul class="d-flex align-items-center justify-content-end gap-3">
                <li><a href="#" class="social-link"><i class="bi bi-facebook"></i></a></li>
                <li><a href="#" class="social-link"><i class="bi bi-twitter"></i></a></li>
                <li><a href="#" class="social-link"><i class="bi bi-behance"></i></a></li>
                <li><a href="#" class="social-link"><i class="bi bi-instagram"></i></a></li>
                <li><a href="#" class="social-link"><i class="bi bi-dribbble"></i></a></li>
            </ul>
        </div>
    </div>
</div>