<?php
$jobs = [
    [
        'id' => 1,
        'img' => 'assets/img/l-1.png', 
        'title' => 'Jr. PHP Developer',
        'app' => 'Tripadvisor',
        'desc' => 'Consistently create well-designed, tested code using best practices for website development, including mobile...',
        'location' => 'London',
        'time' => 'Full Time',
        'ago' => '1 Hours ago',
        'price' => '$80K - 90K', 
        'tag1' => true,
        'name' => '',
        'class' => '',
    ],
    [
        'id' => 2,
        'img' => 'assets/img/l-2.png', 
        'title' => 'Exp. Project manager',
        'app' => 'Pinterest',
        'desc' => 'Consistently create well-designed, tested code using best practices for website development, including mobile...',
        'location' => 'USA',
        'time' => 'Part Time',
        'ago' => '10 Hours ago',
        'price' => '$90K - 100K',
        'tag1' => false,
        'name' => 'Featured',
        'class' => 'featured-text',
    ],
    [
        'id' => 3,
        'img' => 'assets/img/l-3.png', 
        'title' => 'Sr. WordPress Developer',
        'app' => 'Shopify',
        'desc' => 'Consistently create well-designed, tested code using best practices for website development, including mobile...',
        'location' => 'Canada',
        'time' => 'Enternship',
        'ago' => '1 Days ago',
        'price' => '$75K - 90K',
        'tag1' => true,
        'name' => '',
        'class' => '',
    ],
    [
        'id' => 4,
        'img' => 'assets/img/l-4.png', 
        'title' => 'Jr. Laravel Developer',
        'app' => 'Dreezoo',
        'desc' => 'Consistently create well-designed, tested code using best practices for website development, including mobile...',
        'location' => 'Canada',
        'time' => 'Full Time',
        'ago' => '1 Days ago',
        'price' => '$65K - 80K',
        'tag1' => false,
        'name' => 'Featured',
        'class' => 'featured-text',
    ],
    [
        'id' => 5,
        'img' => 'assets/img/l-5.png', 
        'title' => 'Sr. UI-UX Designer',
        'app' => 'Photoshop',
        'desc' => 'Consistently create well-designed, tested code using best practices for website development, including mobile...',
        'location' => 'New York',
        'time' => 'Part Time',
        'ago' => '2 Days ago',
        'price' => '$95K - 120K',
        'tag1' => false,
        'name' => 'Urgent',
        'class' => 'urgent',
    ],
    [
        'id' => 6,
        'img' => 'assets/img/l-6.png', 
        'title' => 'Java & Python Developer',
        'app' => 'Firefox',
        'desc' => 'Consistently create well-designed, tested code using best practices for website development, including mobile...',
        'location' => 'Denver',
        'time' => 'Freelance',
        'ago' => '2 Days ago',
        'price' => '$90K - 110K',
        'tag1' => true,
        'name' => '',
        'class' => '',
    ],
    [
        'id' => 7,
        'img' => 'assets/img/l-7.png', 
        'title' => 'Sr. CodeIgniter Developer',
        'app' => 'Airbnb',
        'desc' => 'Consistently create well-designed, tested code using best practices for website development, including mobile...',
        'location' => 'London',
        'time' => 'Full Time',
        'ago' => '2 Days ago',
        'price' => '$60K - 80K',
        'tag1' => false,
        'name' => 'Urgent',
        'class' => 'urgent',
    ],
    [
        'id' => 8,
        'img' => 'assets/img/l-8.png', 
        'title' => 'Sr. Magento Developer',
        'app' => 'Snapchat',
        'desc' => 'Consistently create well-designed, tested code using best practices for website development, including mobile...',
        'location' => 'Canada',
        'time' => 'Part Time',
        'ago' => '3 Days ago',
        'price' => '$80K - 95K',
        'tag1' => false,
        'name' => 'Featured',
        'class' => 'featured-text',
    ],
    [
        'id' => 9,
        'img' => 'assets/img/l-9.png', 
        'title' => 'Technical Content Writer',
        'app' => 'Tripadvisor',
        'desc' => 'Consistently create well-designed, tested code using best practices for website development, including mobile...',
        'location' => 'London',
        'time' => 'Full Time',
        'ago' => '1 Hours ago',
        'price' => '$80K - 90K', 
        'tag1' => true,
        'name' => '',
        'class' => '',
    ],
    [
        'id' => 10,
        'img' => 'assets/img/l-10.png', 
        'title' => 'Front-end Developer',
        'app' => 'Pinterest',
        'desc' => 'Consistently create well-designed, tested code using best practices for website development, including mobile...',
        'location' => 'USA',
        'time' => 'Part Time',
        'ago' => '10 Hours ago',
        'price' => '$90K - 100K',
        'tag1' => false,
        'name' => 'Featured',
        'class' => 'featured-text',
    ],
    [
        'id' => 11,
        'img' => 'assets/img/l-11.png', 
        'title' => 'Jr. Content Writer',
        'app' => 'Shopify',
        'desc' => 'Consistently create well-designed, tested code using best practices for website development, including mobile...',
        'location' => 'Canada',
        'time' => 'Enternship',
        'ago' => '1 Days ago',
        'price' => '$75K - 90K',
        'tag1' => true,
        'name' => '',
        'class' => '',
    ],
    [
        'id' => 12,
        'img' => 'assets/img/l-12.png', 
        'title' => 'Sr. Figma Designer',
        'app' => 'Dreezoo',
        'desc' => 'Consistently create well-designed, tested code using best practices for website development, including mobile...',
        'location' => 'Canada',
        'time' => 'Full Time',
        'ago' => '1 Days ago',
        'price' => '$65K - 80K',
        'tag1' => false,
        'name' => 'Featured',
        'class' => 'featured-text',
    ]
];
?>

<?php foreach ($jobs as $item): ?>
    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
        <div class="jbs-grid-layout border">
            <div class="right-tags-capt">
                
                <?php if (!empty($item['tag1']) && $item['tag1'] === true): ?>
                    <span class="featured-text">Featured</span>
                    <span class="urgent">Urgent</span>
                <?php else: ?>
                    <span class="<?= h($item['class']) ?>"><?= h($item['name']) ?></span>
                <?php endif; ?>

            </div>
            <div class="jbs-grid-emp-head">
                <div class="jbs-grid-emp-content">
                    <div class="jbs-grid-emp-thumb"><a href="<?= $this->Url->build('/job-detail/' . strtolower(str_replace(' ', '-', $item['title']))) ?>"><figure><img src="<?= $this->Url->build('/' . h($item['img'])) ?>" class="img-fluid" alt=""></figure></a></div>
                    <div class="jbs-grid-job-caption">
                        <div class="jbs-job-employer-wrap"><span><?= h($item['app']) ?></span></div>
                        <div class="jbs-job-title-wrap"><h4><a href="<?= $this->Url->build('/job-detail/' . strtolower(str_replace(' ', '-', $item['title']))) ?>" class="jbs-job-title"><?= h($item['title']) ?></a></h4></div>
                    </div>
                </div>
            </div>
            <div class="jbs-grid-job-description">
                <p><?= h($item['desc']) ?></p>
            </div>
            <div class="jbs-grid-job-edrs">
                <div class="jbs-grid-job-edrs-group">
                    <span><i class="fa-solid fa-location-dot me-1"></i><?= h($item['location']) ?></span>
                    <span><i class="fa-regular fa-clock me-1"></i><?= h($item['time']) ?></span>
                    <span><i class="fa-solid fa-calendar-days me-1"></i><?= h($item['ago']) ?></span>
                </div>
            </div>
            <div class="jbs-grid-job-apply-btns">
                <div class="jbs-btn-groups">
                    <div class="jbs-sng-blux"><div class="jbs-grid-package-title smalls"><h5><?= h($item['price']) ?><span>\Year</span></h5></div></div>
                    <div class="jbs-sng-blux"><a href="JavaScript:Void(0);" class="btn btn-md btn-main px-4">Quick Apply</a></div>
                </div>
            </div>
        </div>	
    </div>
<?php endforeach; ?>