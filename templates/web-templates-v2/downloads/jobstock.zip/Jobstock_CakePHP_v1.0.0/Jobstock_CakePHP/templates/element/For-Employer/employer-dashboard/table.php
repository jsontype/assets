<?php
$tables = [
    [
        'number' => '01',
        'id' => '1274',
        'name' => 'Basic',
        'type' => 'Job Package',
        'featured' => 'Yes',
        'urgent' => 'Yes',
        'posted' => '04',
        'limit' => '20',
        'duration' => '30',
        'title' => 'Active',
        'class' => 'success',
    ],
    [
        'number' => '02',
        'id' => '1285',
        'name' => 'Standard',
        'type' => 'Job Package',
        'featured' => 'Yes',
        'urgent' => 'Yes',
        'posted' => '02',
        'limit' => '25',
        'duration' => '40',
        'title' => 'Expired',
        'class' => 'danger',
    ],
    [
        'number' => '03',
        'id' => '1274',
        'name' => 'Platinum',
        'type' => 'Job Package',
        'featured' => 'Yes',
        'urgent' => 'Yes',
        'posted' => '10',
        'limit' => '40',
        'duration' => '75',
        'title' => 'Active',
        'class' => 'success',
    ],
    [
        'number' => '04',
        'id' => '6254',
        'name' => 'Standard',
        'type' => 'Job Package',
        'featured' => 'Yes',
        'urgent' => 'Yes',
        'posted' => '07',
        'limit' => '10',
        'duration' => '15',
        'title' => 'Active',
        'class' => 'success',
    ],
    [
        'number' => '05',
        'id' => '3256',
        'name' => 'Basic',
        'type' => 'Job Package',
        'featured' => 'Yes',
        'urgent' => 'Yes',
        'posted' => '04',
        'limit' => '20',
        'duration' => '30',
        'title' => 'Expired',
        'class' => 'danger',
    ],
    [
        'number' => '06',
        'id' => '4215',
        'name' => 'Basic',
        'type' => 'Job Package',
        'featured' => 'Yes',
        'urgent' => 'Yes',
        'posted' => '04',
        'limit' => '20',
        'duration' => '30',
        'title' => 'Active',
        'class' => 'success',
    ],
    [
        'number' => '07',
        'id' => '6254',
        'name' => 'Platinum',
        'type' => 'Job Package',
        'featured' => 'Yes',
        'urgent' => 'Yes',
        'posted' => '04',
        'limit' => '20',
        'duration' => '30',
        'title' => 'Active',
        'class' => 'success',
    ]
];
?>

<?php foreach ($tables as $item): ?>
    <tr>
        <td><?= h($item['number']) ?></td>
        <td><?= h($item['id']) ?></td>
        <td><?= h($item['name']) ?></td>
        <td><?= h($item['type']) ?></td>
        <td>
            <div class="package-descr">
                <p class="text-sm-muted mb-1">Featured: <?= h($item['featured']) ?></p>
                <p class="text-sm-muted mb-1">Urgent: <?= h($item['urgent']) ?></p>
                <p class="text-sm-muted mb-1">Posted:<?= h($item['posted']) ?></p>
                <p class="text-sm-muted mb-1">Post Limit: <?= h($item['limit']) ?></p>
                <p class="text-sm-muted mb-1">Post Duration: <?= h($item['duration']) ?></p>
            </div>
        </td>
        <td><span class="label text-light bg-<?= h($item['class']) ?>"><?= h($item['title']) ?></span></td>
    </tr>
<?php endforeach; ?>