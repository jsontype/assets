<div class="ground-list ground-list-hove">
    <div class="ground ground-single-list">
        <a href="JavaScript:Void(0);">
            <div class="btn-circle-40 text-warning bg-warning bg-opacity-05"><i class="fas fa-home"></i></div>
        </a>

        <div class="ground-content">
            <h6><a href="JavaScript:Void(0);"><strong>Kr. Shaury Preet</strong> Replied your message</a></h6>
            <span class="small">Just Now</span>
        </div>
    </div>
    
    <div class="ground ground-single-list">
        <a href="JavaScript:Void(0);">
            <div class="btn-circle-40 text-danger bg-danger bg-opacity-05"><i class="fa-solid fa-comments"></i></div>
        </a>

        <div class="ground-content">
            <h6><a href="JavaScript:Void(0);">Mortin Denver accepted your resume on <strong>JobStock</strong></a></h6>
            <span class="small">20 min ago</span>
        </div>
    </div>
    
    <div class="ground ground-single-list">
        <a href="JavaScript:Void(0);">
            <div class="btn-circle-40 text-info bg-info bg-opacity-05"><i class="fa-solid fa-heart"></i></div>
        </a>

        <div class="ground-content">
            <h6><a href="JavaScript:Void(0);">Your job #456256 expired yesterday <strong>View More</strong></a></h6>
            <span class="small">1 day ago</span>
        </div>
    </div>
    
    <div class="ground ground-single-list">
        <a href="JavaScript:Void(0);">
            <div class="btn-circle-40 text-danger bg-danger bg-opacity-05"><i class="fa-solid fa-thumbs-up"></i></div>
        </a>

        <div class="ground-content">
            <h6><a href="JavaScript:Void(0);"><strong>Daniel Kurwa</strong> has been approved your resume!.</a></h6>
            <span class="small">10 days ago</span>
        </div>
    </div>
    
    <div class="ground ground-single-list">
        <a href="JavaScript:Void(0);">
            <div class="btn-circle-40 text-success bg-success bg-opacity-05"><i class="fa-solid fa-comment-dots"></i></div>
        </a>

        <div class="ground-content">
            <h6><a href="JavaScript:Void(0);">Khushi Verma left a review on <strong>Your Message</strong></a></h6>
            <span class="small">Just Now</span>
        </div>
    </div>
</div>