<div class="row justify-content-end align-items-md-center">
					
    <div class="d-none d-lg-block col-lg-6 position-absolute top-0 start-0 bg-cover h-100 rounded-end" style="background-image: url(<?= $this->Url->build('/assets/img/banner-1.jpg'); ?>);"></div>
    <div class="d-lg-none mb-5 mb-md-0">
        <img class="img-fluid rounded" src="<?= $this->Url->build('/assets/img/banner-1.jpg'); ?>" alt="Image Description">
    </div>

    <div class="col-lg-6 align-self-center">
        <div class="p-lg-5 p-md-0 pt-md-5">

            <div class="row mb-sm-4">
                <div class="col-sm-12 col-md-12 col-lg-12">
                    <div class="choose-us-head">
                        <div class="choose-us-wriops mb-2"><span class="font--bold label-light-warning px-3 py-2 rounded">Advanced Features</span></div>
                        <div class="choose-title">
                            <h2>Our Trusted & Popular<br>Job Portal</h2>
                            <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores</p>
                        </div>
                        <div class="jobstock-icon-box-list mt-4">
                            <ul>
                                
                                <li>
                                    <div class="vib-list-wrap21">
                                        <div class="vib-list-icon">
                                            <i class="fa-solid fa-check"></i>
                                        </div>
                                        <div class="vib-list-caption">
                                            <h5>#1 Quality Job</h5>
                                            <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores</p>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="vib-list-wrap21">
                                        <div class="vib-list-icon">
                                            <i class="fa-solid fa-check"></i>
                                        </div>
                                        <div class="vib-list-caption">
                                            <h5>Top Companies</h5>
                                            <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores</p>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="vib-list-wrap21">
                                        <div class="vib-list-icon">
                                            <i class="fa-solid fa-check"></i>
                                        </div>
                                        <div class="vib-list-caption">
                                            <h5>International Jobs</h5>
                                            <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores</p>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="vib-list-wrap21">
                                        <div class="vib-list-icon">
                                            <i class="fa-solid fa-check"></i>
                                        </div>
                                        <div class="vib-list-caption">
                                            <h5>No Extra Charges</h5>
                                            <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores</p>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- End Col -->
            </div>
            <!-- End Row -->
        
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12">
                    <a class="btn btn-main fw-medium px-4" href="#">Get Started</a>
                </div>
            </div>
        </div>
    </div>
    <!-- End Col -->
    
</div>