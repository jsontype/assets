<!-- Call To Action -->
<section class="bg-cover bg-second" style="background:url(<?= $this->Url->build('/assets/img/footer-bg-dark.png'); ?>)no-repeat;">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-7 col-lg-10 col-md-12 col-sm-12">
                
                <div class="call-action-wrap">
                    <div class="sec-heading center">
                        <h2 class="lh-base mb-3 text-light">Find The Perfect Job<br>on JobStock That is Superb For You</h2>
                        <p class="fs-6 text-light">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias</p>
                    </div>
                    <div class="call-action-buttons mt-3">
                        <a href="JavaScript:Void(0);" class="btn btn-lg btn-main fw-medium px-xl-5 px-lg-4 me-2">Upload resume</a>
                        <a href="JavaScript:Void(0);" class="btn btn-lg btn-whites fw-medium px-xl-5 px-lg-4 text-main">Join Our Team</a>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</section>
<!-- Call To Action End -->