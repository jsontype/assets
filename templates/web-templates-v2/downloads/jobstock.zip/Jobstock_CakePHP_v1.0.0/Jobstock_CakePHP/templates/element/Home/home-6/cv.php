<section class="pb-0 bg-cover" style="background:#01333f url(<?= $this->Url->build('/assets/img/footer-bg-dark.png'); ?>)no-repeat;">
    <div class="container">
    
        <div class="row justify-content-between">
        
            <div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 order-sm-2">
                <div class="position-relative">
                    <div class="footlio-img pb-4 pb-sm-0"><img src="<?= $this->Url->build('/assets/img/mean.png'); ?>" class="img-fluid" alt="" style="width: 350px"></div>
                </div>
            </div>
            
            <div class="col-xl-7 col-lg-6 col-md-12 col-sm-12 align-self-center order-sm-1">
                <div class="footlio-caalaction-caption">
                    <div class="footlio-caalaction-text">
                        <span class="text-main bg-white rounded py-1 px-3">Get Your Job</span>
                        <h2 class="text-light mt-3 mb-4 lh-base">Get your dream jobs just by<br>uploading your CV</h2>
                        <p class="text-light fs-6 opacity-75">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                    </div>
                    <div class="footlio-caalaction-link mt-4">
                        <a href="" class="btn btn-main fw-medium px-4"><i class="fa-solid fa-cloud-arrow-up me-2"></i>Upload CV</a>
                    </div>
                </div>
            </div>
            
        </div>
        
    </div>		
</section>