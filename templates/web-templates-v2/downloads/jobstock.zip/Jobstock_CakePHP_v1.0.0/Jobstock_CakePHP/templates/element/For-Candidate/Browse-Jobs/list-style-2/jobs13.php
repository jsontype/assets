<?php
$jobs = [
    [
        'id' => 1,
        'img' => 'assets/img/l-1.png', 
        'title' => 'Jr. PHP Developer',
        'name' => 'Tripadvisor', 
        'location' => 'London', 
        'time' => 'Full Time', 
        'date' => '06 Sep 2025', 
        'price' => '$85K - 95K',
    ],
    [
        'id' => 2,
        'img' => 'assets/img/l-2.png', 
        'title' => 'Exp. Project manager',
        'name' => 'Pinterest', 
        'location' => 'Canada', 
        'time' => 'Part Time', 
        'date' => '06 Sep 2025', 
        'price' => '$85K - 95K',
    ],
    [
        'id' => 3,
        'img' => 'assets/img/l-3.png', 
        'title' => 'Sr. WordPress Developer',
        'name' => 'Shopify', 
        'location' => 'London', 
        'time' => 'Enternship', 
        'date' => '06 Sep 2025', 
        'price' => '$85K - 95K',
    ],
    [
        'id' => 4,
        'img' => 'assets/img/l-4.png', 
        'title' => 'Jr. Laravel Developer',
        'name' => 'Dreezoo', 
        'location' => 'New York', 
        'time' => 'Full Time', 
        'date' => '06 Sep 2025', 
        'price' => '$85K - 95K',
    ],
    [
        'id' => 5,
        'img' => 'assets/img/l-5.png', 
        'title' => 'Sr. UI-UX Designer',
        'name' => 'Snapchat', 
        'location' => 'California', 
        'time' => 'Part Time', 
        'date' => '06 Sep 2025', 
        'price' => '$85K - 95K',
    ],
    [
        'id' => 6,
        'img' => 'assets/img/l-6.png', 
        'title' => 'Java & Python Developer',
        'name' => 'Photoshop', 
        'location' => 'Canada', 
        'time' => 'Enternship', 
        'date' => '06 Sep 2025', 
        'price' => '$85K - 95K',
    ],
    [
        'id' => 7,
        'img' => 'assets/img/l-7.png', 
        'title' => 'Sr. CodeIgniter Developer',
        'name' => 'Firefox', 
        'location' => 'London', 
        'time' => 'Part Time', 
        'date' => '06 Sep 2025', 
        'price' => '$85K - 95K',
    ],
    [
        'id' => 8,
        'img' => 'assets/img/l-8.png', 
        'title' => 'Sr. Magento Developer',
        'name' => 'Airbnb', 
        'location' => 'London', 
        'time' => 'Freelance', 
        'date' => '06 Sep 2025', 
        'price' => '$85K - 95K',
    ],
    [
        'id' => 9,
        'img' => 'assets/img/l-9.png', 
        'title' => 'Technical Content Writer',
        'name' => 'Tripadvisor', 
        'location' => 'London', 
        'time' => 'Full Time', 
        'date' => '06 Sep 2025', 
        'price' => '$85K - 95K',
    ],
    [
        'id' => 10,
        'img' => 'assets/img/l-10.png', 
        'title' => 'Front-end Developer',
        'name' => 'Pinterest', 
        'location' => 'Canada', 
        'time' => 'Part Time', 
        'date' => '06 Sep 2025', 
        'price' => '$85K - 95K',
    ]
];
?>

<?php foreach ($jobs as $item): ?>
    <div class="col-xl-12 col-lg-12 col-md-12">
        <div class="jbs-list-box border">
            <div class="jbs-list-head">
                <div class="jbs-list-head-thunner">
                    <div class="jbs-list-emp-thumb jbs-verified"><a href="<?= $this->Url->build('/job-detail/' . strtolower(str_replace(' ', '-', $item['title']))) ?>"><figure><img src="<?= $this->Url->build('/' . h($item['img'])) ?>" class="img-fluid" alt=""></figure></a></div>
                    <div class="jbs-list-job-caption">
                        <div class="jbs-job-types-wrap"><span class="label text-green bg-light-green"><?= h($item['time']) ?></span></div>
                        <div class="jbs-job-title-wrap"><h4><a href="<?= $this->Url->build('/job-detail/' . strtolower(str_replace(' ', '-', $item['title']))) ?>" class="jbs-job-title"><?= h($item['title']) ?></a></h4></div>
                        <div class="jbs-job-mrch-lists">
                            <div class="single-mrch-lists">
                                <span><?= h($item['name']) ?></span>.<span><i class="fa-solid fa-location-dot me-1"></i><?= h($item['location']) ?></span>.<span><?= h($item['date']) ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="jbs-list-head-middle">
                    <div class="elsocrio-jbs"><div class="ilop-tr"><i class="fa-solid fa-sack-dollar"></i></div><h5 class="jbs-list-pack"><?= h($item['price']) ?><span class="patype">\PA</span></h5></div>
                </div>
                <div class="jbs-list-head-last">
                    <a href="<?= $this->Url->build('/job-detail/' . strtolower(str_replace(' ', '-', $item['title']))) ?>" class="btn btn-md btn-gray px-3 me-2">View Detail</a>
                    <a href="JavaScript:Void(0);" class="btn btn-md btn-main px-3">Quick Apply</a>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>