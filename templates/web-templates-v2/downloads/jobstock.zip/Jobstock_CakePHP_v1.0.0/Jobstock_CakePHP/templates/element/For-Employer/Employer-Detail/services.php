<div class="single-cdtsr-block">
    <div class="single-cdtsr-header"><h5>Company Services</h5></div>
    <div class="single-cdtsr-body">
        <div class="cndts-all-skills-list">
            <span>WordPress Developements</span>
            <span>Java Developements</span>
            <span>HTML To WordPress</span>
            <span>PHP Developements</span>
            <span>UI/UX Design</span>
            <span>Laravel</span>
            <span>Magento 2.0</span>
        </div>
    </div>
</div>

<div class="single-cdtsr-block">
    <div class="single-cdtsr-header"><h5>Portfolio</h5></div>
    <div class="single-cdtsr-body">
        <div class="row gx-3 gy-3">
        
            <div class="col-xl-4 col-lg-4 col-md-6 col-6">
                <div class="cndts-prt-block">
                    <div class="cndts-prt-thumb">
                        <img src="<?= $this->Url->build('/assets/img/blog-1.jpg'); ?>" class="img-fluid rounded" alt="">
                    </div>
                    <div class="cndts-prt-link"><a href="JavaScript:Void(0);"><i class="fa-solid fa-arrow-up-right-from-square"></i></a></div>
                </div>
            </div>
            
            <div class="col-xl-4 col-lg-4 col-md-6 col-6">
                <div class="cndts-prt-block">
                    <div class="cndts-prt-thumb">
                        <img src="<?= $this->Url->build('/assets/img/blog-2.jpg'); ?>" class="img-fluid rounded" alt="">
                    </div>
                    <div class="cndts-prt-link"><a href="JavaScript:Void(0);"><i class="fa-solid fa-arrow-up-right-from-square"></i></a></div>
                </div>
            </div>
            
            <div class="col-xl-4 col-lg-4 col-md-6 col-6">
                <div class="cndts-prt-block">
                    <div class="cndts-prt-thumb">
                        <img src="<?= $this->Url->build('/assets/img/blog-3.jpg'); ?>" class="img-fluid rounded" alt="">
                    </div>
                    <div class="cndts-prt-link"><a href="JavaScript:Void(0);"><i class="fa-solid fa-arrow-up-right-from-square"></i></a></div>
                </div>
            </div>
        
        </div>
    </div>
</div>

<div class="single-cdtsr-block">
    <div class="single-cdtsr-header"><h5>10 Openings</h5></div>
    <div class="single-cdtsr-body">
        <!-- Start All List -->
        <div class="row justify-content-start gx-3 gy-4">
    
            <!-- Single Item -->
            <div class="col-xl-12 col-lg-12 col-md-12">
                <div class="jbs-list-box border">
                    <div class="jbs-list-head">
                        <div class="jbs-list-head-thunner">
                            <div class="jbs-list-emp-thumb jbs-verified"><a href="<?= $this->Url->build('/job-detail'); ?>"><figure><img src="<?= $this->Url->build('/assets/img/l-1.png'); ?>" class="img-fluid" alt=""></figure></a></div>
                            <div class="jbs-list-job-caption">
                                <div class="jbs-job-types-wrap"><span class="label text-success bg-success bg-opacity-05">Full Time</span></div>
                                <div class="jbs-job-title-wrap"><h4><a href="<?= $this->Url->build('/job-detail'); ?>" class="jbs-job-title">Product Designer</a></h4></div>
                                <div class="jbs-job-mrch-lists">
                                    <div class="single-mrch-lists">
                                        <span>Tripadvisor</span>.<span><i class="fa-solid fa-location-dot me-1"></i>California</span>.<span>07 Apr 2026</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="jbs-list-head-middle">
                            <div class="elsocrio-jbs"><div class="ilop-tr"><i class="fa-solid fa-sack-dollar"></i></div><h5 class="jbs-list-pack">$85K - 95K<span class="patype">\PA</span></h5></div>
                        </div>
                        <div class="jbs-list-head-last">
                            <a href="<?= $this->Url->build('/job-detail'); ?>" class="btn btn-md btn-gray px-3 me-2">View Detail</a>
                            <a href="JavaScript:Void(0);" class="btn btn-md btn-main px-3">Quick Apply</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Single Item -->
            <div class="col-xl-12 col-lg-12 col-md-12">
                <div class="jbs-list-box border">
                    <div class="jbs-list-head">
                        <div class="jbs-list-head-thunner">
                            <div class="jbs-list-emp-thumb"><a href="<?= $this->Url->build('/job-detail'); ?>"><figure><img src="<?= $this->Url->build('/assets/img/l-2.png'); ?>" class="img-fluid" alt=""></figure></a></div>
                            <div class="jbs-list-job-caption">
                                <div class="jbs-job-types-wrap"><span class="label text-warning bg-warning bg-opacity-05">Part Time</span></div>
                                <div class="jbs-job-title-wrap"><h4><a href="<?= $this->Url->build('/job-detail'); ?>" class="jbs-job-title">Product Designer</a></h4></div>
                                <div class="jbs-job-mrch-lists">
                                    <div class="single-mrch-lists">
                                        <span>Pinterest</span>.<span><i class="fa-solid fa-location-dot me-1"></i>Allahabad</span>.<span>2 Apr 2026</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="jbs-list-head-middle">
                            <div class="elsocrio-jbs"><div class="ilop-tr"><i class="fa-solid fa-sack-dollar"></i></div><h5 class="jbs-list-pack">$90K - 100K<span class="patype">\PA</span></h5></div>
                        </div>
                        <div class="jbs-list-head-last">
                            <a href="<?= $this->Url->build('/job-detail'); ?>" class="btn btn-md btn-gray px-3 me-2">View Detail</a>
                            <a href="JavaScript:Void(0);" class="btn btn-md btn-main px-3">Quick Apply</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Single Item -->
            <div class="col-xl-12 col-lg-12 col-md-12">
                <div class="jbs-list-box border">
                    <div class="jbs-list-head">
                        <div class="jbs-list-head-thunner">
                            <div class="jbs-list-emp-thumb"><a href="<?= $this->Url->build('/job-detail'); ?>"><figure><img src="<?= $this->Url->build('/assets/img/l-3.png'); ?>" class="img-fluid" alt=""></figure></a></div>
                            <div class="jbs-list-job-caption">
                                <div class="jbs-job-types-wrap"><span class="label text-success bg-success bg-opacity-05">Full Time</span></div>
                                <div class="jbs-job-title-wrap"><h4><a href="<?= $this->Url->build('/job-detail'); ?>" class="jbs-job-title">Product Designer</a></h4></div>
                                <div class="jbs-job-mrch-lists">
                                    <div class="single-mrch-lists">
                                        <span>Shopify</span>.<span><i class="fa-solid fa-location-dot me-1"></i>Canada, USA</span>.<span>15 March 2026</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="jbs-list-head-middle">
                            <div class="elsocrio-jbs"><div class="ilop-tr"><i class="fa-solid fa-sack-dollar"></i></div><h5 class="jbs-list-pack">$90K - 115K<span class="patype">\PA</span></h5></div>
                        </div>
                        <div class="jbs-list-head-last">
                            <a href="<?= $this->Url->build('/job-detail'); ?>" class="btn btn-md btn-gray px-3 me-2">View Detail</a>
                            <a href="JavaScript:Void(0);" class="btn btn-md btn-main px-3">Quick Apply</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Single Item -->
            <div class="col-xl-12 col-lg-12 col-md-12">
                <div class="jbs-list-box border">
                    <div class="jbs-list-head">
                        <div class="jbs-list-head-thunner">
                            <div class="jbs-list-emp-thumb jbs-verified"><a href="<?= $this->Url->build('/job-detail'); ?>"><figure><img src="<?= $this->Url->build('/assets/img/l-4.png'); ?>" class="img-fluid" alt=""></figure></a></div>
                            <div class="jbs-list-job-caption">
                                <div class="jbs-job-types-wrap"><span class="label text-success bg-success bg-opacity-05">Full Time</span></div>
                                <div class="jbs-job-title-wrap"><h4><a href="<?= $this->Url->build('/job-detail'); ?>" class="jbs-job-title">Jr. Laravel Developer</a></h4></div>
                                <div class="jbs-job-mrch-lists">
                                    <div class="single-mrch-lists">
                                        <span>Dreezoo</span>.<span><i class="fa-solid fa-location-dot me-1"></i>Liverpool, UK</span>.<span>20 March 2026</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="jbs-list-head-middle">
                            <div class="elsocrio-jbs"><div class="ilop-tr"><i class="fa-solid fa-sack-dollar"></i></div><h5 class="jbs-list-pack">$85K - 110K<span class="patype">\PA</span></h5></div>
                        </div>
                        <div class="jbs-list-head-last">
                            <a href="<?= $this->Url->build('/job-detail'); ?>" class="btn btn-md btn-gray px-3 me-2">View Detail</a>
                            <a href="JavaScript:Void(0);" class="btn btn-md btn-main px-3">Quick Apply</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Single Item -->
            <div class="col-xl-12 col-lg-12 col-md-12">
                <div class="jbs-list-box border">
                    <div class="jbs-list-head">
                        <div class="jbs-list-head-thunner">
                            <div class="jbs-list-emp-thumb"><a href="<?= $this->Url->build('/job-detail'); ?>"><figure><img src="<?= $this->Url->build('/assets/img/l-5.png'); ?>" class="img-fluid" alt=""></figure></a></div>
                            <div class="jbs-list-job-caption">
                                <div class="jbs-job-types-wrap"><span class="label text-danger bg-danger bg-opacity-05">Enternship</span></div>
                                <div class="jbs-job-title-wrap"><h4><a href="<?= $this->Url->build('/job-detail'); ?>" class="jbs-job-title">Java & Python Developer</a></h4></div>
                                <div class="jbs-job-mrch-lists">
                                    <div class="single-mrch-lists">
                                        <span>Photoshop</span>.<span><i class="fa-solid fa-location-dot me-1"></i>California</span>.<span>20 Feb 2026</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="jbs-list-head-middle">
                            <div class="elsocrio-jbs"><div class="ilop-tr"><i class="fa-solid fa-sack-dollar"></i></div><h5 class="jbs-list-pack">$90K - 120K<span class="patype">\PA</span></h5></div>
                        </div>
                        <div class="jbs-list-head-last">
                            <a href="<?= $this->Url->build('/job-detail'); ?>" class="btn btn-md btn-gray px-3 me-2">View Detail</a>
                            <a href="JavaScript:Void(0);" class="btn btn-md btn-main px-3">Quick Apply</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Single Item -->
            <div class="col-xl-12 col-lg-12 col-md-12">
                <div class="jbs-list-box border">
                    <div class="jbs-list-head">
                        <div class="jbs-list-head-thunner">
                            <div class="jbs-list-emp-thumb"><a href="<?= $this->Url->build('/job-detail'); ?>"><figure><img src="<?= $this->Url->build('/assets/img/l-6.png'); ?>" class="img-fluid" alt=""></figure></a></div>
                            <div class="jbs-list-job-caption">
                                <div class="jbs-job-types-wrap"><span class="label text-success bg-success bg-opacity-05">Full Time</span></div>
                                <div class="jbs-job-title-wrap"><h4><a href="<?= $this->Url->build('/job-detail'); ?>" class="jbs-job-title">Sr. Code Ignetor Developer</a></h4></div>
                                <div class="jbs-job-mrch-lists">
                                    <div class="single-mrch-lists">
                                        <span>Firefox</span>.<span><i class="fa-solid fa-location-dot me-1"></i>Canada, USA</span>.<span>18 Feb 2026</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="jbs-list-head-middle">
                            <div class="elsocrio-jbs"><div class="ilop-tr"><i class="fa-solid fa-sack-dollar"></i></div><h5 class="jbs-list-pack">$80K - 90K<span class="patype">\PA</span></h5></div>
                        </div>
                        <div class="jbs-list-head-last">
                            <a href="<?= $this->Url->build('/job-detail'); ?>" class="btn btn-md btn-gray px-3 me-2">View Detail</a>
                            <a href="JavaScript:Void(0);" class="btn btn-md btn-main px-3">Quick Apply</a>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
        <!-- End All Job List -->
    </div>
</div>