<?php
$avatars = [
    [
        'class' => 'square--80',
    ],
    [
        'class' => 'square--70',
    ],
    [
        'class' => 'square--50',
    ],
    [
        'class' => 'square--30',
    ],
    [
        'class' => 'square--20',
    ]
];
?>

<?php foreach ($avatars as $item): ?>
    <div class="<?= h($item['class']) ?> circle"><img src="<?= $this->Url->build('/assets/img/avatar.jpg'); ?>" class="img-fluid circle" alt=""></div>
<?php endforeach; ?>