<div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12 order-xl-1 order-lg-1 order-md-1">
    <div class="work-process mb-5">
        <div class="work-process-icon"><span><i class="fa-solid fa-file-shield text-main"></i></span></div>
        <div class="work-process-caption">
            <h4>Search Job</h4>
            <p>Aliquam vestibulum cursus felis. In iaculis iaculis sapien ac condimentum. Vestibulum congue posuere lacus</p>
        </div>
    </div>
    
    <div class="work-process mb-5">
        <div class="work-process-icon"><span><i class="fa-solid fa-paste text-main"></i></span></div>
        <div class="work-process-caption">
            <h4>FIND JOB</h4>
            <p>Aliquam vestibulum cursus felis. In iaculis iaculis sapien ac condimentum. Vestibulum congue posuere lacus</p>
        </div>
    </div>
    
    <div class="work-process mb-5">
        <div class="work-process-icon"><span><i class="fa-solid fa-unlock text-main"></i></span></div>
        <div class="work-process-caption">
            <h4>Create Account</h4>
            <p>Aliquam vestibulum cursus felis. In iaculis iaculis sapien ac condimentum. Vestibulum congue posuere lacus</p>
        </div>
    </div>
    
    <div class="work-process">
        <div class="work-process-icon"><span><i class="fa-solid fa-user-clock text-main"></i></span></div>
        <div class="work-process-caption">
            <h4>HIRE EMPLOYEE</h4>
            <p>Aliquam vestibulum cursus felis. In iaculis iaculis sapien ac condimentum. Vestibulum congue posuere lacus</p>
        </div>
    </div>
</div>

<div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12 order-xl-2 order-lg-3 order-md-3">
    <div class="eslio-pincc m-auto">
        <img src="<?= $this->Url->build('/assets/img/wp-iphone.png'); ?>" class="img-fluid" alt="">
    </div>
</div>

<div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12 order-xl-3 order-lg-2 order-md-2">
    <div class="work-process mb-5">
        <div class="work-process-icon"><span><i class="fa-solid fa-laptop-file text-main"></i></span></div>
        <div class="work-process-caption">
            <h4>START WORK</h4>
            <p>Aliquam vestibulum cursus felis. In iaculis iaculis sapien ac condimentum. Vestibulum congue posuere lacus</p>
        </div>
    </div>
    
    <div class="work-process mb-5">
        <div class="work-process-icon"><span><i class="fa-solid fa-business-time text-main"></i></span></div>
        <div class="work-process-caption">
            <h4>Submit Bid</h4>
            <p>Aliquam vestibulum cursus felis. In iaculis iaculis sapien ac condimentum. Vestibulum congue posuere lacus</p>
        </div>
    </div>
    
    <div class="work-process mb-5">
        <div class="work-process-icon"><span><i class="fa-solid fa-sack-dollar text-main"></i></span></div>
        <div class="work-process-caption">
            <h4>PAY MONEY</h4>
            <p>Aliquam vestibulum cursus felis. In iaculis iaculis sapien ac condimentum. Vestibulum congue posuere lacus</p>
        </div>
    </div>
    
    <div class="work-process">
        <div class="work-process-icon"><span><i class="fa-regular fa-face-laugh-wink text-main"></i></span></div>
        <div class="work-process-caption">
            <h4>HAPPY USER</h4>
            <p>Aliquam vestibulum cursus felis. In iaculis iaculis sapien ac condimentum. Vestibulum congue posuere lacus</p>
        </div>
    </div>
</div>