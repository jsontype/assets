<li class="single-comment">
    <article>
        <div class="comment-author">
            <img src="<?= $this->Url->build('/assets/img/user-1.png'); ?>" class="img-fluid circle" alt="">
        </div>
        <div class="comment-details">
            <div class="comment-meta">
                <div class="comment-left-meta">
                    <h4 class="author-name">Rosalina Kelian <span class="selected"><i class="fas fa-bookmark"></i></span></h4>
                    <div class="comment-date">19th May 2026</div>
                </div>
                <div class="comment-reply">
                    <a href="#" class="reply"><span class="icona"><i class="ti-back-left"></i></span> Reply</a>
                </div>
            </div>
            <div class="comment-text">
                <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim laborumab.
                    perspiciatis unde omnis iste natus error.</p>
            </div>
        </div>
    </article>
    <ul class="children">
        <li class="single-comment">
            <article>
                <div class="comment-author">
                    <img src="<?= $this->Url->build('/assets/img/user-2.png'); ?>" class="img-fluid circle" alt="">
                </div>
                <div class="comment-details">
                    <div class="comment-meta">
                        <div class="comment-left-meta">
                            <h4 class="author-name">Rosalina Kelian</h4>
                            <div class="comment-date">19th May 2026</div>
                        </div>
                        <div class="comment-reply">
                            <a href="#" class="reply"><span class="icons"><i class="ti-back-left"></i></span> Reply</a>
                        </div>
                    </div>
                    <div class="comment-text">
                        <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim laborumab.
                            perspiciatis unde omnis iste natus error.</p>
                    </div>
                </div>
            </article>
            <ul class="children">
                <li class="single-comment">
                    <article>
                        <div class="comment-author">
                            <img src="<?= $this->Url->build('/assets/img/user-3.png'); ?>" class="img-fluid circle" alt="">
                        </div>
                        <div class="comment-details">
                            <div class="comment-meta">
                                <div class="comment-left-meta">
                                    <h4 class="author-name">Rosalina Kelian</h4>
                                    <div class="comment-date">19th May 2026</div>
                                </div>
                                <div class="comment-reply">
                                    <a href="#" class="reply"><span class="icons"><i class="ti-back-left"></i></span> Reply</a>
                                </div>
                            </div>
                            <div class="comment-text">
                                <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim laborumab.
                                    perspiciatis unde omnis iste natus error.</p>
                            </div>
                        </div>
                    </article>
                </li>
            </ul>
        </li>
    </ul>
</li>
<li class="single-comment">
    <article>
        <div class="comment-author">
            <img src="<?= $this->Url->build('/assets/img/user-4.png'); ?>" class="img-fluid circle" alt="">
        </div>
        <div class="comment-details">
            <div class="comment-meta">
                <div class="comment-left-meta">
                    <h4 class="author-name">Rosalina Kelian</h4>
                    <div class="comment-date">19th May 2026</div>
                </div>
                <div class="comment-reply">
                    <a href="#" class="reply"><span class="icons"><i class="ti-back-left"></i></span> Reply</a>
                </div>
            </div>
            <div class="comment-text">
                <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim laborumab.
                    perspiciatis unde omnis iste natus error.</p>
            </div>
        </div>
    </article>
</li>