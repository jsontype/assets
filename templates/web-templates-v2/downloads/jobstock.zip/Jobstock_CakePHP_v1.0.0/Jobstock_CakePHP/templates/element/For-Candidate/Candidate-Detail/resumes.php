<div class="single-cdtsr-block">
    <div class="single-cdtsr-header"><h5>Resumes</h5></div>
    <div class="single-cdtsr-body">
        <div class="resumes-groups-blox">
            
            <div class="single-resumes-blocks">
                <div class="single-resumes-left">
                    <div class="single-resumes-icons"><i class="fa-solid fa-file-word"></i></div>
                    <div class="single-resumes-captions"><h5>Daniel-Resume.doc-2024<span>1 Year ago</span></h5></div>
                </div>
                <div class="single-resumes-right">
                    <button type="button" class="btn btn-md btn-light-green">Download<i class="fa-solid fa-circle-down ms-1"></i></button>
                </div>
            </div>
            
            <div class="single-resumes-blocks">
                <div class="single-resumes-left">
                    <div class="single-resumes-icons"><i class="fa-solid fa-file-word"></i></div>
                    <div class="single-resumes-captions"><h5>Daniel-Resume.doc-2025<span>10 Days ago</span></h5></div>
                </div>
                <div class="single-resumes-right">
                    <button type="button" class="btn btn-md btn-light-green">Download<i class="fa-solid fa-circle-down ms-1"></i></button>
                </div>
            </div>
            
        </div>
    </div>
</div>

<div class="single-cdtsr-block">
    <div class="single-cdtsr-header"><h5>All Experience</h5></div>
    <div class="single-cdtsr-body">
        <div class="experinc-usr-groups">
        
            <div class="single-experinc-block">
                <div class="single-experinc-lft">
                    <div class="experinc-thumbs"><figure><img src="<?= $this->Url->build('/assets/img/l-1.png'); ?>" class="img-fluid" alt=""></figure></div>
                </div>
                <div class="single-experinc-rght">
                    <div class="experinc-emp-title"><h5>Linked In</h5><span class="label text-success bg-success bg-opacity-05">Full Time</span></div>
                    <div class="experinc-post-title">
                        <h6>Sr. Web Designer</h6>
                        <div class="experinc-infos-list"><span class="exp-start">5 Years 1 Month</span><span class="work-exp-date">May 2010 - Jun 2015</span></div>
                    </div>
                </div>
            </div>
            
            <div class="single-experinc-block">
                <div class="single-experinc-lft">
                    <div class="experinc-thumbs"><figure><img src="<?= $this->Url->build('/assets/img/l-2.png'); ?>" class="img-fluid" alt=""></figure></div>
                </div>
                <div class="single-experinc-rght">
                    <div class="experinc-emp-title"><h5>Dribbble Ltd.</h5><span class="label text-warning bg-warning bg-opacity-05">Part Time</span></div>
                    <div class="experinc-post-title">
                        <h6>Sr. Product Designer</h6>
                        <div class="experinc-infos-list"><span class="exp-start">2 Years 3 Month</span><span class="work-exp-date">Aug 2015 - Jan 2017</span></div>
                    </div>
                </div>
            </div>
            <div class="single-experinc-block">
                <div class="single-experinc-lft">
                    <div class="experinc-thumbs"><figure><img src="<?= $this->Url->build('/assets/img/l-3.png'); ?>" class="img-fluid" alt=""></figure></div>
                </div>
                <div class="single-experinc-rght">
                    <div class="experinc-emp-title"><h5>Google Inc.</h5><span class="label text-success bg-success bg-opacity-05">Full Time</span></div>
                    <div class="experinc-post-title">
                        <h6>Sr. Team Leader</h6>
                        <div class="experinc-infos-list"><span class="exp-start">4 Years 7 Month</span>.<span class="work-exp-date">Feb 2017 - Dec 2022</span></div>
                    </div>
                </div>
            </div>
        
        </div>
    </div>
</div>

<div class="single-cdtsr-block">
    <div class="single-cdtsr-header"><h5>Educations</h5></div>
    <div class="single-cdtsr-body">
        <div class="educations-usr-groups">
        
            <div class="single-educations-block">
                <div class="single-educations-lft">
                    <div class="educations-thumbs"><figure><img src="<?= $this->Url->build('/assets/img/l-4.png'); ?>" class="img-fluid" alt=""></figure></div>
                </div>
                <div class="single-educations-rght">
                    <div class="educations-emp-title"><h5>Swami Vivekanand University</h5></div>
                    <div class="educations-post-title">
                        <h6>Bachlor Degree in Computer Science</h6>
                    </div>
                    <div class="educations-infos-list"><span class="exp-start">Jun 2008</span><span class="work-exp-date">Meeruth, UP</span></div>
                </div>
            </div>
            
            <div class="single-educations-block">
                <div class="single-educations-lft">
                    <div class="educations-thumbs"><figure><img src="<?= $this->Url->build('/assets/img/l-5.png'); ?>" class="img-fluid" alt=""></figure></div>
                </div>
                <div class="single-educations-rght">
                    <div class="educations-emp-title"><h5>Shatrapati Shiva Ji Maharaja University</h5></div>
                    <div class="educations-post-title">
                        <h6>Master Degree in Computer Science</h6>
                    </div>
                    <div class="educations-infos-list"><span class="exp-start">Jun 2013</span><span class="work-exp-date">Faizabad, UP</span></div>
                </div>
            </div>
        
        </div>
    </div>
</div>

<div class="single-cdtsr-block">
    <div class="single-cdtsr-header"><h5>Candidate Skills</h5></div>
    <div class="single-cdtsr-body">
        <div class="cndts-all-skills-list">
            <span>Java</span>
            <span>Python</span>
            <span>Bootstrap</span>
            <span>HTML5</span>
            <span>UI/UX</span>
            <span>Laravel</span>
            <span>WordPress</span>
        </div>
    </div>
</div>

<div class="single-cdtsr-block">
    <div class="single-cdtsr-header"><h5>Portfolio</h5></div>
    <div class="single-cdtsr-body">
        <div class="row gx-3 gy-3">
        
            <div class="col-xl-4 col-lg-4 col-md-6 col-6">
                <div class="cndts-prt-block">
                    <div class="cndts-prt-thumb">
                        <img src="<?= $this->Url->build('/assets/img/blog-1.jpg'); ?>" class="img-fluid rounded" alt="">
                    </div>
                    <div class="cndts-prt-link"><a href="JavaScript:Void(0);"><i class="fa-solid fa-arrow-up-right-from-square"></i></a></div>
                </div>
            </div>
            
            <div class="col-xl-4 col-lg-4 col-md-6 col-6">
                <div class="cndts-prt-block">
                    <div class="cndts-prt-thumb">
                        <img src="<?= $this->Url->build('/assets/img/blog-2.jpg'); ?>" class="img-fluid rounded" alt="">
                    </div>
                    <div class="cndts-prt-link"><a href="JavaScript:Void(0);"><i class="fa-solid fa-arrow-up-right-from-square"></i></a></div>
                </div>
            </div>
            
            <div class="col-xl-4 col-lg-4 col-md-6 col-6">
                <div class="cndts-prt-block">
                    <div class="cndts-prt-thumb">
                        <img src="<?= $this->Url->build('/assets/img/blog-3.jpg'); ?>" class="img-fluid rounded" alt="">
                    </div>
                    <div class="cndts-prt-link"><a href="JavaScript:Void(0);"><i class="fa-solid fa-arrow-up-right-from-square"></i></a></div>
                </div>
            </div>
        
        </div>
    </div>
</div>

<div class="single-cdtsr-block">
    <div class="single-cdtsr-header"><h5>Language</h5></div>
    <div class="single-cdtsr-body">
        <div class="row gy-4">
        
            <div class="col-xl-4 col-lg-4 col-md-6 col-6">
                <div class="cndts-lgs-blocks">
                    <div class="cndts-lgs-ico"><h6>JP</h6></div>
                    <div class="cndts-lgs-captions">
                        <h5>Japanies</h5>
                        <p>Basic</p>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-4 col-lg-4 col-md-6 col-6">
                <div class="cndts-lgs-blocks">
                    <div class="cndts-lgs-ico"><h6>EN</h6></div>
                    <div class="cndts-lgs-captions">
                        <h5>English</h5>
                        <p>Advance</p>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-4 col-lg-4 col-md-6 col-6">
                <div class="cndts-lgs-blocks">
                    <div class="cndts-lgs-ico"><h6>FR</h6></div>
                    <div class="cndts-lgs-captions">
                        <h5>French</h5>
                        <p>Medium</p>
                    </div>
                </div>
            </div>
        
        </div>
    </div>
</div>

<div class="single-cdtsr-block">
    <div class="single-cdtsr-header"><h5>Related Candidate</h5></div>
    <div class="single-cdtsr-body">
        <!-- Start All List -->
        <div class="row justify-content-start gx-3 gy-4">
    
            <!-- Single Item -->
            <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                <div class="jbs-list-box border">
                    <div class="jbs-list-head m-0">
                        <div class="jbs-list-head-thunner center">
                            <div class="jbs-list-usrs-thumb jbs-verified"><a href="<?= $this->Url->build('/candidate-detail'); ?>"><figure><img src="<?= $this->Url->build('/assets/img/team-1.jpg'); ?>" class="img-fluid circle" alt=""></figure></a></div>
                            <div class="jbs-list-job-caption">
                                <div class="jbs-job-title-wrap"><h4><a href="<?= $this->Url->build('/candidate-detail'); ?>" class="jbs-job-title">Kr. Calvin English</a></h4></div>
                                <div class="jbs-job-mrch-lists">
                                    <div class="single-mrch-lists">
                                        <span>Sr. Web Designer</span>.<span><i class="fa-solid fa-location-dot me-1"></i>London</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="jbs-list-head-middle">
                            <div class="elsocrio-jbs sm"><div class="ilop-tr"><i class="fa-solid fa-coins"></i></div><h5 class="jbs-list-pack">7 Years Exp.</h5></div>
                        </div>
                        <div class="jbs-list-head-last">
                            <a href="JavaScript:Void(0);" class="btn btn-md btn-main px-3">View Detail</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Single Item -->
            <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                <div class="jbs-list-box border">
                    <div class="jbs-list-head m-0">
                        <div class="jbs-list-head-thunner center">
                            <div class="jbs-list-usrs-thumb jbs-verified"><a href="<?= $this->Url->build('/candidate-detail'); ?>"><figure><img src="<?= $this->Url->build('/assets/img/team-6.jpg'); ?>" class="img-fluid circle" alt=""></figure></a></div>
                            <div class="jbs-list-job-caption">
                                <div class="jbs-job-title-wrap"><h4><a href="<?= $this->Url->build('/candidate-detail'); ?>" class="jbs-job-title">Clarence B. Mantooth</a></h4></div>
                                <div class="jbs-job-mrch-lists">
                                    <div class="single-mrch-lists">
                                        <span>Sr. Content Writer</span>.<span><i class="fa-solid fa-location-dot me-1"></i>Canada, USA</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="jbs-list-head-middle">
                            <div class="elsocrio-jbs sm"><div class="ilop-tr"><i class="fa-solid fa-coins"></i></div><h5 class="jbs-list-pack">3 Years Exp.</h5></div>
                        </div>
                        <div class="jbs-list-head-last">
                            <a href="JavaScript:Void(0);" class="btn btn-md btn-main px-3">View Detail</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Single Item -->
            <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                <div class="jbs-list-box border">
                    <div class="jbs-list-head m-0">
                        <div class="jbs-list-head-thunner center">
                            <div class="jbs-list-usrs-thumb jbs-verified"><a href="<?= $this->Url->build('/candidate-detail'); ?>"><figure><img src="<?= $this->Url->build('/assets/img/team-7.jpg'); ?>" class="img-fluid circle" alt=""></figure></a></div>
                            <div class="jbs-list-job-caption">
                                <div class="jbs-job-title-wrap"><h4><a href="<?= $this->Url->build('/candidate-detail'); ?>" class="jbs-job-title">Geraldine E. Scott</a></h4></div>
                                <div class="jbs-job-mrch-lists">
                                    <div class="single-mrch-lists">
                                        <span>Shopify Developer</span>.<span><i class="fa-solid fa-location-dot me-1"></i>Denver, USA</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="jbs-list-head-middle">
                            <div class="elsocrio-jbs sm"><div class="ilop-tr"><i class="fa-solid fa-coins"></i></div><h5 class="jbs-list-pack">8 Years Exp.</h5></div>
                        </div>
                        <div class="jbs-list-head-last">
                            <a href="JavaScript:Void(0);" class="btn btn-md btn-main px-3">View Detail</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Single Item -->
            <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                <div class="jbs-list-box border">
                    <div class="jbs-list-head m-0">
                        <div class="jbs-list-head-thunner">
                            <div class="jbs-list-usrs-thumb jbs-verified"><a href="<?= $this->Url->build('/candidate-detail'); ?>"><figure><img src="<?= $this->Url->build('/assets/img/team-8.jpg'); ?>" class="img-fluid circle" alt=""></figure></a></div>
                            <div class="jbs-list-job-caption">
                                <div class="jbs-job-title-wrap"><h4><a href="<?= $this->Url->build('/candidate-detail'); ?>" class="jbs-job-title">Donald J. Merrick</a></h4></div>
                                <div class="jbs-job-mrch-lists">
                                    <div class="single-mrch-lists">
                                        <span>Laravel Developer</span>.<span><i class="fa-solid fa-location-dot me-1"></i>California, USA</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="jbs-list-head-middle">
                            <div class="elsocrio-jbs sm"><div class="ilop-tr"><i class="fa-solid fa-coins"></i></div><h5 class="jbs-list-pack">5 Years Exp.</h5></div>
                        </div>
                        <div class="jbs-list-head-last">
                            <a href="JavaScript:Void(0);" class="btn btn-md btn-main px-3">View Detail</a>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
        <!-- End All Job List -->
    </div>
</div>