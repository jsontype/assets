<!-- Apply Job Modal -->
<div class="modal fade" id="applyjob" tabindex="-1" role="dialog" aria-labelledby="applyjobs" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered applyjob-pop-form" role="document">
        <div class="modal-content" id="applyjobs">
            <span class="mod-close" data-bs-dismiss="modal" aria-hidden="true"><i class="fas fa-close"></i></span>
            <div class="modal-body">
                <div class="detail-side-heads mb-4 mt-4">
                    <h3>Ready To Apply?</h3>
                    <p>Complete the eligibities checklist now and get started with your online application</p>
                </div>
                <div class="detail-side-middle">
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" placeholder="">
                        <label>Name:</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" placeholder="">
                        <label>Email:</label>
                    </div>
                    <div class="form-group">
                        <div class="upload-btn-wrapper full-width">
                            <button class="btn full-width">Upload Resume</button>
                            <input type="file" name="myfile">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="elsoci"><label>Are you authorised to work in India?</label></div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="workindia" id="wyes" value="option1">
                            <label class="form-check-label" for="wyes">Yes</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="workindia" id="wno" value="option1">
                            <label class="form-check-label" for="wno">No</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="elsoci"><label>Do you have master degree?</label></div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="degree" id="dyed" value="option1">
                            <label class="form-check-label" for="dyed">Yes</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="degree" id="dno" value="option1">
                            <label class="form-check-label" for="dno">No</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" id="jobalert" value="option1">
                            <label class="form-check-label" for="jobalert">Create Job Alert</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <button type="button" class="btn btn-main full-width fw-medium font-sm">Submit Application</button>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <p>Don't have an account yet?<a href="<?= $this->Url->build('/signup'); ?>" class="text-main font--bold ms-1">Sign Up</a></p>
            </div>
        </div>
    </div>
</div>
<!-- End Modal -->