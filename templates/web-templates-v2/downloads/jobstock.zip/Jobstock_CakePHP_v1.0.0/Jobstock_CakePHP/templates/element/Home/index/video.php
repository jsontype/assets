<!-- Video Help Start -->
<section class="bg-cover" style="background:#17ac6a url(<?= $this->Url->build('/assets/img/video-bg.jpg'); ?>)no-repeat;" data-overlay="4">
    <div class="ht-200"></div>
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-xl-12 col-lg-12">
                
                <div class="overlio-vedio-box">
                    <a href="#" class="play-video-btn text-main"><i class="fa-solid fa-play"></i></a>
                </div>
                
            </div>
        </div>
    </div>
    <div class="ht-200"></div>
</section>
<!-- Video Help End -->