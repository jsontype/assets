<div class="message-plunch">
    <div class="dash-msg-avatar"><img src="<?= $this->Url->build('/assets/img/user-5.png'); ?>" alt=""></div>
    <div class="dash-msg-text"><p>Hello, Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin</p></div>
</div>

<div class="message-plunch me">
    <div class="dash-msg-avatar"><img src="<?= $this->Url->build('/assets/img/user-3.png'); ?>" alt=""></div>
    <div class="dash-msg-text"><p>looked up one of the more obscure Latin words, consectetur, from a Lorem</p></div>
</div>

<div class="message-plunch">
    <div class="dash-msg-avatar"><img src="<?= $this->Url->build('/assets/img/user-5.png'); ?>" alt=""></div>
    <div class="dash-msg-text"><p>If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing</p></div>
</div>

<div class="message-plunch me">
    <div class="dash-msg-avatar"><img src="<?= $this->Url->build('/assets/img/user-3.png'); ?>" alt=""></div>
    <div class="dash-msg-text"><p>please consider donating a small sum to help pay for the hosting and bandwidth bill.</p></div>
</div>

<div class="message-plunch">
    <div class="dash-msg-avatar"><img src="<?= $this->Url->build('/assets/img/user-5.png'); ?>" alt=""></div>
    <div class="dash-msg-text"><p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore</p></div>
</div>

<div class="message-plunch me">
    <div class="dash-msg-avatar"><img src="<?= $this->Url->build('/assets/img/user-3.png'); ?>" alt=""></div>
    <div class="dash-msg-text"><p>numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p></div>
</div>

<div class="message-plunch">
    <div class="dash-msg-avatar"><img src="<?= $this->Url->build('/assets/img/user-5.png'); ?>" alt=""></div>
    <div class="dash-msg-text"><p>But I must explain to you how all this mistaken idea of denouncing pleasure</p></div>
</div>