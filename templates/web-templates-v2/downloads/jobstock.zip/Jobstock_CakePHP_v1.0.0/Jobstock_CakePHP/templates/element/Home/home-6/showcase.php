<div class="row align-items-center justify-content-between">
					
    <div class="col-xl-6 col-lg-6 col-md-12 col-12">
        <div class="p-lg-5 p-md-0 pt-md-5">
            <!-- Heading -->
            <div class="mb-4 mb-sm-7">
                <span class="fw-medium label-light-success px-3 py-2 rounded">Our Showcase</span>
                <h2 class="mt-2 lh-base">Best Job Search platform<br>Experience for you</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>
            <!-- End Heading -->

            <div class="features-groupss my-4">
                <ul class="row gx-3 gy-4 p-0">
                    <li class="fw-medium col-xl-6 col-lg-6 col-6"><span class="square--30 circle d-inline-flex align-items-center justify-content-center text-success bg-light-success me-2"><i class="fa-solid fa-check"></i></span>Corporate Business jobs</li>
                    <li class="fw-medium col-xl-6 col-lg-6 col-6"><span class="square--30 circle d-inline-flex align-items-center justify-content-center text-success bg-light-success me-2"><i class="fa-solid fa-check"></i></span>Company Showcase</li>
                    <li class="fw-medium col-xl-6 col-lg-6 col-6"><span class="square--30 circle d-inline-flex align-items-center justify-content-center text-success bg-light-success me-2"><i class="fa-solid fa-check"></i></span>Creative Services</li>
                    <li class="fw-medium col-xl-6 col-lg-6 col-6"><span class="square--30 circle d-inline-flex align-items-center justify-content-center text-success bg-light-success me-2"><i class="fa-solid fa-check"></i></span>Easy To Upload Resume</li>
                    <li class="fw-medium col-xl-6 col-lg-6 col-6"><span class="square--30 circle d-inline-flex align-items-center justify-content-center text-success bg-light-success me-2"><i class="fa-solid fa-check"></i></span>Online E-commerce</li>
                    <li class="fw-medium col-xl-6 col-lg-6 col-6"><span class="square--30 circle d-inline-flex align-items-center justify-content-center text-success bg-light-success me-2"><i class="fa-solid fa-check"></i></span>Hire Expert Candidates</li>
                </ul>
            </div>
        
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-6">
                    <a class="btn btn-main fw-medium px-4" href="#">Explore More Jobs</a>
                </div>
            </div>
        </div>
    
    </div>
    
    <div class="col-xl-5 col-lg-5 col-md-12 col-12">
        <div class="side-thumber-wrap">
            <div class="side-effect"></div>
            <div class="side-thumber-img">
                <figure><img src="<?= $this->Url->build('/assets/img/side-2.png'); ?>" class="img-fluid" alt=""></figure>
            </div>
        </div>
    </div>
    
</div>