<?php
$alerts = [
    [
        'title' => 'main',
    ],
    [
        'title' => 'secondary',
    ],
    [
        'title' => 'success',
    ],
    [
        'title' => 'danger',
    ],
    [
        'title' => 'warning',
    ],
    [
        'title' => 'info',
    ],
    [
        'title' => 'light',
    ],
    [
        'title' => 'dark',
    ]
];
?>

<?php foreach ($alerts as $item): ?>
    <div class="alert alert-<?= h($item['title']) ?>" role="alert">
        A simple <?= h($item['title']) ?> alert—check it out!
    </div>
<?php endforeach; ?>