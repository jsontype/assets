<li>
    <a href="#">
        <div class="dash-msg-avatar"><img src="<?= $this->Url->build('/assets/img/team-1.jpg'); ?>" alt=""><span class="_user_status online"></span></div>

        <div class="message-by">
            <div class="message-by-headline">
                <h5>Tilly Bartlett</h5>
                <span>36 min ago</span>
            </div>
            <p>Hello, I am a web designer with 5 year.. </p>
        </div>
    </a>
</li>

<li class="active-message">
    <a href="#">
        <div class="dash-msg-avatar"><img src="<?= $this->Url->build('/assets/img/team-2.jpg'); ?>" alt=""><span class="_user_status offline"></span></div>

        <div class="message-by">
            <div class="message-by-headline">
                <h5>George Howarth</h5>
                <span>2 hours ago</span>
            </div>
            <p>Hello, I am a web designer with 5 year..</p>
        </div>
    </a>
</li>

<li>
    <a href="#">
        <div class="dash-msg-avatar"><img src="<?= $this->Url->build('/assets/img/team-3.jpg'); ?>" alt=""><span class="_user_status busy"></span></div>

        <div class="message-by">
            <div class="message-by-headline">
                <h5>Harriet Ball</h5>
                <span>Yesterday</span>
            </div>
            <p>Hello, I am a web designer with 5 year..</p>
        </div>
    </a>
</li>

<li>
    <a href="#">
        <div class="dash-msg-avatar"><img src="<?= $this->Url->build('/assets/img/team-4.jpg'); ?>" alt=""><span class="_user_status online"></span></div>

        <div class="message-by">
            <div class="message-by-headline">
                <h5>Sienna Bruce</h5>
                <span>02.01.2026</span>
            </div>
            <p>Hello, I am a web designer with 5 year..</p>
        </div>
    </a>
</li>

<li>
    <a href="#">
        <div class="dash-msg-avatar"><img src="<?= $this->Url->build('/assets/img/team-5.jpg'); ?>" alt=""><span class="_user_status busy"></span></div>

        <div class="message-by">
            <div class="message-by-headline">
                <h5>Leo Stewart</h5>
                <span>03.01.2026</span>
            </div>
            <p>Hello, I am a web designer with 5 year..</p>
        </div>
    </a>
</li>

<li>
    <a href="#">
        <div class="dash-msg-avatar"><img src="<?= $this->Url->build('/assets/img/team-1.jpg'); ?>" alt=""><span class="_user_status online"></span></div>

        <div class="message-by">
            <div class="message-by-headline">
                <h5>Shaurya Preet</h5>
                <span>05.01.2026</span>
            </div>
            <p>Hello, I am a web designer with 5 year..</p>
        </div>
    </a>
</li>

<li>
    <a href="#">
        <div class="dash-msg-avatar"><img src="<?= $this->Url->build('/assets/img/team-2.jpg'); ?>" alt=""><span class="_user_status offline"></span></div>

        <div class="message-by">
            <div class="message-by-headline">
                <h5>Dan Preet</h5>
                <span>04.01.2026</span>
            </div>
            <p>Hello, I am a web designer with 5 year..</p>
        </div>
    </a>
</li>

<li>
    <a href="#">
        <div class="dash-msg-avatar"><img src="<?= $this->Url->build('/assets/img/team-3.jpg'); ?>" alt=""><span class="_user_status online"></span></div>

        <div class="message-by">
            <div class="message-by-headline">
                <h5>Maddison</h5>
                <span>31.05.2026</span>
            </div>
            <p>Hello, I am a web designer with 5 year..</p>
        </div>
    </a>
</li>

<li>
    <a href="#">
        <div class="dash-msg-avatar"><img src="<?= $this->Url->build('/assets/img/team-4.jpg'); ?>" alt=""><span class="_user_status busy"></span></div>

        <div class="message-by">
            <div class="message-by-headline">
                <h5>Maddison</h5>
                <span>27.05.2026</span>
            </div>
            <p>Hello, I am a web designer with 5 year..</p>
        </div>
    </a>
</li>

<li>
    <a href="#">
        <div class="dash-msg-avatar"><img src="<?= $this->Url->build('/assets/img/team-5.jpg'); ?>" alt=""><span class="_user_status busy"></span></div>

        <div class="message-by">
            <div class="message-by-headline">
                <h5>Eleanor Lloyd</h5>
                <span>24.05.2026</span>
            </div>
            <p>Hello, I am a web designer with 5 year..</p>
        </div>
    </a>
</li>

<li>
    <a href="#">
        <div class="dash-msg-avatar"><img src="<?= $this->Url->build('/assets/img/team-1.jpg'); ?>" alt=""><span class="_user_status offline"></span></div>

        <div class="message-by">
            <div class="message-by-headline">
                <h5>Anna Curtis</h5>
                <span>05.01.2026</span>
            </div>
            <p>Hello, I am a web designer with 5 year..</p>
        </div>
    </a>
</li>

<li>
    <a href="#">
        <div class="dash-msg-avatar"><img src="<?= $this->Url->build('/assets/img/team-2.jpg'); ?>" alt=""><span class="_user_status online"></span></div>

        <div class="message-by">
            <div class="message-by-headline">
                <h5>Tyler Fraser</h5>
                <span>07.01.2026</span>
            </div>
            <p>Hello, I am a web designer with 5 year..</p>
        </div>
    </a>
</li>