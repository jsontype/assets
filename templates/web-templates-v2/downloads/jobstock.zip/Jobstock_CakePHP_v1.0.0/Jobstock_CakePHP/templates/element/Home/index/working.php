<!-- Call To Action -->
<section class="bg-cover call-action-container dark bg-main" style="background:url(<?= $this->Url->build('/assets/img/footer-bg-dark.png'); ?>)no-repeat;">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-7 col-lg-10 col-md-12 col-sm-12">
                
                <div class="call-action-wrap">
                    <div class="call-action-caption">
                        <h2 class="text-light">Are You Already Working With Us?</h2>
                        <p class="fs-6 text-light">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias</p>
                    </div>
                    <div class="call-action-form">
                        <form>
                            <div class="newsltr-form">
                                <input type="text" class="form-control" placeholder="Enter Your email">
                                <button type="button" class="btn btn-dark px-4">Subscribe</button>
                            </div>
                        </form>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</section>
<!-- Call To Action End -->