<?php
$companies = [
    [
        'img' => 'assets/img/brand/layar-white.svg', 
    ],
    [
        'img' => 'assets/img/brand/mailchimp-white.svg', 
    ],
    [
        'img' => 'assets/img/brand/forbes-white.svg', 
    ],
    [
        'img' => 'assets/img/brand/fitbit-white.svg', 
    ],
    [
        'img' => 'assets/img/brand/vidados-white.svg', 
    ]
];
?>

<?php foreach ($companies as $item): ?>
    <div class="col">
        <figure class="single-brand thumb-figure">
            <img src="<?= $this->Url->build('/' . h($item['img'])) ?>" class="img-fluid" alt="">
        </figure>
    </div>
<?php endforeach; ?>