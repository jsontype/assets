<div class="row justify-content-end align-items-md-center">
					
    <div class="d-none d-lg-block col-lg-6 position-absolute top-0 start-0 bg-cover h-100 rounded-end" style="background-image: url(<?= $this->Url->build('/assets/img/banner-1.jpg'); ?>);"></div>
    <div class="d-lg-none mb-5 mb-md-0">
        <img class="img-fluid rounded" src="<?= $this->Url->build('/assets/img/banner-1.jpg'); ?>" alt="Image Description">
    </div>

    <div class="col-lg-6 align-self-center">
        <div class="p-lg-5 p-md-0 pt-md-5">
            <!-- Heading -->
            <div class="mb-4 mb-sm-7">
                <span class="fw-medium label-light-success px-3 py-2 rounded mb-2">Explore Showcase</span>
                <h2 class="mt-2 lh-base">Best Job Search platform<br>Experience for you</h2>
                <p class="fw-light fs-5">Lorem ipsum dolor sit amet, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip rounded commodo consequat.</p>
            </div>
            <!-- End Heading -->
            
            <div class="features-groupss my-4">
                <ul class="row gx-3 gy-4 p-0">
                    <li class="fw-medium col-xl-6 col-lg-6 col-6"><span class="square--30 circle d-inline-flex align-items-center justify-content-center text-success bg-light-success me-2"><i class="fa-solid fa-check"></i></span>Corporate Business jobs</li>
                    <li class="fw-medium col-xl-6 col-lg-6 col-6"><span class="square--30 circle d-inline-flex align-items-center justify-content-center text-success bg-light-success me-2"><i class="fa-solid fa-check"></i></span>Company Showcase</li>
                    <li class="fw-medium col-xl-6 col-lg-6 col-6"><span class="square--30 circle d-inline-flex align-items-center justify-content-center text-success bg-light-success me-2"><i class="fa-solid fa-check"></i></span>Creative Services</li>
                    <li class="fw-medium col-xl-6 col-lg-6 col-6"><span class="square--30 circle d-inline-flex align-items-center justify-content-center text-success bg-light-success me-2"><i class="fa-solid fa-check"></i></span>Easy To Upload Resume</li>
                    <li class="fw-medium col-xl-6 col-lg-6 col-6"><span class="square--30 circle d-inline-flex align-items-center justify-content-center text-success bg-light-success me-2"><i class="fa-solid fa-check"></i></span>Online E-commerce</li>
                    <li class="fw-medium col-xl-6 col-lg-6 col-6"><span class="square--30 circle d-inline-flex align-items-center justify-content-center text-success bg-light-success me-2"><i class="fa-solid fa-check"></i></span>Hire Expert Candidates</li>
                </ul>
            </div>
        
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-6">
                    <a class="btn btn-main fw-medium px-4" href="#">Explore Candidates</a>
                </div>
            </div>
        </div>
    </div>
    <!-- End Col -->
    
</div>