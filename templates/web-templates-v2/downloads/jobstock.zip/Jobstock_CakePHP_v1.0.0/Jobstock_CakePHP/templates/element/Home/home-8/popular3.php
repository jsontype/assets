<div class="row align-items-center justify-content-between">
					
    <div class="col-xl-5 col-lg-5 col-md-12 col-12">
        <div class="side-thumber-wrap mb-md-0 mb-4">
            <div class="side-effect"></div>
            <div class="side-thumber-img pe-4 pb-4 position-relative">
                <div class="bg-dot yellow w-25 h-25 position-absolute start-0 top-0"></div>
                <div class="bg-dot success w-25 h-25 position-absolute end-0 bottom-0"></div>
                <figure><img src="<?= $this->Url->build('/assets/img/slice-1.png'); ?>" class="img-fluid rounded-top-pill rounded-bottom-4 z-1 position-relative" alt=""></figure>
            </div>
        </div>
    </div>
    
    <div class="col-xl-5 col-lg-6 col-md-12 col-12">
        <div class="choose-us-head">
            <div class="choose-us-wriops mb-2"><span class="fw-medium label-light-warning px-3 py-2 rounded">Advanced Features</span></div>
            <div class="choose-title">
                <h2 class="lh-base">Trusted & Popular<br>Job Portal</h2>
                <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores</p>
            </div>
            <div class="jobstock-icon-box-list mt-4">
                <ul>
                    
                    <li>
                        <div class="vib-list-wrap21">
                            <div class="vib-list-icon">
                                <i class="fa-solid fa-check"></i>
                            </div>
                            <div class="vib-list-caption">
                                <h5>#1 Quality Job</h5>
                                <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores</p>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="vib-list-wrap21">
                            <div class="vib-list-icon">
                                <i class="fa-solid fa-check"></i>
                            </div>
                            <div class="vib-list-caption">
                                <h5>Top Companies</h5>
                                <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores</p>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="vib-list-wrap21">
                            <div class="vib-list-icon">
                                <i class="fa-solid fa-check"></i>
                            </div>
                            <div class="vib-list-caption">
                                <h5>International Jobs</h5>
                                <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores</p>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="vib-list-wrap21">
                            <div class="vib-list-icon">
                                <i class="fa-solid fa-check"></i>
                            </div>
                            <div class="vib-list-caption">
                                <h5>No Extra Charges</h5>
                                <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores</p>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    
    </div>
    
</div>