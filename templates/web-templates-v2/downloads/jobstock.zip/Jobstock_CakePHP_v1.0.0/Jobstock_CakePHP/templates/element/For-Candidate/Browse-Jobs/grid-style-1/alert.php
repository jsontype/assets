<div class="alert-jbemail-box bg-cover" style="background:#016551 url(<?= $this->Url->build('/assets/img/alert-bg.png'); ?>)no-repeat;" overlay="0">
    <div class="alert-bxr-wrap">
        <div class="alert-bxr-captions mb-3">
            <h4 class="text-light">Get The Latest Jobs Right Into Your Inbox!</h4>
            <p class="text-light opacity-75">We just want your email address!</p>
        </div>
        <div class="alert-bxr-forms">
            <form>
                <div class="newsltr-form">
                    <input type="text" class="form-control" placeholder="Enter Your email">
                    <button type="button" class="btn btn-subscribe bg-dark">Subscribe</button>
                </div>
            </form>
        </div>
    </div>
</div>