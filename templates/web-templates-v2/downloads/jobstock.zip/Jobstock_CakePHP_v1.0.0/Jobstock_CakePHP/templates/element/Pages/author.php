<div class="pg-side-block">
    <div class="pg-side-block-head">
        <div class="pg-side-left">
            <div class="pg-side-thumb"><img src="<?= $this->Url->build('/assets/img/team-6.jpg'); ?>" class="img-fluid circle" alt=""></div>
        </div>
        <div class="pg-side-right">
            <div class="pg-side-right-caption">
                <h4>Ht. Mickle Hussy</h4>
                <span><i class="fa-solid fa-location-dot me-2"></i>New York, UK</span>
            </div>
        </div>
    </div>
    <div class="pg-side-block-body">
        <div class="pg-side-block-info">
            <div class="vl-elfo-group">
                <div class="vl-elfo-icon"><i class="fa-solid fa-phone-volume"></i></div>
                <div class="vl-elfo-caption"><h6>Call Us</h6><p>+91 586 847 5213</p></div>
            </div>
            <div class="vl-elfo-group">
                <div class="vl-elfo-icon"><i class="fa-regular fa-envelope"></i></div>
                <div class="vl-elfo-caption"><h6>Drop A Mail</h6><p>payshreethemes@gmail.com</p></div>
            </div>
            <div class="vl-elfo-group">
                <div class="vl-elfo-icon"><i class="fa-solid fa-globe"></i></div>
                <div class="vl-elfo-caption"><h6>Website</h6><p>https://shreethemes.in/</p></div>
            </div>
        </div>
        <div class="pg-side-block-buttons">
            <div class="single-button"><a href="JavaScript:Void(0);" class="btn fw-medium btn-main full-width"><i class="fa-solid fa-comments me-2"></i>Send A Message</a></div>
        </div>
    </div>
</div>