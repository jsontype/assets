<?php
declare(strict_types=1);

/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link      https://cakephp.org CakePHP(tm) Project
 * @since     0.2.9
 * @license   https://opensource.org/licenses/mit-license.php MIT License
 */
namespace App\Controller;

use Cake\Core\Configure;
use Cake\Http\Exception\ForbiddenException;
use Cake\Http\Exception\NotFoundException;
use Cake\Http\Response;
use Cake\View\Exception\MissingTemplateException;

/**
 * Static content controller
 *
 * This controller will render views from templates/Pages/
 *
 * @link https://book.cakephp.org/5/en/controllers/pages-controller.html
 */
class PagesController extends AppController
{
    /**
     * Displays a view
     *
     * @param string ...$path Path segments.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Http\Exception\ForbiddenException When a directory traversal attempt.
     * @throws \Cake\View\Exception\MissingTemplateException When the view file could not
     *   be found and in debug mode.
     * @throws \Cake\Http\Exception\NotFoundException When the view file could not
     *   be found and not in debug mode.
     * @throws \Cake\View\Exception\MissingTemplateException In debug mode.
     */
    public function display(string ...$path): ?Response
    {
        if (!$path) {
            return $this->redirect('/');
        }
        if (in_array('..', $path, true) || in_array('.', $path, true)) {
            throw new ForbiddenException();
        }
        $page = $subpage = null;

        if (!empty($path[0])) {
            $page = $path[0];
        }
        if (!empty($path[1])) {
            $subpage = $path[1];
        }
        $this->set(compact('page', 'subpage'));

        try {
            return $this->render(implode('/', $path));
        } catch (MissingTemplateException $exception) {
            if (Configure::read('debug')) {
                throw $exception;
            }
            throw new NotFoundException();
        }
    }

    public function index()
    {
        return $this->render('/pages/index');
    }

    public function home2()
    {
        return $this->render('/pages/home-2');
    }

    public function home3()
    {
        return $this->render('/pages/home-3');
    }

    public function home4()
    {
        return $this->render('/pages/home-4');
    }

    public function home5()
    {
        return $this->render('/pages/home-5');
    }

    public function home6()
    {
        return $this->render('/pages/home-6');
    }

    public function home7()
    {
        return $this->render('/pages/home-7');
    }

    public function home8()
    {
        return $this->render('/pages/home-8');
    }

    public function home9()
    {
        return $this->render('/pages/home-9');
    }

    public function home10()
    {
        return $this->render('/pages/home-10');
    }

    public function home11()
    {
        return $this->render('/pages/home-11');
    }

    public function home12()
    {
        return $this->render('/pages/home-12');
    }

    public function gridStyle1()
    {
        return $this->render('/pages/grid-style-1');
    }

    public function gridStyle2()
    {
        return $this->render('/pages/grid-style-2');
    }

    public function gridStyle3()
    {
        return $this->render('/pages/grid-style-3');
    }

    public function gridStyle4()
    {
        return $this->render('/pages/grid-style-4');
    }

    public function gridStyle5()
    {
        return $this->render('/pages/grid-style-5');
    }

    public function fullJobGrid1()
    {
        return $this->render('/pages/full-job-grid-1');
    }

    public function fullJobGrid2()
    {
        return $this->render('/pages/full-job-grid-2');
    }

    public function listStyle1()
    {
        return $this->render('/pages/list-style-1');
    }

    public function listStyle2()
    {
        return $this->render('/pages/list-style-2');
    }

    public function listStyle3()
    {
        return $this->render('/pages/list-style-3');
    }

    public function fullJobList1()
    {
        return $this->render('/pages/full-job-list-1');
    }

    public function fullJobList2()
    {
        return $this->render('/pages/full-job-list-2');
    }

    public function halfMap()
    {
        return $this->render('/pages/half-map');
    }

    public function halfMap2()
    {
        return $this->render('/pages/half-map-2');
    }

    public function halfMap3()
    {
        return $this->render('/pages/half-map-3');
    }

    public function halfMapList1()
    {
        return $this->render('/pages/half-map-list-1');
    }

    public function halfMapList2()
    {
        return $this->render('/pages/half-map-list-2');
    }

    public function candidateGrid1()
    {
        return $this->render('/pages/candidate-grid-1');
    }

    public function candidateGrid2()
    {
        return $this->render('/pages/candidate-grid-2');
    }

    public function candidateList1()
    {
        return $this->render('/pages/candidate-list-1');
    }

    public function candidateList2()
    {
        return $this->render('/pages/candidate-list-2');
    }

    public function candidateHalfMap()
    {
        return $this->render('/pages/candidate-half-map');
    }

    public function candidateHalfMapList()
    {
        return $this->render('/pages/candidate-half-map-list');
    }

    public function singleLayout1()
    {
        return $this->render('/pages/single-layout-1');
    }

    public function singleLayout2()
    {
        return $this->render('/pages/single-layout-2');
    }

    public function singleLayout3()
    {
        return $this->render('/pages/single-layout-3');
    }

    public function singleLayout4()
    {
        return $this->render('/pages/single-layout-4');
    }

    public function singleLayout5()
    {
        return $this->render('/pages/single-layout-5');
    }

    public function singleLayout6()
    {
        return $this->render('/pages/single-layout-6');
    }

    public function candidateDetail2()
    {
        return $this->render('/pages/candidate-detail-2');
    }

    public function candidateDetail3()
    {
        return $this->render('/pages/candidate-detail-3');
    }

    public function advanceSearch()
    {
        return $this->render('/pages/advance-search');
    }

    public function candidateDashboard()
    {
        return $this->render('/pages/candidate-dashboard');
    }

    public function candidateProfile()
    {
        return $this->render('/pages/candidate-profile');
    }

    public function candidateResume()
    {
        return $this->render('/pages/candidate-resume');
    }

    public function candidateAppliedJobs()
    {
        return $this->render('/pages/candidate-applied-jobs');
    }

    public function candidateAlertJob()
    {
        return $this->render('/pages/candidate-alert-job');
    }

    public function candidateSavedJobs()
    {
        return $this->render('/pages/candidate-saved-jobs');
    }

    public function candidateFollowEmployers()
    {
        return $this->render('/pages/candidate-follow-employers');
    }

    public function candidateMessages()
    {
        return $this->render('/pages/candidate-messages');
    }

    public function candidateChangePassword()
    {
        return $this->render('/pages/candidate-change-password');
    }

    public function candidateDeleteAccount()
    {
        return $this->render('/pages/candidate-delete-account');
    }

    public function employerGrid1()
    {
        return $this->render('/pages/employer-grid-1');
    }

    public function employerGrid2()
    {
        return $this->render('/pages/employer-grid-2');
    }

    public function employerList1()
    {
        return $this->render('/pages/employer-list-1');
    }

    public function employerHalfMap()
    {
        return $this->render('/pages/employer-half-map');
    }

    public function employerHalfMapList()
    {
        return $this->render('/pages/employer-half-map-list');
    }

    public function employerDetail2()
    {
        return $this->render('/pages/employer-detail-2');
    }

    public function employerDashboard()
    {
        return $this->render('/pages/employer-dashboard');
    }

    public function employerProfile()
    {
        return $this->render('/pages/employer-profile');
    }

    public function employerJobs()
    {
        return $this->render('/pages/employer-jobs');
    }

    public function employerSubmitJob()
    {
        return $this->render('/pages/employer-submit-job');
    }

    public function employerApplicantsJobs()
    {
        return $this->render('/pages/employer-applicants-jobs');
    }

    public function employerShortlistCandidates()
    {
        return $this->render('/pages/employer-shortlist-candidates');
    }

    public function employerPackage()
    {
        return $this->render('/pages/employer-package');
    }

    public function employerMessages()
    {
        return $this->render('/pages/employer-messages');
    }

    public function employerChangePassword()
    {
        return $this->render('/pages/employer-change-password');
    }

    public function employerDeleteAccount()
    {
        return $this->render('/pages/employer-delete-account');
    }

    public function aboutUs()
    {
        return $this->render('/pages/about-us');
    }

    public function notFound()
    {
        return $this->render('/pages/404');
    }

    public function checkout()
    {
        return $this->render('/pages/checkout');
    }

    public function blog()
    {
        return $this->render('/pages/blog');
    }

    public function privacy()
    {
        return $this->render('/pages/privacy');
    }

    public function pricing()
    {
        return $this->render('/pages/pricing');
    }

    public function faq()
    {
        return $this->render('/pages/faq');
    }

    public function contact()
    {
        return $this->render('/pages/contact');
    }

    public function help()
    {
        return $this->render('/pages/help');
    }

    public function signup()
    {
        return $this->render('/pages/signup');
    }

    public function sliderHome()
    {
        return $this->render('/pages/slider-home');
    }
}
