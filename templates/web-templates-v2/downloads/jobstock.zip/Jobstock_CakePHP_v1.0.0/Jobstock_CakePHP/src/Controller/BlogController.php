<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Blog Controller
 *
 */
class BlogController extends AppController
{
    public function detail($slug = null)
    {
        $blogs = [
            [
                'id' => 1,
                'img' => 'assets/img/blog-1.jpg', 
                'title' => 'How To Work with jobstock Agency',
                'desc' => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat',
                'date' => '10 Jul 2026',
            ],
            [
                'id' => 2,
                'img' => 'assets/img/blog-2.jpg', 
                'title' => 'Auctor sit elementum habitant vel tempor varius.',
                'desc' => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat',
                'date' => '17 Jan 2026',
            ],
            [
                'id' => 3,
                'img' => 'assets/img/blog-3.jpg', 
                'title' => 'Consectetur purus habitasse ut diam habitant varius.',
                'desc' => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat',
                'date' => '26 Feb 2026',
            ],
            [
                'id' => 4,
                'img' => 'assets/img/blog-7.jpg', 
                'title' => 'Smartest Applications for Business',
                'desc' => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat',
                'date' => '19 Dec 2026',
            ],
            [
                'id' => 5,
                'img' => 'assets/img/blog-4.jpg', 
                'title' => 'Stop Worrying About Deadlines! We Got You Covered',
                'desc' => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat',
                'date' => '10 Aug 2026',
            ],
            [
                'id' => 6,
                'img' => 'assets/img/blog-5.jpg', 
                'title' => 'Change Your Strategy: Find a Business Consultant',
                'desc' => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat',
                'date' => '16 Jul 2026',
            ],
            [
                'id' => 7,
                'img' => 'assets/img/blog-6.jpg', 
                'title' => 'Everything About Financial Modeling',
                'desc' => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat',
                'date' => '07 May 2026',
            ],
            [
                'id' => 8,
                'img' => 'assets/img/blog-7.jpg', 
                'title' => 'On the other hand we provide denounce',
                'desc' => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat',
                'date' => '19 Dec 2026',
            ]
        ];

        $article = ['title' => 'Why People Like JobStock & It"s Team Managing?']; // Default value

        if ($slug !== null) {
            foreach ($blogs as $item) {
                $slugifiedTitle = strtolower(str_replace(' ', '-', $item['title']));
                if ($slugifiedTitle === strtolower($slug)) {
                    $article = $item;
                    break;
                }
            }
        }

        $this->set(compact('article'));
        $this->render('/pages/blog-detail');
    }
}