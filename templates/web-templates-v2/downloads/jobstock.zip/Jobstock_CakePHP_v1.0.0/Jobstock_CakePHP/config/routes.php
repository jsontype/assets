<?php
/**
 * Routes configuration.
 *
 * In this file, you set up routes to your controllers and their actions.
 * Routes are very important mechanism that allows you to freely connect
 * different URLs to chosen controllers and their actions (functions).
 *
 * It's loaded within the context of `Application::routes()` method which
 * receives a `RouteBuilder` instance `$routes` as method argument.
 *
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link          https://cakephp.org CakePHP(tm) Project
 * @license       https://opensource.org/licenses/mit-license.php MIT License
 */

use Cake\Routing\Route\DashedRoute;
use Cake\Routing\RouteBuilder;

return function (RouteBuilder $routes): void {
    
    $routes->setRouteClass(DashedRoute::class);

    $routes->scope('/', function (RouteBuilder $builder): void {
        
        $builder->connect('/', ['controller' => 'Pages', 'action' => 'display', 'index']);

        $builder->connect('/home-2', ['controller' => 'Pages', 'action' => 'home2']);
        $builder->connect('/home-3', ['controller' => 'Pages', 'action' => 'home3']);
        $builder->connect('/home-4', ['controller' => 'Pages', 'action' => 'home4']);
        $builder->connect('/home-5', ['controller' => 'Pages', 'action' => 'home5']);
        $builder->connect('/home-6', ['controller' => 'Pages', 'action' => 'home6']);
        $builder->connect('/home-7', ['controller' => 'Pages', 'action' => 'home7']);
        $builder->connect('/home-8', ['controller' => 'Pages', 'action' => 'home8']);
        $builder->connect('/home-9', ['controller' => 'Pages', 'action' => 'home9']);
        $builder->connect('/home-10', ['controller' => 'Pages', 'action' => 'home10']);
        $builder->connect('/home-11', ['controller' => 'Pages', 'action' => 'home11']);
        $builder->connect('/home-12', ['controller' => 'Pages', 'action' => 'home12']);

        $builder->connect('/grid-style-1', ['controller' => 'Pages', 'action' => 'gridStyle1']);
        $builder->connect('/grid-style-2', ['controller' => 'Pages', 'action' => 'gridStyle2']);
        $builder->connect('/grid-style-3', ['controller' => 'Pages', 'action' => 'gridStyle3']);
        $builder->connect('/grid-style-4', ['controller' => 'Pages', 'action' => 'gridStyle4']);
        $builder->connect('/grid-style-5', ['controller' => 'Pages', 'action' => 'gridStyle5']);
        $builder->connect('/full-job-grid-1', ['controller' => 'Pages', 'action' => 'fullJobGrid1']);
        $builder->connect('/full-job-grid-2', ['controller' => 'Pages', 'action' => 'fullJobGrid2']);
        $builder->connect('/list-style-1', ['controller' => 'Pages', 'action' => 'listStyle1']);
        $builder->connect('/list-style-2', ['controller' => 'Pages', 'action' => 'listStyle2']);
        $builder->connect('/list-style-3', ['controller' => 'Pages', 'action' => 'listStyle3']);
        $builder->connect('/full-job-list-1', ['controller' => 'Pages', 'action' => 'fullJobList1']);
        $builder->connect('/full-job-list-2', ['controller' => 'Pages', 'action' => 'fullJobList2']);

        $builder->connect('/half-map', ['controller' => 'Pages', 'action' => 'halfMap']);
        $builder->connect('/half-map-2', ['controller' => 'Pages', 'action' => 'halfMap2']);
        $builder->connect('/half-map-3', ['controller' => 'Pages', 'action' => 'halfMap3']);
        $builder->connect('/half-map-list-1', ['controller' => 'Pages', 'action' => 'halfMapList1']);
        $builder->connect('/half-map-list-2', ['controller' => 'Pages', 'action' => 'halfMapList2']);

        $builder->connect('/candidate-grid-1', ['controller' => 'Pages', 'action' => 'candidateGrid1']);
        $builder->connect('/candidate-grid-2', ['controller' => 'Pages', 'action' => 'candidateGrid2']);
        $builder->connect('/candidate-list-1', ['controller' => 'Pages', 'action' => 'candidateList1']);
        $builder->connect('/candidate-list-2', ['controller' => 'Pages', 'action' => 'candidateList2']);
        $builder->connect('/candidate-half-map', ['controller' => 'Pages', 'action' => 'candidateHalfMap']);
        $builder->connect('/candidate-half-map-list', ['controller' => 'Pages', 'action' => 'candidateHalfMapList']);

        $builder->connect('/single-layout-1', ['controller' => 'Pages', 'action' => 'singleLayout1']);
        $builder->connect('/single-layout-2', ['controller' => 'Pages', 'action' => 'singleLayout2']);
        $builder->connect('/single-layout-3', ['controller' => 'Pages', 'action' => 'singleLayout3']);
        $builder->connect('/single-layout-4', ['controller' => 'Pages', 'action' => 'singleLayout4']);
        $builder->connect('/single-layout-5', ['controller' => 'Pages', 'action' => 'singleLayout5']);
        $builder->connect('/single-layout-6', ['controller' => 'Pages', 'action' => 'singleLayout6']);

        $builder->connect('/candidate-detail', ['controller' => 'Candidate', 'action' => 'detail']);
        
        $builder->connect('/candidate-detail/{slug}', 
            ['controller' => 'Candidate', 'action' => 'detail'], 
            ['pass' => ['slug'], 'slug' => '[^/]+']
        );

        $builder->connect('/candidate-detail-2', ['controller' => 'Pages', 'action' => 'candidateDetail2']);
        $builder->connect('/candidate-detail-3', ['controller' => 'Pages', 'action' => 'candidateDetail3']);

        $builder->connect('/advance-search', ['controller' => 'Pages', 'action' => 'advanceSearch']);

        $builder->connect('/candidate-dashboard', ['controller' => 'Pages', 'action' => 'candidateDashboard']);
        $builder->connect('/candidate-profile', ['controller' => 'Pages', 'action' => 'candidateProfile']);
        $builder->connect('/candidate-resume', ['controller' => 'Pages', 'action' => 'candidateResume']);
        $builder->connect('/candidate-applied-jobs', ['controller' => 'Pages', 'action' => 'candidateAppliedJobs']);
        $builder->connect('/candidate-alert-job', ['controller' => 'Pages', 'action' => 'candidateAlertJob']);
        $builder->connect('/candidate-saved-jobs', ['controller' => 'Pages', 'action' => 'candidateSavedJobs']);
        $builder->connect('/candidate-follow-employers', ['controller' => 'Pages', 'action' => 'candidateFollowEmployers']);
        $builder->connect('/candidate-messages', ['controller' => 'Pages', 'action' => 'candidateMessages']);
        $builder->connect('/candidate-change-password', ['controller' => 'Pages', 'action' => 'candidateChangePassword']);
        $builder->connect('/candidate-delete-account', ['controller' => 'Pages', 'action' => 'candidateDeleteAccount']);

        $builder->connect('/employer-grid-1', ['controller' => 'Pages', 'action' => 'employerGrid1']);
        $builder->connect('/employer-grid-2', ['controller' => 'Pages', 'action' => 'employerGrid2']);
        $builder->connect('/employer-list-1', ['controller' => 'Pages', 'action' => 'employerList1']);
        $builder->connect('/employer-half-map', ['controller' => 'Pages', 'action' => 'employerHalfMap']);
        $builder->connect('/employer-half-map-list', ['controller' => 'Pages', 'action' => 'employerHalfMapList']);

        $builder->connect('/employer-detail', ['controller' => 'Employer', 'action' => 'detail']);
        
        $builder->connect('/employer-detail/{slug}', 
            ['controller' => 'Employer', 'action' => 'detail'], 
            ['pass' => ['slug'], 'slug' => '[^/]+']
        );

        $builder->connect('/employer-detail-2', ['controller' => 'Pages', 'action' => 'employerDetail2']);

        $builder->connect('/employer-dashboard', ['controller' => 'Pages', 'action' => 'employerDashboard']);
        $builder->connect('/employer-profile', ['controller' => 'Pages', 'action' => 'employerProfile']);
        $builder->connect('/employer-jobs', ['controller' => 'Pages', 'action' => 'employerJobs']);
        $builder->connect('/employer-submit-job', ['controller' => 'Pages', 'action' => 'employerSubmitJob']);
        $builder->connect('/employer-applicants-jobs', ['controller' => 'Pages', 'action' => 'employerApplicantsJobs']);
        $builder->connect('/employer-shortlist-candidates', ['controller' => 'Pages', 'action' => 'employerShortlistCandidates']);
        $builder->connect('/employer-package', ['controller' => 'Pages', 'action' => 'employerPackage']);
        $builder->connect('/employer-messages', ['controller' => 'Pages', 'action' => 'employerMessages']);
        $builder->connect('/employer-change-password', ['controller' => 'Pages', 'action' => 'employerChangePassword']);
        $builder->connect('/employer-delete-account', ['controller' => 'Pages', 'action' => 'employerDeleteAccount']);

        $builder->connect('/about-us', ['controller' => 'Pages', 'action' => 'aboutUs']);
        $builder->connect('/404', ['controller' => 'Pages', 'action' => 'notFound']);
        $builder->connect('/checkout', ['controller' => 'Pages', 'action' => 'checkout']);
        $builder->connect('/blog', ['controller' => 'Pages', 'action' => 'blog']);

        $builder->connect('/blog-detail', ['controller' => 'Blog', 'action' => 'detail']);
        
        $builder->connect('/blog-detail/{slug}', 
            ['controller' => 'Blog', 'action' => 'detail'], 
            ['pass' => ['slug'], 'slug' => '[^/]+']
        );

        $builder->connect('/privacy', ['controller' => 'Pages', 'action' => 'privacy']);
        $builder->connect('/pricing', ['controller' => 'Pages', 'action' => 'pricing']);
        $builder->connect('/faq', ['controller' => 'Pages', 'action' => 'faq']);

        $builder->connect('/contact', ['controller' => 'Pages', 'action' => 'contact']);
        $builder->connect('/contact/submit', ['controller' => 'Contact', 'action' => 'submit'], ['_method' => 'POST']);

        $builder->connect('/help', ['controller' => 'Pages', 'action' => 'help']);

        $builder->connect('/job-detail', ['controller' => 'Job', 'action' => 'detail']);
        
        $builder->connect('/job-detail/{slug}', 
            ['controller' => 'Job', 'action' => 'detail'], 
            ['pass' => ['slug'], 'slug' => '[^/]+']
        );

        $builder->connect('/signup', ['controller' => 'Pages', 'action' => 'signup']);
        $builder->connect('/slider-home', ['controller' => 'Pages', 'action' => 'sliderHome']);

        /*
         * ...and connect the rest of 'Pages' controller's URLs.
         */
        $builder->connect('/pages/*', 'Pages::display');

        $builder->fallbacks();
    });
};
