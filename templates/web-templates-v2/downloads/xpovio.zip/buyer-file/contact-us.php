<!DOCTYPE html>
<html lang="en">

<?php $title='Xpovio - Digital Agency Creative Portfolio Template '?>
<?php include './partials/head.php'?>

<body>
   <!--[if lte IE 9]>
      <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
      <![endif]-->
   <div class="my-app">
 <!-- Preloader Start -->
      <?php include './partials/preloader.php'?>

      <!-- Cursor Area Start -->
      <?php include './partials/cursor.php'?>

      <!-- Header Section Start -->
      <?php include './partials/header.php'?>
      <div id="smooth-wrapper">
         <div id="smooth-content">
            <!-- ==== main start ==== -->
            <main>
                <!--<< Breadcrumb Section Start >>-->
               <?php 
                     $img='assets/images/banner/cmn-banner-bg.png';
                     $Title='Home';
                     $Title2 = 'Contact Us';
               ?>
               <?php include './partials/page-header.php'?>

               <!-- ==== contact start ==== -->
               <section class="section contact-m fade-wrapper">
                  <div class="container">
                     <div class="row gaper">
                        <div class="col-12 col-sm-6 col-xl-3">
                           <div class="contact-m__single topy-tilt fade-top">
                              <div class="thumb">
                                 <img src="assets/images/phone.png" alt="Image">
                              </div>
                              <div class="content">
                                 <h4>Phone & Fax</h4>
                                 <p>
                                    <a href="tel:197-90-56-780">Mobile : +197-90-56-780</a>
                                 </p>
                                 <p>
                                    <a href="tel:197-90-56-780">Fax : +44-208-1234567</a>
                                 </p>
                              </div>
                           </div>
                        </div>
                        <div class="col-12 col-sm-6 col-xl-3">
                           <div class="contact-m__single topy-tilt fade-top">
                              <div class="thumb">
                                 <img src="assets/images/mail.png" alt="Image">
                              </div>
                              <div class="content">
                                 <h4>Mail Address</h4>
                                 <p>
                                    <a href="mailto:info.company@gmail.com">Info.company@gmail.com</a>
                                 </p>
                                 <p>
                                    <a href="mailto:info.company@gmail.com">Info.company@yahoo.com</a>
                                 </p>
                              </div>
                           </div>
                        </div>
                        <div class="col-12 col-sm-6 col-xl-3">
                           <div class="contact-m__single topy-tilt fade-top">
                              <div class="thumb">
                                 <img src="assets/images/location.png" alt="Image">
                              </div>
                              <div class="content">
                                 <h4>Our Location</h4>
                                 <p>
                                    <a href="https://www.google.com/maps/d/viewer?mid=1UZ57Drfs3SGrTgh6mrYjQktu6uY&hl=en_US&ll=18.672105000000013%2C105.68673800000003&z=17"
                                       target="_blank">
                                       85 Ketch Harbour
                                       RoadBensalem, PA 19020
                                    </a>
                                 </p>
                              </div>
                           </div>
                        </div>
                        <div class="col-12 col-sm-6 col-xl-3">
                           <div class="contact-m__single topy-tilt fade-top">
                              <div class="thumb">
                                 <img src="assets/images/time.png" alt="Image">
                              </div>
                              <div class="content">
                                 <h4>Office Hour</h4>
                                 <p>
                                    Sun - Thu
                                    09 am - 06pm
                                 </p>
                                 <p>
                                    Fri - Sat
                                    4 pm - 10pm
                                 </p>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-12">
                           <div class="map-wrapper">
                              <div class="row gaper">
                                 <div class="col-12 col-lg-6">
                                    <div class="contact__map fade-top">
                                       <iframe
                                          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d20342.411046372905!2d-74.16638039276373!3d40.719832743885284!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew%20York%2C%20NY%2C%20USA!5e0!3m2!1sen!2sbd!4v1649562691355!5m2!1sen!2sbd"
                                          width="100" height="800" style="border:0;" allowfullscreen="" loading="lazy"
                                          referrerpolicy="no-referrer-when-downgrade"></iframe>
                                    </div>
                                 </div>
                                 <div class="col-12 col-lg-6">
                                    <div class="contact-main__form  fade-top">
                                       <h3>Leave A Message</h3>
                                       <form action="#" method="post" class="section__content-cta">
                                          <div class="group-wrapper">
                                             <div class="group-input ">
                                                <input type="text" name="contact-name" id="contactName"
                                                   placeholder="Name">
                                             </div>
                                             <div class="group-input ">
                                                <input type="email" name="contact-email" id="contactEmail"
                                                   placeholder="Email">
                                             </div>
                                          </div>
                                          <div class="group-input ">
                                             <select class="subject">
                                                <option data-display="Subject">
                                                   Subject
                                                </option>
                                                <option value="1">Account</option>
                                                <option value="2">Service</option>
                                                <option value="3">Pricing</option>
                                                <option value="4">Support</option>
                                             </select>
                                          </div>
                                          <div class="group-input ">
                                             <textarea name="contact-message" id="contactMessage"
                                                placeholder="Message"></textarea>
                                          </div>
                                          <div class="form-cta justify-content-start">
                                             <button type="submit" class="btn btn--primary">
                                                Send Message
                                             </button>
                                          </div>
                                       </form>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </section>
               <!-- ==== / contact end ==== -->
            </main>
            <!-- ==== / main end ==== -->
           <!--<< Footer Section Start >>-->
            <?php include './partials/footer.php'?>
         </div>
      </div>
     <!-- Back to top area start here -->
   <?php include './partials/scroll-up.php'?>
   <!-- Back to top area end here -->
   </div>
     <!--<< All JS Plugins >>-->
   <?php include './partials/script.php'?>
</body>

</html>